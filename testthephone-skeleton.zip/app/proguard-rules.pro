# Bu dosya release build'de (isMinifyEnabled = true) R8'in hangi
# sınıfları/üyeleri "kullanılmıyor" diye silmemesi ya da isim
# değiştirmemesi gerektiğini belirtir. Reflection kullanan kütüphaneler
# (kotlinx.serialization, RootBeer) bu kurallar olmadan release
# build'de runtime'da ClassNotFoundException veya benzeri hatalarla
# çökebilir — debug build'de (minify kapalı) bu sorunlar hiç görünmez,
# bu yüzden gözden kaçması kolaydır.

# --- kotlinx.serialization ---
# JSON export/import (ReportJsonWriter/ReportJsonReader) bu kütüphaneyi
# kullanıyor. Serileştirilebilir sınıfların generated serializer'larını
# R8'in silmemesi gerekiyor.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclasseswithmembers class ** {
    kotlinx.serialization.KSerializer serializer(...);
}
-if @kotlinx.serialization.Serializable class **
-keepclassmembers class <1> {
    static <1>$Companion Companion;
}
-if @kotlinx.serialization.Serializable class ** {
    static **$* *;
}
-keepclassmembers class <1>$<3> {
    kotlinx.serialization.KSerializer serializer(...);
}
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# --- RootBeer ---
# Root tespiti çeşitli sistem sınıflarına ve dosya yollarına reflection
# ile erişiyor; kütüphanenin kendi sınıflarının isimlerinin
# değiştirilmemesi gerekiyor, aksi halde tespit mantığı sessizce
# yanlış sonuç dönebilir (ki bu, "cihaz root'lu değil" yanlış negatifine
# yol açabilir — güvenlik açısından ciddi bir hata sınıfı).
-keep class com.scottyab.rootbeer.** { *; }
-dontwarn com.scottyab.rootbeer.**

# --- Genel Compose/Kotlin coroutines ---
# Resmi Android/JetBrains kütüphaneleri genelde kendi consumer-rules.pro
# dosyalarını AAR içinde taşır ve bu kurallar otomatik uygulanır; burada
# ekstra bir şey gerekmiyor. Yine de coroutine debug metadata'sının
# silinmesiyle ilgili yaygın bir uyarıyı bastırıyoruz.
-dontwarn kotlinx.coroutines.debug.**

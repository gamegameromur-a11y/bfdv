plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.testthephone.app"
    // Play Store, 31 Ağustos 2026'dan itibaren yeni gönderimler için
    // API 36 (Android 16) hedeflenmesini zorunlu kılıyor.
    compileSdk = 36

    defaultConfig {
        applicationId = "com.testthephone.app" // Geçici — gerçek paket adı yayın öncesi belirlenecek
        // minSdk 26: HardwarePropertiesManager (API 24), PowerManager thermal
        // callback (API 29) gibi bazı API'ler daha yüksek sürüm ister, ancak
        // bunlar zaten runtime'da varlık kontrolü ile (best-effort) kullanılıyor.
        // 26, pazardaki cihazların büyük çoğunluğunu kapsarken temel API
        // seviyesini makul tutuyor.
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-dev"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // Release imzalama, GitHub Actions'daki KEYSTORE_PASSWORD/KEY_ALIAS/
    // KEY_PASSWORD ortam değişkenleriyle besleniyor (bkz.
    // .github/workflows/android-build.yml). Bu değişkenler CI dışında
    // (yerel derlemede) tanımlı değilse signingConfig sessizce boş kalır
    // ve release build imzasız (unsigned) üretilir — bu Play Store'a
    // yüklenemez ama en azından derlemenin kendisi kırılmaz, geliştirme
    // sırasında test edilebilir.
    val keystorePassword = System.getenv("KEYSTORE_PASSWORD")
    val keyAlias = System.getenv("KEY_ALIAS")
    val keyPassword = System.getenv("KEY_PASSWORD")
    val keystoreFile = file("release-keystore.jks")

    signingConfigs {
        if (keystorePassword != null && keyAlias != null && keyPassword != null && keystoreFile.exists()) {
            create("release") {
                storeFile = keystoreFile
                storePassword = keystorePassword
                this.keyAlias = keyAlias
                this.keyPassword = keyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // signingConfigs.findByName("release") null ise (secret'lar
            // tanımlı değilse) bu satır sessizce hiçbir imzalama
            // uygulamaz — build kırılmaz, sadece imzasız APK üretilir.
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // AppCompatDelegate.setApplicationLocales() için — uygulama içi dil
    // seçimini (per-app language) API 33 altındaki cihazlarda da tutarlı
    // çalıştırmak amacıyla. API 33+'ta framework'ün kendi per-app language
    // desteğiyle otomatik entegre olur; altında AppCompat kendi mekanizmasını
    // kullanır — tek bir API çağrısıyla her iki durumu da kapsar.
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    // History gibi genişletilmiş ikon setleri material-icons-core'da yok,
    // extended pakete ihtiyaç duyuyor.
    implementation("androidx.compose.material:material-icons-extended")

    // Kotlin coroutines — testlerin arka plan hesaplama döngüleri
    // ve izleme (monitoring) örnekleme akışları için.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // JSON serileştirme — rapor export formatı için.
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")

    // Kalıcı, basit anahtar-değer depolama (EULA onayı, dil/tema tercihi,
    // geçmiş oturum listesi) için Jetpack DataStore — SharedPreferences'ın
    // önerilen, coroutine-uyumlu yerine geçen halidir.
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Root/tamper tespiti (best-effort yerel kontrol).
    // Play Integrity API entegrasyonu ayrı bir adımda eklenecek
    // (backend doğrulama gerektirdiği için).
    implementation("com.scottyab:rootbeer-lib:0.1.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}

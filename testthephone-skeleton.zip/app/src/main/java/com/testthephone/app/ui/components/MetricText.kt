package com.testthephone.app.ui.components

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign

/**
 * Canlı değişen sayısal metrikler (FPS, sıcaklık, entity sayısı) için
 * sabit genişlikli rakam özelliğini (tabular numbers) etkinleştiren
 * Text sarmalayıcısı. Bu olmadan "9" ile "0" farklı genişlikte
 * render edilebilir, bu da sayı değiştikçe metnin yatayda hafifçe
 * kayması/titremesi hissine yol açar — özellikle test ekranında
 * sürekli güncellenen değerlerde rahatsız edici olur.
 */
@Composable
fun MetricText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    textAlign: TextAlign? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        textAlign = textAlign,
        style = LocalTextStyle.current.copy(
            fontFeatureSettings = "tnum",
        ),
    )
}

package com.testthephone.app.core.safety.integrity

import android.content.Context
import com.scottyab.rootbeer.RootBeer
import com.testthephone.app.report.DeviceIntegrityChecker
import com.testthephone.app.report.IntegrityResult

/**
 * RootBeer kütüphanesi üzerinden yerel, offline root tespiti. Play
 * Integrity API entegrasyonu (backend doğrulamalı, daha güçlü ama
 * ağ bağlantısı gerektiren yöntem) ayrı bir sınıfta (PlayIntegrityChecker)
 * eklenecek; ikisi birlikte kullanılacağı için bu sınıf tek başına
 * "unchecked" değil "rootbeer_local_only" etiketiyle raporlanıyor —
 * hangi yöntemin kullanıldığı şeffaf olsun diye.
 *
 * Root tespit edilirse, UI katmanı EULA'daki 9. maddeyi (modifiye
 * edilmiş cihaz uyarısı) test başlamadan önce ayrıca göstermeli.
 */
class RootBeerIntegrityChecker(private val context: Context) : DeviceIntegrityChecker {

    override fun check(): IntegrityResult {
        val rootBeer = RootBeer(context)

        // isRooted(): birden fazla belirtiyi (su binary, test-keys,
        // busybox, yaygın root paketleri, sistem dizin yazılabilirliği
        // vb.) birleştiren kapsamlı kontrol.
        val rooted = runCatching { rootBeer.isRooted }.getOrDefault(false)

        return IntegrityResult(
            rootedOrModified = rooted,
            verdictLabel = if (rooted) "rootbeer_local_detected" else "rootbeer_local_clean",
        )
    }
}

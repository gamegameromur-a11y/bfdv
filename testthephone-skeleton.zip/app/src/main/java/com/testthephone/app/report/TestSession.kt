package com.testthephone.app.report

import com.testthephone.app.core.monitoring.MetricsSnapshot
import com.testthephone.app.core.safety.SafetyEvent
import java.util.UUID

/**
 * Daha önce üzerinde anlaştığımız JSON şemasının uygulama içi (runtime)
 * karşılığı. TestRunner bu modeli doldurur; export sırasında
 * ReportJsonWriter bunu somut JSON'a çevirir.
 */
data class TestSession(
    val sessionId: String = UUID.randomUUID().toString(),
    val reportVersion: String = "1.0",
    val appVersion: String,
    val generatedAtUtcMillis: Long = System.currentTimeMillis(),
    val deviceProfile: DeviceProfile,
    val environmentSnapshot: EnvironmentSnapshot,
    val tests: MutableList<TestResult> = mutableListOf(),
    val safetyEvents: MutableList<SafetyEvent> = mutableListOf(),
)

data class DeviceProfile(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val cpuCoreCount: Int,
    val abi: List<String>,
    val ramTotalMb: Long,
    val rootedOrModified: Boolean,
    val integrityVerdict: String?,
    val adaptiveCalibration: AdaptiveCalibrationInfo,
)

/**
 * Kalibrasyon kararının şeffaflığı için: hangi girdilerle hangi
 * parametrelerin türetildiği rapora yazılır, "kara kutu" bir ayar değil.
 */
data class AdaptiveCalibrationInfo(
    val initialEntityCount: Int,
    val entityCountStep: Int,
    val maxEntityCountCap: Int,
    val calibrationRuleVersion: String = "linear_v1",
)

data class EnvironmentSnapshot(
    val batteryTempCStart: Float?,
    val batteryLevelPctStart: Int?,
    val thermalStatusStart: String,
)

/**
 * Tek bir testin tam sonucu: özet + tüm zaman serisi + durum bilgisi.
 * "status" alanı, testin nasıl bittiğini ayırt eder — bu, JSON'u okuyan
 * tarafın "bu veri eksik mi yoksa gerçekten mi bu kadar mı" sorusuna
 * cevap vermesi için gerekli.
 */
data class TestResult(
    val testId: String,
    var status: TestStatus = TestStatus.NOT_STARTED,
    var startedAtUtcMillis: Long? = null,
    var endedAtUtcMillis: Long? = null,
    var abortReason: String? = null,
    val timeseries: MutableList<MetricsSnapshot> = mutableListOf(),
    var summary: Map<String, Double> = emptyMap(),
    /**
     * Sayısal olmayan, kategorik özet bilgileri (örn. GPU testinde
     * hangi render modunun kullanıldığı: "agsl_shader" | "canvas_fallback").
     * summary Map<String, Double> olduğu için bu tür bilgileri sayıya
     * sıkıştırmak yerine ayrı, okunabilir bir alanda tutuyoruz.
     */
    var summaryLabels: Map<String, String> = emptyMap(),
)

enum class TestStatus {
    NOT_STARTED,
    RUNNING,
    COMPLETED,
    PAUSED,
    ABORTED,
    SKIPPED,
}

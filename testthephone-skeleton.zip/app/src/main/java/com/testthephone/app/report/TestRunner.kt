package com.testthephone.app.report

import com.testthephone.app.core.safety.SafetyController
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.core.safety.TestWakeLockManager
import com.testthephone.app.core.safety.ThermalMonitor
import com.testthephone.app.tests.DeviceCalibration
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.TestExecutionContext
import com.testthephone.app.tests.TestProgressEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/**
 * Testleri sırayla çalıştıran, ThermalMonitor'dan gelen okumaları
 * SafetyController'a besleyen ve her testin sonucunu TestSession'a
 * yazan orkestratör. UI katmanı bu sınıfın yayınladığı RunnerState'i
 * gözlemleyerek ekranı günceller.
 *
 * Tasarım kararı: TestRunner testlerin İÇİNDE ne yaptığını bilmez —
 * sadece TestEngine sözleşmesine güvenir. Bu ayrım, yeni bir test
 * eklendiğinde (GPU, progressive image, vb.) TestRunner'ın hiç
 * değişmemesini sağlıyor.
 */
class TestRunner(
    private val thermalMonitor: ThermalMonitor,
    private val session: TestSession,
    private val scope: CoroutineScope,
    private val wakeLockManager: TestWakeLockManager,
) {
    private val safetyController = SafetyController(thermalMonitor)

    private val _runnerState = MutableStateFlow<RunnerState>(RunnerState.Idle)
    val runnerState: StateFlow<RunnerState> = _runnerState.asStateFlow()

    // UI'nin canlı metrik kartlarını (TestProgressScreen) besleyebilmesi
    // için en son alınan snapshot ayrıca yayınlanır. runnerState sadece
    // "hangi test, kaçıncı sırada" bilgisini taşır; asıl sayısal veri
    // burada, ayrı bir StateFlow'da — böylece UI iki farklı güncelleme
    // sıklığındaki veriyi (nadir durum değişimi vs sık metrik güncellemesi)
    // birbirinden bağımsız gözlemleyebilir.
    private val _latestSnapshot = MutableStateFlow<com.testthephone.app.core.monitoring.MetricsSnapshot?>(null)
    val latestSnapshot: StateFlow<com.testthephone.app.core.monitoring.MetricsSnapshot?> = _latestSnapshot.asStateFlow()

    // GPU ve tepki süresi testleri TestEngine sözleşmesine uymadığı için
    // (Compose render/input döngüsüne bağlılar), runSingleTest içindeki
    // gibi kendi decisionStateFlow'larını kuramıyorlar — bu yüzden
    // TestRunner, safetyController'ın kararını dışarıya, aynı ince
    // StateFlow<SafetyDecision> sarmalayıcısıyla açar. Böylece
    // GpuTestController/ReactionTimeTestController TestRunner'ın iç
    // SafetyController'ına dolaylı olarak, tutarlı bir şekilde bağlanır.
    private val _exposedSafetyDecision = MutableStateFlow(SafetyDecision.RUNNING)
    val safetyDecisionFlow: StateFlow<SafetyDecision> = _exposedSafetyDecision.asStateFlow()

    /** GPU/tepki süresi testleri tamamlandığında sonucu session'a eklemek için. */
    fun registerExternalTestResult(result: TestResult) {
        session.tests.add(result)
    }

    /** Safety events listesini güncel tutmak için — GPU/tepki süresi testleri sonrası çağrılmalı. */
    fun syncSafetyEvents() {
        session.safetyEvents.clear()
        session.safetyEvents.addAll(safetyController.state.value.events)
    }

    init {
        // Termal okumaları sürekli dinle ve SafetyController'a besle.
        // Bu akış TestRunner'ın ömrü boyunca aktif kalır — testler
        // arasındaki boşluklarda bile izleme kesilmez.
        thermalMonitor.statusChanges()
            .onEach { reading -> safetyController.onThermalReading(reading) }
            .launchIn(scope)

        // safetyController.state değiştikçe dışarı açılan
        // safetyDecisionFlow'u da senkron tut — GPU/tepki süresi
        // testleri bunu dinliyor.
        safetyController.state
            .onEach { _exposedSafetyDecision.value = it.decision }
            .launchIn(scope)
    }

    /**
     * Belirtilen testleri sırayla çalıştırır. Bir test PAUSE_REQUIRED
     * kararıyla duraklarsa, kalan testler çalıştırılmaz — kullanıcı
     * "soğuyunca devam et" dediğinde resumeFromPause() çağrılır.
     *
     * engineFactories, düz TestEngine listesi DEĞİL — her eleman,
     * o ana kadar TAMAMLANMIŞ testlerin sonuçlarını (testId -> summary
     * Map) alıp gerçek TestEngine'i üreten bir fabrika fonksiyonu.
     * Bu, Test 2'nin Test 1'in bulduğu statik kapasiteyi, Test 5'in
     * Test 1/2'nin referans kapasitesini GERÇEKTEN kullanabilmesini
     * sağlıyor — önceden her motor sabit bir varsayılanla (staticCapacityHint=0
     * gibi) kuruluyordu, bu adaptif zincir eksikti.
     *
     * WakeLock, tüm test dizisi boyunca (tek bir test değil, runAll'a
     * verilen TÜM engines listesi bitene kadar) tutulur — testler
     * arasındaki kısa geçişlerde ekranın kilitlenip açılması hem
     * rahatsız edici olur hem de kilitliyken termal izlemenin
     * (Android'in kendi ekran kapalıyken kısıtlamaları) güvenilirliğini
     * etkileyebilir.
     */
    fun runAll(
        engineFactories: List<(priorResults: Map<String, Map<String, Double>>) -> TestEngine>,
        calibration: DeviceCalibration,
    ) {
        // Çift-tetiklenme koruması: runnerState zaten Running/PausedForThermal
        // ise (örn. kullanıcı UI güncellenmeden önce butona ikinci kez
        // bastıysa) yeni bir çalıştırma başlatma — aksi halde iki ayrı
        // runAll() coroutine'i aynı anda testleri paylaşımlı kaynaklar
        // (MetricsCollector, WakeLock vb.) üzerinde çalıştırır, bu da hem
        // tutarsız sonuçlara hem de gerçek bir performans/donma sorununa
        // yol açar.
        if (_runnerState.value is RunnerState.Running || _runnerState.value is RunnerState.PausedForThermal) {
            return
        }
        wakeLockManager.acquire()
        scope.launch {
            _runnerState.value = RunnerState.Running(currentTestId = null, testIndex = 0, totalTests = engineFactories.size)

            // testId -> summary eşlemesi, her test bitince güncellenir.
            // Sonraki fabrikalar bunu okuyarak önceki testlerin sonucuna
            // göre kendi parametrelerini (örn. referans entity sayısı)
            // belirleyebilir.
            val priorResults = mutableMapOf<String, Map<String, Double>>()

            for ((index, factory) in engineFactories.withIndex()) {
                val engine = factory(priorResults)
                val result = TestResult(testId = engine.testId)
                session.tests.add(result)

                _runnerState.value = RunnerState.Running(
                    currentTestId = engine.testId,
                    testIndex = index,
                    totalTests = engineFactories.size,
                )

                val outcome = runSingleTest(engine, calibration, result)
                priorResults[engine.testId] = result.summary

                if (outcome == SingleTestOutcome.PAUSED) {
                    _runnerState.value = RunnerState.PausedForThermal(engine.testId, index, engineFactories.size)
                    wakeLockManager.release() // Duraklatıldı: kullanıcı bekleyecek, ekranı zorla açık tutmaya gerek yok.
                    return@launch // Kalan testler kullanıcı devam edene kadar başlamaz.
                }
            }

            _runnerState.value = RunnerState.AllCompleted
            wakeLockManager.release()
        }
    }

    private suspend fun runSingleTest(
        engine: TestEngine,
        calibration: DeviceCalibration,
        result: TestResult,
    ): SingleTestOutcome {
        result.status = TestStatus.RUNNING
        result.startedAtUtcMillis = System.currentTimeMillis()

        // safetyController.state bir StateFlow<SafetyState>; test motorları
        // sadece "decision" alanına ihtiyaç duyduğu için burada projeksiyon
        // (map) yerine, doğrudan mevcut değeri anlık okuyabilecekleri
        // ince bir StateFlow sarmalayıcısı geçiyoruz.
        val decisionStateFlow = kotlinx.coroutines.flow.MutableStateFlow(
            safetyController.state.value.decision
        )
        val decisionSyncJob = safetyController.state
            .onEach { decisionStateFlow.value = it.decision }
            .launchIn(scope)

        val context = TestExecutionContext(
            safetyDecision = decisionStateFlow,
            calibration = calibration,
        )

        var outcome = SingleTestOutcome.COMPLETED

        try {
            // ÖNEMLİ: Test motorları (EntitySpawnTestEngine, MultiCoreWorkloadTestEngine
            // vb.) flow {} bloğu içinde YOĞUN, senkron CPU hesaplaması yapıyor
            // (binlerce entity simülasyonu, sıkı while döngüleri). flowOn olmadan
            // bu iş, collect'i çağıran coroutine'in dispatcher'ında çalışır — ki bu
            // burada scope (lifecycleScope) üzerinden Dispatchers.Main'dir. Sonuç:
            // ana/UI thread'i saniyelerce bloklanır, uygulama "Test Başlat"a
            // basıldığında donmuş görünür ve ANR riski oluşur (özellikle emülatörde,
            // gerçek cihaza göre CPU çok daha yavaş/paylaşımlı olduğu için bu çok
            // daha belirgin hale gelir). flowOn(Dispatchers.Default) ile ağır işi
            // arka plan thread havuzuna taşıyoruz; emit edilen event'ler yine de
            // collect'in kendi context'inde (Main) toplanmaya devam eder, bu yüzden
            // UI state güncellemeleri güvenli kalır.
            engine.run(context)
                .flowOn(Dispatchers.Default)
                .collect { event ->
                when (event) {
                    is TestProgressEvent.Sample -> {
                        result.timeseries.add(event.snapshot)
                        _latestSnapshot.value = event.snapshot
                    }
                    is TestProgressEvent.Paused -> {
                        result.status = TestStatus.PAUSED
                        result.abortReason = event.reason
                        outcome = SingleTestOutcome.PAUSED
                    }
                    is TestProgressEvent.Completed -> {
                        result.status = TestStatus.COMPLETED
                        result.summary = event.summary
                        outcome = SingleTestOutcome.COMPLETED
                    }
                    is TestProgressEvent.Aborted -> {
                        result.status = TestStatus.ABORTED
                        result.abortReason = event.reason
                        outcome = SingleTestOutcome.ABORTED
                    }
                }
            }
        } finally {
            decisionSyncJob.cancel()
        }

        result.endedAtUtcMillis = System.currentTimeMillis()
        session.safetyEvents.clear()
        session.safetyEvents.addAll(safetyController.state.value.events)

        return outcome
    }

    /** Kullanıcı "soğuyunca devam et" seçtiğinde çağrılır. */
    fun resumeFromPause(
        remainingEngineFactories: List<(priorResults: Map<String, Map<String, Double>>) -> TestEngine>,
        calibration: DeviceCalibration,
    ) {
        safetyController.requestResume()
        if (safetyController.state.value.decision != SafetyDecision.PAUSE_REQUIRED) {
            runAll(remainingEngineFactories, calibration)
        }
        // Hâlâ kritik seviyedeyse hiçbir şey yapmaz; UI kullanıcıya
        // "hâlâ soğumadı, tekrar dene" göstermeli.
    }
}

private enum class SingleTestOutcome { COMPLETED, PAUSED, ABORTED }

sealed interface RunnerState {
    data object Idle : RunnerState
    data class Running(val currentTestId: String?, val testIndex: Int, val totalTests: Int) : RunnerState
    data class PausedForThermal(val pausedTestId: String, val testIndex: Int, val totalTests: Int) : RunnerState
    data object AllCompleted : RunnerState
}

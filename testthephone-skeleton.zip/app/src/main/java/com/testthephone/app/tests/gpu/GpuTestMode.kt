package com.testthephone.app.tests.gpu

import android.os.Build

/**
 * Test 3: GPU render testi. "PC'lerdeki GPU testinin minimalize ve
 * kademeli büyüyen hali" — çok küçük bir hesaplama yükünden başlayıp
 * kademeli olarak artan bir eğri.
 *
 * İki mod arasında otomatik geçiş yapılır:
 *  - API 33+ (Android 13+): gerçek AGSL/RuntimeShader tabanlı GPU yükü
 *    (GpuStressShader). Piksel başına GPU'da çalışan gerçek bir hesaplama.
 *  - API 26-32: Canvas tabanlı fallback — çok sayıda path/shape çizerek
 *    GPU'nun rasterization/compositing işini zorlayan alternatif yük.
 *
 * Hangi modun kullanıldığı rapora AÇIKÇA yazılır (renderMode alanı),
 * çünkü iki yöntemin ölçtüğü şey aynı değil — AGSL saf hesaplama
 * gücünü, Canvas fallback ise daha çok compositing/overdraw kapasitesini
 * yansıtır. Bunu şeffaf belirtmek, "doğru rapor" hedefinin bir parçası.
 */
object GpuTestModeSelector {

    fun select(): GpuTestMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        GpuTestMode.AGSL_SHADER
    } else {
        GpuTestMode.CANVAS_FALLBACK
    }
}

enum class GpuTestMode {
    AGSL_SHADER,
    CANVAS_FALLBACK,
}

/**
 * Her iki modda da kademeli olarak artan bir "yoğunluk" parametresi
 * kullanılır. AGSL modunda bu, shader'daki iterasyon sayısına karşılık
 * gelir; Canvas modunda çizilen şekil sayısına.
 *
 * Kalibrasyon, entity testindekiyle aynı mantığı izler: cihaza göre
 * başlangıç değeri ve adım büyüklüğü ölçeklenir, ama GPU yükünün
 * doğası CPU'dan farklı olduğu için ayrı bir kalibrasyon eğrisi kullanılır.
 */
data class GpuLoadStep(
    val stepIndex: Int,
    /** AGSL modunda shader iterasyon sayısı (1-512 arası). */
    val shaderIterations: Float,
    /** Canvas modunda çizilecek şekil sayısı. */
    val canvasShapeCount: Int,
)

class GpuLoadCalibrator(private val gpuTierHint: GpuTierHint) {

    // Başlangıç ve adım büyüklüğü, GPU'nun "tahmini seviyesine" göre
    // ölçeklenir. Gerçek GPU model tespiti (renderer string'inden)
    // güvenilir bir performans sınıflandırması vermez, bu yüzden
    // bilinçli olarak muhafazakar ve düşük seviyeden başlanır — her
    // cihaz kendi gerçek kapasitesine testin İLK ADIMLARINDA ulaşır,
    // varsayımla değil, ölçümle.
    //
    // ÖNEMLİ BUG DÜZELTMESİ: canvasShapeCount önceden HİÇBİR üst sınıra
    // sahip değildi (shaderIterations 512f'de tavan yapıyordu ama
    // canvasShapeCount = 50 + index * 40 sınırsızca büyüyordu). API 33
    // altı cihazlarda/emülatörlerde (CANVAS_FALLBACK modu), eğer Canvas
    // render maliyeti frame time eşiğini (33.3ms) yeterince hızlı
    // aşmazsa — özellikle software-rendering kullanan bazı emülatörlerde
    // ortaya çıkan bir durum — stepIndex sınırsızca artmaya devam
    // ediyordu. Bu da her adımda +40 daire eklenen, sonunda binlerce/on
    // binlerce yarı saydam daireyi TEK BİR FRAME'DE çizmeye çalışan bir
    // Canvas'a yol açıyordu: test teknik olarak "sonsuz döngü" değildi
    // ama pratikte donmuş gibi görünen, makul sürede asla bitmeyen bir
    // duruma giriyordu. maxCanvasShapeCount ile bir tavan koyduk —
    // buraya ulaşılırsa yoğunluk artık artmıyor, GpuTestController'daki
    // consecutiveFailureThreshold mantığı normal şekilde devreye girip
    // testi zamanında sonlandırabiliyor.
    private val maxCanvasShapeCount = 4000

    fun stepFor(index: Int): GpuLoadStep {
        val shaderIterations = (8f + index * 6f).coerceAtMost(512f)
        val canvasShapeCount = (50 + index * 40).coerceAtMost(maxCanvasShapeCount)

        return GpuLoadStep(
            stepIndex = index,
            shaderIterations = shaderIterations,
            canvasShapeCount = canvasShapeCount,
        )
    }
}

/**
 * GPU'nun kabaca hangi seviyede olabileceğine dair zayıf bir ipucu —
 * kesin bir sınıflandırma değil, sadece kalibrasyonun başlangıç
 * noktasını çok yanlış seçmemek için. cpuCoreCount üzerinden dolaylı
 * bir tahmin (güçlü CPU'lu cihazlar genelde daha güçlü GPU'ya sahiptir,
 * ama bu garanti değil — bu yüzden INDIRECT_ESTIMATE mantığıyla tutarlı,
 * sadece başlangıç noktası için kullanılır, sonuçları etkilemez).
 */
data class GpuTierHint(val cpuCoreCount: Int)

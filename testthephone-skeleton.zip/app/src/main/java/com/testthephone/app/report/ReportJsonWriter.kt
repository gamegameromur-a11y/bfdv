package com.testthephone.app.report

import com.testthephone.app.core.monitoring.json.toJsonObject
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import java.io.File

/**
 * TestSession'ı, konuşmamızda kararlaştırdığımız JSON şemasına birebir
 * uyan bir dosyaya yazar. Tüm alan adları İngilizce ve sabit — uygulama
 * arayüzü 8 dilde olsa da, export her zaman aynı, öngörülebilir şemaya
 * sahip olmalı (AI/teknik servis tarafı diline göre parse mantığı
 * değiştirmek zorunda kalmasın diye).
 */
class ReportJsonWriter {

    private val json = Json {
        prettyPrint = true
        encodeDefaults = true
    }

    fun buildJson(session: TestSession): String {
        val root = buildJsonObject {
            put("report_version", JsonPrimitive(session.reportVersion))
            put("app_version", JsonPrimitive(session.appVersion))
            put("generated_at_utc_millis", JsonPrimitive(session.generatedAtUtcMillis))
            put("test_session_id", JsonPrimitive(session.sessionId))

            put("device_profile", deviceProfileJson(session.deviceProfile))
            put("environment_snapshot", environmentSnapshotJson(session.environmentSnapshot))

            put("tests", buildJsonArray {
                session.tests.forEach { add(testResultJson(it)) }
            })

            put("safety_events", buildJsonArray {
                session.safetyEvents.forEach { event ->
                    add(buildJsonObject {
                        put("timestamp_ms", JsonPrimitive(event.timestampMs))
                        put("trigger_thermal_status", JsonPrimitive(event.triggerThermalStatus.name))
                        put(
                            "headroom_at_trigger",
                            event.headroomAtTrigger?.let { JsonPrimitive(it) } ?: JsonNull,
                        )
                    })
                }
            })
        }
        return json.encodeToString(JsonObject.serializer(), root)
    }

    fun writeToFile(session: TestSession, outputFile: File) {
        outputFile.parentFile?.mkdirs()
        outputFile.writeText(buildJson(session))
    }

    private fun deviceProfileJson(profile: DeviceProfile) = buildJsonObject {
        put("manufacturer", JsonPrimitive(profile.manufacturer))
        put("model", JsonPrimitive(profile.model))
        put("android_version", JsonPrimitive(profile.androidVersion))
        put("sdk_int", JsonPrimitive(profile.sdkInt))
        put("cpu_core_count", JsonPrimitive(profile.cpuCoreCount))
        put("abi", buildJsonArray { profile.abi.forEach { add(JsonPrimitive(it)) } })
        put("ram_total_mb", JsonPrimitive(profile.ramTotalMb))
        put("device_integrity", buildJsonObject {
            put("rooted_or_modified", JsonPrimitive(profile.rootedOrModified))
            put("verdict", profile.integrityVerdict?.let { JsonPrimitive(it) } ?: JsonNull)
        })
        put("adaptive_calibration", buildJsonObject {
            put("initial_entity_count", JsonPrimitive(profile.adaptiveCalibration.initialEntityCount))
            put("entity_count_step", JsonPrimitive(profile.adaptiveCalibration.entityCountStep))
            put("max_entity_count_cap", JsonPrimitive(profile.adaptiveCalibration.maxEntityCountCap))
            put("calibration_rule_version", JsonPrimitive(profile.adaptiveCalibration.calibrationRuleVersion))
        })
    }

    private fun environmentSnapshotJson(env: EnvironmentSnapshot) = buildJsonObject {
        put(
            "battery_temp_c_start",
            env.batteryTempCStart?.let { JsonPrimitive(it) } ?: JsonNull,
        )
        put(
            "battery_level_pct_start",
            env.batteryLevelPctStart?.let { JsonPrimitive(it) } ?: JsonNull,
        )
        put("thermal_status_start", JsonPrimitive(env.thermalStatusStart))
    }

    private fun testResultJson(result: TestResult) = buildJsonObject {
        put("test_id", JsonPrimitive(result.testId))
        put("status", JsonPrimitive(result.status.name.lowercase()))
        put(
            "started_at_utc_millis",
            result.startedAtUtcMillis?.let { JsonPrimitive(it) } ?: JsonNull,
        )
        put(
            "ended_at_utc_millis",
            result.endedAtUtcMillis?.let { JsonPrimitive(it) } ?: JsonNull,
        )
        put(
            "duration_ms",
            if (result.startedAtUtcMillis != null && result.endedAtUtcMillis != null) {
                JsonPrimitive(result.endedAtUtcMillis!! - result.startedAtUtcMillis!!)
            } else JsonNull,
        )
        put(
            "abort_reason",
            result.abortReason?.let { JsonPrimitive(it) } ?: JsonNull,
        )

        put("summary", buildJsonObject {
            result.summary.forEach { (k, v) -> put(k, JsonPrimitive(v)) }
        })
        put("summary_labels", buildJsonObject {
            result.summaryLabels.forEach { (k, v) -> put(k, JsonPrimitive(v)) }
        })

        put("timeseries", buildJsonArray {
            result.timeseries.forEach { add(it.toJsonObject()) }
        })
    }
}

package com.testthephone.app.core.monitoring

import java.io.File

/**
 * /proc/stat üzerinden CPU kullanım yüzdesini hesaplar. İzin gerektirmez
 * ama /proc/stat'ın içeriği ve erişilebilirliği cihaza/Android sürümüne
 * göre değişebildiği için BEST_EFFORT olarak işaretlenir.
 *
 * Kullanım oranı, ardışık iki okuma arasındaki farktan hesaplanır —
 * bu yüzden bu sınıf iki çağrı arasındaki son ham okumayı saklar (stateful).
 */
class CpuUsageMonitor {

    private var previousTotalSnapshot: CpuTimeSnapshot? = null
    private var previousPerCoreSnapshot: List<CpuTimeSnapshot>? = null

    /**
     * Toplam CPU kullanım yüzdesini döner. İlk çağrıda referans noktası
     * olmadığı için null/UNAVAILABLE döner; sonraki çağrılarda iki
     * örnekleme arasındaki farktan hesaplanan gerçek değeri verir.
     */
    fun totalUsagePct(): MeasuredValue<Float> {
        val current = readTotalCpuTime() ?: return unavailable("proc_stat:unreadable")
        val previous = previousTotalSnapshot
        previousTotalSnapshot = current

        if (previous == null) return unavailable("proc_stat:awaiting_second_sample")

        val usage = calculateUsagePct(previous, current)
        return bestEffort(usage, "proc_stat")
    }

    /** Çekirdek başına kullanım yüzdesi listesi. */
    fun perCoreUsagePct(): MeasuredValue<List<Float>> {
        val current = readPerCoreCpuTime() ?: return unavailable("proc_stat:per_core_unreadable")
        val previous = previousPerCoreSnapshot
        previousPerCoreSnapshot = current

        if (previous == null || previous.size != current.size) {
            return unavailable("proc_stat:per_core_awaiting_second_sample")
        }

        val usages = current.zip(previous) { curr, prev -> calculateUsagePct(prev, curr) }
        return bestEffort(usages, "proc_stat:per_core")
    }

    private fun calculateUsagePct(previous: CpuTimeSnapshot, current: CpuTimeSnapshot): Float {
        val totalDelta = current.total - previous.total
        val idleDelta = current.idle - previous.idle
        if (totalDelta <= 0) return 0f
        val busyDelta = totalDelta - idleDelta
        return (busyDelta.toFloat() / totalDelta.toFloat() * 100f).coerceIn(0f, 100f)
    }

    private fun readTotalCpuTime(): CpuTimeSnapshot? {
        val line = runCatching {
            File("/proc/stat").useLines { it.firstOrNull { l -> l.startsWith("cpu ") } }
        }.getOrNull() ?: return null
        return parseCpuLine(line)
    }

    private fun readPerCoreCpuTime(): List<CpuTimeSnapshot>? {
        val lines = runCatching {
            File("/proc/stat").useLines { seq ->
                seq.filter { it.matches(Regex("^cpu\\d+ .*")) }.toList()
            }
        }.getOrNull() ?: return null
        if (lines.isEmpty()) return null
        return lines.mapNotNull { parseCpuLine(it) }
    }

    private fun parseCpuLine(line: String): CpuTimeSnapshot? {
        // Format: cpu[N]  user nice system idle iowait irq softirq steal ...
        val fields = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (fields.size < 4) return null
        val idle = fields[3]
        val total = fields.sum()
        return CpuTimeSnapshot(total = total, idle = idle)
    }
}

private data class CpuTimeSnapshot(val total: Long, val idle: Long)

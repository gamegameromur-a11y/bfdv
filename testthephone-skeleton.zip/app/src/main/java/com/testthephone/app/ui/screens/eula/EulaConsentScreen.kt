package com.testthephone.app.ui.screens.eula

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.ui.theme.AppColors

// Zorunlu EULA onay ekrani. readOnlyMode = true oldugunda (Ayarlar
// ekranindan tekrar acildiginda) onay/reddet butonlari yerine tek bir
// "Kapat" butonu gosterilir. Tum metin stringResource uzerinden 8 dilde
// lokalize (bkz. res/values*/strings.xml, eula_section_N_title/body).
// Not: bu metin taslak niteligindedir, gercek yayin oncesi hukuki
// gozden gecirme gerektirir.
@Composable
fun EulaConsentScreen(
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    readOnlyMode: Boolean = false,
    onClose: () -> Unit = {},
) {
    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(vertical = 20.dp),
        ) {
            item {
                Text(
                    text = stringResource(R.string.eula_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = AppColors.TextPrimary,
                )
                Text(
                    text = stringResource(R.string.eula_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = AppColors.TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
                )
            }

            items(eulaSectionResourceIds) { section ->
                EulaSectionBlock(section)
            }
        }

        if (readOnlyMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
            ) {
                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AppColors.FillPrimary,
                        contentColor = AppColors.OnPrimary,
                    ),
                ) {
                    Text(text = stringResource(R.string.generic_close))
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = onDecline,
                    modifier = Modifier.weight(1f),
                ) {
                    Text(text = stringResource(R.string.eula_decline))
                }
                Button(
                    onClick = onAccept,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AppColors.FillPrimary,
                        contentColor = AppColors.OnPrimary,
                    ),
                ) {
                    Text(text = stringResource(R.string.eula_accept))
                }
            }
        }
    }
}

@Composable
private fun EulaSectionBlock(section: EulaSectionRes) {
    Column(modifier = Modifier.padding(bottom = 16.dp)) {
        Text(
            text = "${section.number}. ${stringResource(section.titleRes)}",
            style = MaterialTheme.typography.titleMedium,
            color = AppColors.TextPrimary,
            fontWeight = FontWeight.Medium,
        )
        Text(
            text = stringResource(section.bodyRes),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextSecondary,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

data class EulaSectionRes(val number: Int, val titleRes: Int, val bodyRes: Int)

private val eulaSectionResourceIds = listOf(
    EulaSectionRes(1, R.string.eula_section_1_title, R.string.eula_section_1_body),
    EulaSectionRes(2, R.string.eula_section_2_title, R.string.eula_section_2_body),
    EulaSectionRes(3, R.string.eula_section_3_title, R.string.eula_section_3_body),
    EulaSectionRes(4, R.string.eula_section_4_title, R.string.eula_section_4_body),
    EulaSectionRes(5, R.string.eula_section_5_title, R.string.eula_section_5_body),
    EulaSectionRes(6, R.string.eula_section_6_title, R.string.eula_section_6_body),
    EulaSectionRes(7, R.string.eula_section_7_title, R.string.eula_section_7_body),
    EulaSectionRes(8, R.string.eula_section_8_title, R.string.eula_section_8_body),
    EulaSectionRes(9, R.string.eula_section_9_title, R.string.eula_section_9_body),
    EulaSectionRes(10, R.string.eula_section_10_title, R.string.eula_section_10_body),
)

package com.testthephone.app.core.monitoring

import java.io.File

/**
 * CPU-Z / CPU Throttling Test gibi araçların kullandığı yönteme benzer:
 * /sys/class/thermal/thermal_zoneN dizinlerini tarar, "type" dosyasındaki
 * isimden hangi donanım bileşenine ait olabileceğini TAHMİN eder.
 *
 * Bu KESİN bir CPU/GPU sıcaklığı değildir — zone-donanım eşlemesi
 * cihaza ve kernel'e göre değişir, bazı cihazlarda SELinux erişimi tümüyle
 * engeller. Bu yüzden tüm sonuçlar INDIRECT_ESTIMATE olarak işaretlenir
 * ve hangi zone etiketinden geldiği (zoneLabel) rapora dahil edilir —
 * şeffaflık için, "kesin CPU sıcaklığı" gibi yanıltıcı bir izlenim
 * vermemek adına.
 *
 * İzin gerektirmez; erişilemeyen dosyalar sessizce atlanır.
 */
class ThermalZoneReader {

    private val thermalRoot = File("/sys/class/thermal")

    // Zone "type" dosyasındaki isimde bu anahtar kelimelerden biri
    // geçiyorsa ilgili kategoriye eşleniyor. Sıra önemli: daha spesifik
    // olanlar (cpu, gpu) önce kontrol edilir.
    private val categoryKeywords = mapOf(
        ThermalZoneCategory.CPU to listOf("cpu", "apc", "cpuss", "tsens_tz", "core"),
        ThermalZoneCategory.GPU to listOf("gpu"),
        ThermalZoneCategory.BATTERY to listOf("battery", "batt", "bms"),
        ThermalZoneCategory.SKIN to listOf("skin", "quiet"),
    )

    /**
     * Tüm okunabilir thermal_zone dizinlerini tarar ve kategori
     * eşleştirmesiyle birlikte döner. Cihazda erişim engelliyse
     * (SELinux ya da dizin yoksa) boş liste döner — bu durum çağıran
     * tarafta UNAVAILABLE olarak işlenmeli.
     */
    fun readAll(): List<ThermalZoneReading> {
        // ÖNEMLİ: File.listFiles() genelde erişim reddedilince null döner,
        // ama bazı SELinux-kısıtlı OEM ROM'larında SecurityException
        // fırlattığı da gözlemlenmiştir (belgelenmemiş davranış farkı).
        // Bu, MetricsCollector.snapshot() üzerinden her test adımında
        // çağrıldığı için korumasız kalması testin ortasında beklenmedik
        // bir çökmeye yol açabilir. runCatching ile "erişilemiyor" durumunu
        // her koşulda (null DÖNSÜN ya da exception FIRLATSIN) aynı şekilde
        // boş liste olarak ele alıyoruz.
        val zoneDirs = runCatching {
            thermalRoot.listFiles { file ->
                file.isDirectory && file.name.startsWith("thermal_zone")
            }
        }.getOrNull() ?: return emptyList()

        return zoneDirs.mapNotNull { dir -> readZone(dir) }
    }

    /** Belirli bir kategoriye ait (best-effort eşlemeyle) ilk okumayı döner. */
    fun readCategory(category: ThermalZoneCategory): MeasuredValue<Float> {
        val reading = readAll().firstOrNull { it.category == category }
            ?: return unavailable("sysfs_thermal_zone:no_match_for_${category.name.lowercase()}")

        return indirectEstimate(
            reading.temperatureC,
            "sysfs_thermal_zone:${reading.zoneIndex}:label=${reading.typeLabel}",
        )
    }

    private fun readZone(dir: File): ThermalZoneReading? {
        val typeFile = File(dir, "type")
        val tempFile = File(dir, "temp")
        if (!typeFile.canRead() || !tempFile.canRead()) return null

        val typeLabel = runCatching { typeFile.readText().trim() }.getOrNull() ?: return null
        val rawTemp = runCatching { tempFile.readText().trim().toLong() }.getOrNull() ?: return null

        // Değer genelde milidenece cinsinden gelir (örn. 34500 -> 34.5°C),
        // ama bazı cihazlarda doğrudan derece gelebiliyor. 1000'den büyük
        // değerleri milidenece varsayıyoruz — bu da best-effort bir sezgi.
        val tempC = if (rawTemp > 1000) rawTemp / 1000.0f else rawTemp.toFloat()

        val category = categoryKeywords.entries
            .firstOrNull { (_, keywords) -> keywords.any { typeLabel.lowercase().contains(it) } }
            ?.key ?: ThermalZoneCategory.UNKNOWN

        val zoneIndex = dir.name.removePrefix("thermal_zone").toIntOrNull() ?: -1

        return ThermalZoneReading(
            zoneIndex = zoneIndex,
            typeLabel = typeLabel,
            temperatureC = tempC,
            category = category,
        )
    }
}

enum class ThermalZoneCategory { CPU, GPU, BATTERY, SKIN, UNKNOWN }

data class ThermalZoneReading(
    val zoneIndex: Int,
    val typeLabel: String,
    val temperatureC: Float,
    val category: ThermalZoneCategory,
)

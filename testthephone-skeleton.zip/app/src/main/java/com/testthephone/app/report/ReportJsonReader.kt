package com.testthephone.app.report

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.io.File

/**
 * ReportJsonWriter'ın tersi: bir rapor JSON dosyasını okuyup, Geçmiş
 * ekranının (ReportDetailScreen) ihtiyaç duyduğu kısmı geri kurar.
 *
 * BİLİNÇLİ SINIRLAMA: timeseries[] dizisini (binlerce satırlık asıl
 * ölçüm verisi) MetricsSnapshot nesnelerine geri parse ETMİYORUZ.
 * Bu veri AI/teknik servis tüketimi için tasarlandı, uygulama içi
 * özet ekranı sadece test başına summary + status + temel zaman
 * bilgisini gösteriyor — timeseries'i geri kurmak hem gereksiz
 * bellek/CPU maliyeti getirir hem de UI'nin hiç kullanmayacağı bir
 * veriyi ayrıştırmak anlamına gelir. Bu yüzden dönen TestResult
 * nesnelerinde timeseries her zaman boş liste olur; bu, "veri yok"
 * değil "burada gösterilmiyor" anlamına gelir.
 *
 * Ayrıştırma hataya toleranslı: beklenmeyen/eksik bir alanla
 * karşılaşınca tüm okumayı çökertmek yerine o alanı null/varsayılan
 * bırakır — eski bir report_version'dan gelen dosya da (şema ileride
 * değişirse) makul ölçüde okunabilsin diye.
 */
class ReportJsonReader {

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun readSummary(file: File): ParsedSessionSummary? = withContext(Dispatchers.IO) {
        if (!file.exists()) return@withContext null

        runCatching {
            val root = json.parseToJsonElement(file.readText()).jsonObject
            parseRoot(root)
        }.getOrNull()
    }

    private fun parseRoot(root: JsonObject): ParsedSessionSummary {
        val sessionId = root["test_session_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val deviceProfile = root["device_profile"]?.jsonObject
        // deviceLabel boş/null olabilir — bu durumda ekranda ne
        // göstereceğine dair karar composable katmanına bırakılıyor
        // (lokalize bir "Bilinmeyen cihaz" string'i burada, composable
        // olmayan bir sınıfta stringResource() ile üretilemez). Çağıran
        // taraf (MainActivity) null/boş durumunda kendi lokalize
        // fallback'ini kullanmalı.
        val deviceLabel = deviceProfile?.let {
            val manufacturer = it["manufacturer"]?.jsonPrimitive?.contentOrNull.orEmpty()
            val model = it["model"]?.jsonPrimitive?.contentOrNull.orEmpty()
            "$manufacturer $model".trim()
        }?.takeIf { it.isNotBlank() }

        val tests = root["tests"]?.jsonArray
            ?.mapNotNull { parseTestResult(it) }
            ?: emptyList()

        val safetyEventCount = root["safety_events"]?.jsonArray?.size ?: 0

        val generatedAtMillis = root["generated_at_utc_millis"]?.jsonPrimitive?.longOrNull

        return ParsedSessionSummary(
            sessionId = sessionId,
            deviceLabel = deviceLabel,
            results = tests,
            safetyEventCount = safetyEventCount,
            generatedAtMillis = generatedAtMillis,
        )
    }

    private fun parseTestResult(element: JsonElement): TestResult? {
        val obj = element.jsonObject
        val testId = obj["test_id"]?.jsonPrimitive?.contentOrNull ?: return null

        val statusRaw = obj["status"]?.jsonPrimitive?.contentOrNull?.uppercase()
        val status = runCatching { TestStatus.valueOf(statusRaw ?: "") }
            .getOrDefault(TestStatus.NOT_STARTED)

        val summary = obj["summary"]?.jsonObject
            ?.mapNotNull { (key, value) ->
                value.jsonPrimitive.doubleOrNull?.let { key to it }
            }
            ?.toMap()
            ?: emptyMap()

        val summaryLabels = obj["summary_labels"]?.jsonObject
            ?.mapNotNull { (key, value) ->
                value.jsonPrimitive.contentOrNull?.let { key to it }
            }
            ?.toMap()
            ?: emptyMap()

        return TestResult(
            testId = testId,
            status = status,
            startedAtUtcMillis = obj["started_at_utc_millis"]?.jsonPrimitive?.longOrNull,
            endedAtUtcMillis = obj["ended_at_utc_millis"]?.jsonPrimitive?.longOrNull,
            abortReason = obj["abort_reason"]?.jsonPrimitive?.contentOrNull,
            timeseries = mutableListOf(), // Bilinçli olarak boş — yukarıdaki not.
            summary = summary,
            summaryLabels = summaryLabels,
        )
    }
}

data class ParsedSessionSummary(
    val sessionId: String,
    val deviceLabel: String?,
    val results: List<TestResult>,
    val safetyEventCount: Int,
    val generatedAtMillis: Long?,
)

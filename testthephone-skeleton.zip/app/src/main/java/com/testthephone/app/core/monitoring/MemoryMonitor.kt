package com.testthephone.app.core.monitoring

import android.app.ActivityManager
import android.content.Context
import android.os.Debug

/**
 * RAM kullanımı ve GC baskısı — Kotlin/Android'de "hissedilen akıcılığı"
 * en çok etkileyen ama çoğu benchmark uygulamasının atladığı metrik.
 * Sık GC duraklamaları, ham FPS düşmese bile oyunlarda "stutter" hissi
 * yaratır; bu yüzden sürdürülebilir performans testinde bu veriyi
 * frame time jitter ile birlikte yorumlamak gerekiyor.
 */
class MemoryMonitor(private val context: Context) {

    private val activityManager = context.applicationContext
        .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun snapshot(): MemorySnapshot {
        val debugMemInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(debugMemInfo)

        val appMemInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(appMemInfo)

        return MemorySnapshot(
            appUsedMb = certain(
                debugMemInfo.totalPss / 1024f,
                "Debug.MemoryInfo.totalPss",
            ),
            systemAvailableMb = certain(
                appMemInfo.availMem / (1024f * 1024f),
                "ActivityManager.MemoryInfo.availMem",
            ),
            systemTotalMb = certain(
                appMemInfo.totalMem / (1024f * 1024f),
                "ActivityManager.MemoryInfo.totalMem",
            ),
            systemLowMemory = certain(
                appMemInfo.lowMemory,
                "ActivityManager.MemoryInfo.lowMemory",
            ),
        )
    }

    /**
     * Runtime.getRuntime() GC istatistiklerini doğrudan vermez; bunun yerine
     * Debug.getRuntimeStat ile dolaylı sayaçlar okunur. Bu değerler süreç
     * başlangıcından beri kümülatiftir — çağıran taraf iki örnekleme
     * arasındaki farkı alarak test penceresi içindeki GC olay sayısını
     * hesaplamalı.
     */
    fun cumulativeGcPauseCount(): MeasuredValue<Int> {
        val raw = runCatching {
            Debug.getRuntimeStat("art.gc.gc-count")
        }.getOrNull()?.toIntOrNull()

        return bestEffort(raw, "Debug.getRuntimeStat(art.gc.gc-count)")
    }
}

data class MemorySnapshot(
    val appUsedMb: MeasuredValue<Float>,
    val systemAvailableMb: MeasuredValue<Float>,
    val systemTotalMb: MeasuredValue<Float>,
    val systemLowMemory: MeasuredValue<Boolean>,
)

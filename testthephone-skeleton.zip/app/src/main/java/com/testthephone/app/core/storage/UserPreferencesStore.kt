package com.testthephone.app.core.storage

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "test_the_phone_prefs")

/**
 * Uygulama genelinde kalıcı olması gereken basit tercihler: EULA onayı
 * (versiyon numarasıyla — EULA metni değişirse eski onay geçersiz
 * sayılmalı), dil ve tema seçimi. Test oturumu geçmişi BURADA değil,
 * ayrı bir SessionHistoryStore'da (JSON dosyaları olarak) tutulacak
 * çünkü DataStore büyük/karmaşık veri için uygun değil.
 */
class UserPreferencesStore(context: Context) {

    private val dataStore = context.applicationContext.dataStore

    companion object {
        private val KEY_EULA_ACCEPTED_VERSION = stringPreferencesKey("eula_accepted_version")
        private val KEY_LANGUAGE_CODE = stringPreferencesKey("language_code")
        private val KEY_DARK_THEME_ENABLED = booleanPreferencesKey("dark_theme_enabled")
        private val KEY_ROOT_MODE_ENABLED = booleanPreferencesKey("root_mode_enabled")

        /**
         * EULA metninin mevcut versiyonu. Metin değiştiğinde bu artırılmalı
         * — böylece daha önce onay vermiş kullanıcılara, yeni koşulları
         * onaylamaları için EULA ekranı tekrar gösterilir. Bu, "eski
         * onay yeni metni kapsamıyor" hukuki tutarsızlığını önler.
         */
        const val CURRENT_EULA_VERSION = "1.0"
    }

    /** True, eğer kullanıcı MEVCUT versiyondaki EULA'yı onayladıysa. */
    fun isEulaAccepted(): Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_EULA_ACCEPTED_VERSION] == CURRENT_EULA_VERSION
    }

    suspend fun setEulaAccepted() {
        dataStore.edit { prefs -> prefs[KEY_EULA_ACCEPTED_VERSION] = CURRENT_EULA_VERSION }
    }

    fun languageCode(): Flow<String?> = dataStore.data.map { it[KEY_LANGUAGE_CODE] }

    suspend fun setLanguageCode(code: String) {
        dataStore.edit { prefs -> prefs[KEY_LANGUAGE_CODE] = code }
    }

    fun darkThemeEnabled(): Flow<Boolean?> = dataStore.data.map { it[KEY_DARK_THEME_ENABLED] }

    suspend fun setDarkThemeEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_DARK_THEME_ENABLED] = enabled }
    }

    /**
     * Root modu — best-effort root termal okumasının kullanılmasına
     * kullanıcının açıkça izin verip vermediği. Varsayılan false:
     * root okuması istemsizce, kullanıcı bilgisi olmadan devreye
     * girmemeli.
     */
    fun rootModeEnabled(): Flow<Boolean> = dataStore.data.map { it[KEY_ROOT_MODE_ENABLED] ?: false }

    suspend fun setRootModeEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_ROOT_MODE_ENABLED] = enabled }
    }
}

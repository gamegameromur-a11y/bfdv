package com.testthephone.app.tests.image

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.TestExecutionContext
import com.testthephone.app.tests.TestProgressEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Test 4: telefonun kademe kademe artan çözünürlüklü bir görüntüyü
 * işleme kapasitesi. Her adımda çözünürlük artırılır, aynı görüntü
 * üzerinde box blur + Sobel edge detection art arda uygulanır ve
 * işlem süresi ölçülür.
 *
 * Entity testlerinden farklı olarak burada "FPS/frame time" değil,
 * "tek işlem süresi" ölçülüyor — bu, oyun senaryosundan farklı bir
 * iş yükü türünü (tek seferlik, büyük hesaplama, örn. fotoğraf
 * filtresi uygulama) temsil ediyor. Eşik de buna göre farklı: 30 FPS
 * karşılığı değil, "makul kullanıcı bekleme süresi" olarak 2 saniye
 * seçildi — bir kullanıcının fotoğraf filtresi için makul kabul
 * edebileceği üst sınır.
 *
 * Bellek kullanımı burada özellikle kritik: yüksek çözünürlükte
 * IntArray tabanlı piksel matrisleri (kaynak + blur çıktısı + edge
 * çıktısı) aynı anda bellekte tutulduğu için, bu test RAM baskısını
 * entity testlerinden çok daha belirgin şekilde ortaya çıkarır.
 */
class ProgressiveImageTestEngine(
    private val metricsCollector: MetricsCollector,
) : TestEngine {

    override val testId = "progressive_image_processing"
    override val displayNameKey = "test_progressive_image_name"

    private val processingTimeThresholdMs = 2000f
    private val consecutiveFailureThreshold = 2

    // Kademeli çözünürlük basamakları — kare görüntü varsayılıyor,
    // basitlik için. Gerçek fotoğraflardaki en/boy oranı farklılığı
    // test sonucunu etkilemez çünkü ölçülen şey piksel başına maliyet.
    //
    // Üst sınır 4096 DEĞİL: 4096x4096 IntArray ~67MB'a karşılık gelir,
    // kaynak+blur+edge aynı anda bellekte olduğunda düşük RAM'li
    // cihazlarda OutOfMemoryError riski taşır — bu, "cihaza zarar
    // vermeyelim" ilkesiyle doğrudan çelişir. Bu yüzden üst basamak
    // 2048 ile sınırlandı ve her adımda kalibrasyonun RAM bilgisine
    // göre daha da daraltılabilir hale getirildi (bkz. resolutionStepsFor).
    private val defaultResolutionSteps = listOf(
        128, 192, 256, 384, 512, 768, 1024, 1536, 2048,
    )

    /**
     * Düşük RAM'li cihazlarda (örn. 3GB altı) en yüksek basamağı daha da
     * kısıtlar — OutOfMemoryError'a karşı somut bir önlem, sadece
     * "umarım olmaz" değil.
     */
    private fun resolutionStepsFor(totalRamMb: Int): List<Int> = when {
        totalRamMb < 3072 -> defaultResolutionSteps.filter { it <= 1024 }
        totalRamMb < 6144 -> defaultResolutionSteps.filter { it <= 1536 }
        else -> defaultResolutionSteps
    }

    override fun run(context: TestExecutionContext): Flow<TestProgressEvent> = flow {
        var consecutiveFailures = 0
        var lastStableResolution = 0
        val startTime = System.currentTimeMillis()
        val resolutionSteps = resolutionStepsFor(context.calibration.totalRamMb)

        for (resolution in resolutionSteps) {
            val decision = context.safetyDecision.value
            if (decision == SafetyDecision.PAUSE_REQUIRED) {
                emit(TestProgressEvent.Paused(reason = "thermal_critical"))
                return@flow
            }

            // OutOfMemoryError'a karşı son bir güvenlik ağı: yukarıdaki
            // RAM'e göre basamak filtrelemesi normalde bunu engeller,
            // ama beklenmedik bellek baskısı (başka uygulamalar, sistem
            // durumu) yaşanırsa test çökmesin, güvenli şekilde tamamlansın.
            var oomHit = false
            val (blurTimeMs, edgeTimeMs, checksum) = try {
                val bitmap = SyntheticImageGenerator.generate(resolution, resolution)
                val sourcePixels = ClassicImageFilters.bitmapToPixelArray(bitmap)
                bitmap.recycle()

                val stepStart = System.nanoTime()
                val blurred = ClassicImageFilters.boxBlur3x3(sourcePixels, resolution, resolution)
                val blurEnd = System.nanoTime()
                val edges = ClassicImageFilters.sobelEdgeDetection(blurred, resolution, resolution)
                val edgeEnd = System.nanoTime()

                val blur = (blurEnd - stepStart) / 1_000_000f
                val edge = (edgeEnd - blurEnd) / 1_000_000f
                // edges kullanılmıyor gibi görünse de, JIT/derleyicinin
                // hesaplamayı "gereksiz" diye eleyip atlamasını önlemek
                // için bilinçli olarak referansı tutuyoruz (checksum'a dahil).
                val sum = edges.fold(0L) { acc, px -> acc + (px and 0xFF) }
                Triple(blur, edge, sum)
            } catch (oom: OutOfMemoryError) {
                oomHit = true
                Triple(0f, 0f, 0L)
            }

            // emit() çağrısını try/catch bloğunun DIŞINDA tutuyoruz —
            // Flow builder'da catch bloğu içinden emit yapmak flow
            // invariant'ını ihlal edebilir; bu yüzden sonucu bayrakla
            // taşıyıp burada işliyoruz.
            if (oomHit) {
                emit(
                    TestProgressEvent.Completed(
                        summary = mapOf(
                            "max_stable_resolution_px" to lastStableResolution.toDouble(),
                            "stopped_reason_out_of_memory" to 1.0,
                            "total_duration_ms" to (System.currentTimeMillis() - startTime).toDouble(),
                        )
                    )
                )
                return@flow
            }

            val totalTimeMs = blurTimeMs + edgeTimeMs

            val elapsedMs = System.currentTimeMillis() - startTime
            val snapshot = metricsCollector.snapshot(
                elapsedMs = elapsedMs,
                testSpecific = mapOf(
                    "image_resolution_px" to resolution.toDouble(),
                    "blur_time_ms" to blurTimeMs.toDouble(),
                    "edge_detection_time_ms" to edgeTimeMs.toDouble(),
                    "total_processing_time_ms" to totalTimeMs.toDouble(),
                    "result_checksum" to checksum.toDouble(),
                ),
            )
            emit(TestProgressEvent.Sample(snapshot))

            if (totalTimeMs > processingTimeThresholdMs) {
                consecutiveFailures++
                if (consecutiveFailures >= consecutiveFailureThreshold) {
                    emit(
                        TestProgressEvent.Completed(
                            summary = mapOf(
                                "max_stable_resolution_px" to lastStableResolution.toDouble(),
                                "failure_threshold_ms" to processingTimeThresholdMs.toDouble(),
                                "total_duration_ms" to elapsedMs.toDouble(),
                            )
                        )
                    )
                    return@flow
                }
            } else {
                consecutiveFailures = 0
                lastStableResolution = resolution
            }
        }

        emit(
            TestProgressEvent.Completed(
                summary = mapOf(
                    "max_stable_resolution_px" to lastStableResolution.toDouble(),
                    "reached_max_resolution_step" to 1.0,
                )
            )
        )
    }
}

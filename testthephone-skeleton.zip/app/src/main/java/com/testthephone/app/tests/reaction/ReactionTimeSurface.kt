package com.testthephone.app.tests.reaction

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * ReactionTimeTestController'ın Compose render/input katmanı. GpuStressCanvas
 * ile aynı desende: doğrudan bir TestEngine değil, kontrolcüyü sarıp
 * gerçek kullanıcı dokunmasını ve arka plan yükünü Compose'un frame
 * döngüsüne bağlayan katman.
 *
 * Hedefin görünme zamanlaması bilinçli olarak rastgele (600ms-1800ms
 * arası) tutulur — sabit bir zamanlama kullanıcının "tahmin ederek"
 * erken dokunmasına, yani gerçek tepki süresini değil öngörüyü
 * ölçmesine yol açar.
 */
@Composable
fun ReactionTimeSurface(
    controller: ReactionTimeTestController,
    modifier: Modifier = Modifier,
) {
    val uiState by controller.state.collectAsState()

    var targetOffsetXDp by remember { mutableStateOf(0.dp) }
    var targetOffsetYDp by remember { mutableStateOf(0.dp) }

    // Arka plan yükünü her frame'de ilerlet — entity testlerindeki
    // withFrameMillis desenine paralel.
    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis { controller.stepBackgroundLoad() }
        }
    }

    // Hedefi rastgele gecikmeyle göster; kullanıcı önceki hedefe
    // dokununca kontrolcü otomatik olarak yeni bir tur başlatır
    // (targetVisible false olduğunda burada yeni gecikme planlanır).
    LaunchedEffect(uiState.targetVisible, uiState.finished) {
        if (!uiState.finished && !uiState.targetVisible) {
            val delayMs = Random.nextLong(600, 1800)
            delay(delayMs)
            targetOffsetXDp = Random.nextInt(20, 300).dp
            targetOffsetYDp = Random.nextInt(20, 500).dp
            controller.onTargetShown()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(uiState.targetVisible) {
                detectTapGestures {
                    if (uiState.targetVisible) {
                        controller.onTargetTapped()
                    }
                }
            },
    ) {
        if (uiState.targetVisible) {
            Box(
                modifier = Modifier
                    .offset(x = targetOffsetXDp, y = targetOffsetYDp)
                    .size(56.dp)
                    .background(color = Color(0xFFEF9F27), shape = CircleShape),
            )
        }
    }
}

package com.testthephone.app.core.safety

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ThermalMonitor'dan gelen ham okumaları, testlerin uyması gereken
 * somut bir karara çevirir. Bu sınıf test motorlarından bağımsız —
 * her test (entity spawn, GPU, vs.) aynı SafetyController'ı kullanır,
 * böylece güvenlik mantığı tek bir yerde yaşar ve tutarlı davranır.
 *
 * Eşik mantığı:
 *  - NONE / LIGHT / MODERATE  -> RUNNING, yük artmaya devam edebilir
 *  - SEVERE                    -> RUNNING ama yük artışı durdurulur
 *                                  (mevcut seviyede sabitlenir)
 *  - CRITICAL veya üzeri        -> PAUSE_REQUIRED, test derhal duraklatılır
 *
 * "Mavi ekran seviyesine gelmeden dur" hedefi CRITICAL eşiğiyle
 * karşılanıyor: EMERGENCY/SHUTDOWN'a gelmeden, ondan bir adım önce
 * müdahale ediyoruz, çünkü o noktaya kadar beklemek riskin ta kendisi.
 */
class SafetyController(
    private val thermalMonitor: ThermalMonitor,
) {
    private val _state = MutableStateFlow(SafetyState.initial())
    val state: StateFlow<SafetyState> = _state.asStateFlow()

    /**
     * Yeni bir termal okuma geldiğinde çağrılır (ThermalMonitor.statusChanges
     * akışını toplayan çağıran taraf tarafından). Kararı günceller ve
     * safety_events kaydı için gerekli bilgiyi üretir.
     */
    fun onThermalReading(reading: ThermalReading): SafetyDecision {
        val previousDecision = _state.value.decision
        val newDecision = decisionFor(reading)

        _state.value = _state.value.copy(
            lastReading = reading,
            decision = newDecision,
        )

        val transitioned = previousDecision != newDecision
        if (transitioned && newDecision == SafetyDecision.PAUSE_REQUIRED) {
            recordSafetyEvent(reading)
        }
        return newDecision
    }

    private fun decisionFor(reading: ThermalReading): SafetyDecision = when {
        !reading.supported -> SafetyDecision.RUNNING_UNMONITORED
        reading.status.severity >= ThermalStatus.CRITICAL.severity -> SafetyDecision.PAUSE_REQUIRED
        reading.status == ThermalStatus.SEVERE -> SafetyDecision.RUNNING_CAPPED
        else -> SafetyDecision.RUNNING
    }

    private fun recordSafetyEvent(reading: ThermalReading) {
        val event = SafetyEvent(
            timestampMs = System.currentTimeMillis(),
            triggerThermalStatus = reading.status,
            headroomAtTrigger = reading.headroom,
        )
        _state.value = _state.value.copy(
            events = _state.value.events + event,
        )
    }

    /** Kullanıcı "soğuyunca devam et" seçtiğinde çağrılır. */
    fun requestResume() {
        val reading = _state.value.lastReading
        if (reading != null && decisionFor(reading) != SafetyDecision.PAUSE_REQUIRED) {
            _state.value = _state.value.copy(decision = SafetyDecision.RUNNING)
        }
        // Eğer hâlâ kritik seviyedeyse, resume isteği sessizce reddedilir;
        // arayüz kullanıcıya "hâlâ soğumadı" göstermeli.
    }
}

enum class SafetyDecision {
    /** Normal çalışma, yük artırılabilir. */
    RUNNING,
    /** Termal API desteklenmiyor; test devam ediyor ama izlemesiz — rapora işlenmeli. */
    RUNNING_UNMONITORED,
    /** SEVERE seviyesinde: yük artırma durduruldu, mevcut seviye korunuyor. */
    RUNNING_CAPPED,
    /** CRITICAL veya üzeri: test derhal duraklatılmalı. */
    PAUSE_REQUIRED,
}

data class SafetyState(
    val lastReading: ThermalReading?,
    val decision: SafetyDecision,
    val events: List<SafetyEvent>,
) {
    companion object {
        fun initial() = SafetyState(
            lastReading = null,
            decision = SafetyDecision.RUNNING,
            events = emptyList(),
        )
    }
}

data class SafetyEvent(
    val timestampMs: Long,
    val triggerThermalStatus: ThermalStatus,
    val headroomAtTrigger: Float?,
)

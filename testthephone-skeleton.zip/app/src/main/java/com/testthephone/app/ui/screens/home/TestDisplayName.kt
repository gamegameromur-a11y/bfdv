package com.testthephone.app.ui.screens.home

import com.testthephone.app.R

/**
 * Test motorlarının kullandığı ham testId (örn. "entity_spawn_capacity")
 * ile kullanıcıya gösterilecek lokalize isim arasındaki TEK eşleme
 * kaynağı. Hem ana ekran kataloğunda (TestCatalogEntry), hem test
 * ilerleme ekranının başlığında (AppRoot), hem de rapor detay ekranında
 * (ReportDetailScreen, JSON'dan geri okunan testId'ler için) aynı
 * fonksiyon kullanılır — testId yazım hatası riski tek noktaya iner.
 */
fun testDisplayNameRes(testId: String): Int = when (testId) {
    "entity_spawn_capacity" -> R.string.test_entity_spawn_capacity_name
    "interactive_simulation_capacity" -> R.string.test_interactive_simulation_name
    "gpu_render" -> R.string.test_gpu_render_name
    "progressive_image_processing" -> R.string.test_progressive_image_name
    "sustained_performance" -> R.string.test_sustained_performance_name
    "multicore_parallel_workload" -> R.string.test_multicore_workload_name
    "reaction_time_under_load" -> R.string.test_reaction_time_name
    // ÖNEMLİ GÖSTERGE HATASI DÜZELTMESİ: önceden bilinmeyen bir testId
    // için R.string.test_entity_spawn_capacity_name (yani rastgele başka
    // bir GERÇEK testin adı) gösteriliyordu. "Pratikte hiç oluşmamalı"
    // olsa da, ileride yeni bir test eklenip bu eşlemeye unutulmadan
    // eklenmezse, kullanıcı yanlışlıkla o testin sonucunu farklı bir
    // testin sonucuymuş gibi görürdü — bu, rapor doğruluğunu zedeleyen
    // sessiz bir yanlış bilgilendirme olurdu. Artık nötr, dürüst bir
    // "Bilinmeyen Test" etiketi gösteriliyor.
    else -> R.string.test_unknown_name
}

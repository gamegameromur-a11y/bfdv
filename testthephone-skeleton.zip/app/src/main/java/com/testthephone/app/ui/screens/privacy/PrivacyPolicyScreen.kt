package com.testthephone.app.ui.screens.privacy

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.ui.theme.AppColors

/**
 * Gizlilik Politikası — EULA'dan (kullanım koşulları/sorumluluk) BİLEREK
 * ayrı bir belge. EULA "kullanırken ne kabul ediyorsunuz", bu ekran
 * "hangi veri toplanıyor, nerede kalıyor, kiminle paylaşılıyor" sorusuna
 * cevap veriyor.
 *
 * İçerik gerçek verilerle tutarlı yazıldı: uygulama gerçekten network
 * isteği atmıyor, test verileri sadece cihazda kalıyor ve yalnızca
 * kullanıcı kendisi "JSON'u paylaş" dediğinde dışarı çıkıyor. Bu, Play
 * Console Data Safety formunda beyan edeceğimiz şeyle birebir tutarlı
 * olmalı.
 *
 * ÖNEMLİ: Bu da EULA gibi bir taslak. Yayın öncesi gözden geçirilmeli.
 */
@Composable
fun PrivacyPolicyScreen(onClose: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(vertical = 20.dp),
        ) {
            item {
                Text(
                    text = stringResource(R.string.privacy_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = AppColors.TextPrimary,
                )
                Text(
                    text = stringResource(R.string.privacy_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = AppColors.TextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
                )
            }

            items(privacySectionResourceIds) { section ->
                PrivacySectionBlock(section)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
        ) {
            Button(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AppColors.FillPrimary,
                    contentColor = AppColors.OnPrimary,
                ),
            ) {
                Text(text = stringResource(R.string.generic_close))
            }
        }
    }
}

@Composable
private fun PrivacySectionBlock(section: PrivacySectionRes) {
    Column(modifier = Modifier.padding(bottom = 16.dp)) {
        Text(
            text = "${section.number}. ${stringResource(section.titleRes)}",
            style = MaterialTheme.typography.titleMedium,
            color = AppColors.TextPrimary,
            fontWeight = FontWeight.Medium,
        )
        Text(
            text = stringResource(section.bodyRes),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextSecondary,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

data class PrivacySectionRes(val number: Int, val titleRes: Int, val bodyRes: Int)

private val privacySectionResourceIds = listOf(
    PrivacySectionRes(1, R.string.privacy_section_1_title, R.string.privacy_section_1_body),
    PrivacySectionRes(2, R.string.privacy_section_2_title, R.string.privacy_section_2_body),
    PrivacySectionRes(3, R.string.privacy_section_3_title, R.string.privacy_section_3_body),
    PrivacySectionRes(4, R.string.privacy_section_4_title, R.string.privacy_section_4_body),
    PrivacySectionRes(5, R.string.privacy_section_5_title, R.string.privacy_section_5_body),
    PrivacySectionRes(6, R.string.privacy_section_6_title, R.string.privacy_section_6_body),
    PrivacySectionRes(7, R.string.privacy_section_7_title, R.string.privacy_section_7_body),
    PrivacySectionRes(8, R.string.privacy_section_8_title, R.string.privacy_section_8_body),
)

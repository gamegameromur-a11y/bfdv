package com.testthephone.app.ui.screens.testrun

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.ui.theme.AppColors

/**
 * Önceki mockup'ta tasarladığımız "kritik durum" ekranının gerçek
 * implementasyonu. TestRunner.RunnerState.PausedForThermal durumunda
 * gösterilir. Kırmızı sadece kenarlık + metinde — arka planı boğmuyor,
 * "alarm hissi var ama panik hissi yok" ilkesine sadık.
 *
 * "Soğuyunca devam et" seçeneği kullanıcı tıkladığında hemen devam
 * ETMEYEBİLİR — SafetyController hâlâ kritik seviyedeyse resumeFromPause
 * sessizce hiçbir şey yapmaz (bkz. TestRunner). Bu yüzden bu ekran,
 * onResumeRequested çağrıldıktan sonra hâlâ PausedForThermal state'inde
 * kalınırsa, "hâlâ soğumadı" bilgisini ayrıca göstermeli — bu mantık
 * çağıran ViewModel katmanında (isStillTooHot parametresi) yönetilir.
 */
@Composable
fun ThermalPauseScreen(
    isStillTooHot: Boolean,
    onResumeRequested: () -> Unit,
    onEndTestRequested: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
            .background(color = AppColors.Surface2, shape = RoundedCornerShape(16.dp))
            .border(width = 1.dp, color = AppColors.BorderDanger, shape = RoundedCornerShape(16.dp))
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "⚠", color = AppColors.TextDanger)
            Text(
                text = stringResource(R.string.pause_title),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextDanger,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 10.dp),
            )
        }

        Text(
            text = if (isStillTooHot) {
                stringResource(R.string.pause_still_hot)
            } else {
                stringResource(R.string.pause_cooled_down)
            },
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextSecondary,
            modifier = Modifier.padding(top = 12.dp, bottom = 20.dp),
        )

        Row {
            OutlinedButton(
                onClick = onEndTestRequested,
                modifier = Modifier.weight(1f),
            ) {
                Text(text = stringResource(R.string.pause_end_test))
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onResumeRequested,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AppColors.FillPrimary,
                    contentColor = AppColors.OnPrimary,
                ),
            ) {
                Text(text = stringResource(R.string.pause_resume))
            }
        }
    }
}

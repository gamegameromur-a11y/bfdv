package com.testthephone.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import com.testthephone.app.R
import com.testthephone.app.ui.theme.AppColors

/**
 * Kararlaştırdığımız 3 sekmeli alt navigasyon: Ana sayfa / Geçmiş /
 * Ayarlar. Test akış ekranları (FullTestRun, SingleTest, ReportDetail,
 * EulaConsent) bilinçli olarak bu navigasyonun DIŞINDA — bunlar tam
 * ekran akışlar, alt navigasyon çubuğuyla birlikte gösterilmemeli.
 *
 * BottomNavTab enum'ının kendisi bir @StringRes Int taşır (composable
 * olmayan bir enum sabiti içinde stringResource() çağrılamaz) — gerçek
 * metne burada, composable context'inde çevrilir.
 */
@Composable
fun BottomNavBar(
    currentTab: BottomNavTab,
    onTabSelected: (BottomNavTab) -> Unit,
) {
    NavigationBar(containerColor = AppColors.Surface2) {
        BottomNavTab.entries.forEach { tab ->
            NavigationBarItem(
                selected = currentTab == tab,
                onClick = { onTabSelected(tab) },
                icon = { Icon(imageVector = tab.icon, contentDescription = null) },
                label = { Text(text = stringResource(tab.labelRes)) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AppColors.TextPrimary,
                    selectedTextColor = AppColors.TextPrimary,
                    unselectedIconColor = AppColors.TextMuted,
                    unselectedTextColor = AppColors.TextMuted,
                    indicatorColor = AppColors.Surface1,
                ),
            )
        }
    }
}

enum class BottomNavTab(val labelRes: Int, val icon: ImageVector) {
    HOME(R.string.nav_home, Icons.Filled.Home),
    HISTORY(R.string.nav_history, Icons.Filled.History),
    SETTINGS(R.string.nav_settings, Icons.Filled.Settings),
}

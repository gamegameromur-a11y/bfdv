package com.testthephone.app.tests.entityspawn

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.TestExecutionContext
import com.testthephone.app.tests.TestProgressEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Test 1: telefon en fazla kaç entity spawn edebilir (statik kapasite).
 *
 * Yöntem: entity sayısını cihaza göre kalibre edilmiş adımlarla artırır,
 * her adımda birkaç frame boyunca EntitySimulationStep.stepStatic
 * çalıştırıp gerçek frame time'ı ölçer. Frame time eşiği (33ms ~ 30 FPS
 * altı) art arda aşıldığında, bir önceki stabil entity sayısı "maksimum
 * stabil kapasite" olarak kaydedilir.
 *
 * Bu sınıf render (ekrana çizim) yapmaz — saf hesaplama kapasitesini
 * ölçer. Gerçek ekran render yükü UI katmanında (Compose Canvas)
 * ayrıca eklenecek; bu ayrım bilinçli, çünkü "kaç entity hesaplanabilir"
 * ile "kaç entity çizilebilir" farklı darboğazlar, ikisini karıştırmak
 * raporun teşhis değerini düşürür.
 */
class EntitySpawnTestEngine(
    private val metricsCollector: MetricsCollector,
    private val boundsWidth: Float = 1080f,
    private val boundsHeight: Float = 2400f,
) : TestEngine {

    override val testId = "entity_spawn_capacity"
    override val displayNameKey = "test_entity_spawn_capacity_name"

    // Ardışık kaç adım frame time eşiğini aşarsa test sonlandırılır.
    // Tek seferlik bir jitter'ı gerçek darboğazdan ayırmak için >1.
    private val consecutiveFailureThreshold = 3

    // 30 FPS karşılığı ~33.3ms. Bu, "kabul edilebilir performans" sınırı
    // olarak seçildi — oyun/etkileşim senaryolarında yaygın referans.
    private val frameTimeThresholdMs = 33.3f

    // Her entity sayısı adımında kaç frame ölçülüp ortalaması alınacak.
    private val framesPerStep = 20

    override fun run(context: TestExecutionContext): Flow<TestProgressEvent> = flow {
        val calibration = context.calibration
        val simulationStep = EntitySimulationStep(boundsWidth, boundsHeight)
        val entities = mutableListOf<Entity>()

        var currentTarget = calibration.initialEntityCount
        var consecutiveFailures = 0
        var lastStableCount = 0
        val startTime = System.currentTimeMillis()

        while (currentTarget <= calibration.maxEntityCountCap) {
            // Güvenlik kararını her adımda kontrol et — testin kendi
            // hızından bağımsız, dışarıdan gelen en güncel karar.
            val decision = context.safetyDecision.value
            if (decision == SafetyDecision.PAUSE_REQUIRED) {
                emit(TestProgressEvent.Paused(reason = "thermal_critical"))
                return@flow
            }

            // Yeni entity'leri hedefe kadar ekle.
            while (entities.size < currentTarget) {
                entities.add(Entity.spawnRandom(boundsWidth, boundsHeight, interactive = false))
            }

            // Bu adımda framesPerStep kadar frame ölç, ortalama frame time hesapla.
            val frameTimes = FloatArray(framesPerStep)
            for (f in 0 until framesPerStep) {
                val frameStart = System.nanoTime()
                simulationStep.stepStatic(entities)
                val frameEnd = System.nanoTime()
                frameTimes[f] = (frameEnd - frameStart) / 1_000_000f
            }
            val avgFrameTimeMs = frameTimes.average().toFloat()
            val jitterMs = (frameTimes.maxOrNull()!! - frameTimes.minOrNull()!!)

            val elapsedMs = System.currentTimeMillis() - startTime
            val snapshot = metricsCollector.snapshot(
                elapsedMs = elapsedMs,
                testSpecific = mapOf(
                    "entity_count" to currentTarget.toDouble(),
                    "frame_time_ms" to avgFrameTimeMs.toDouble(),
                    "frame_time_jitter_ms" to jitterMs.toDouble(),
                    "fps" to (1000.0 / avgFrameTimeMs.coerceAtLeast(0.001f)),
                ),
            )
            emit(TestProgressEvent.Sample(snapshot))

            if (avgFrameTimeMs > frameTimeThresholdMs) {
                consecutiveFailures++
                if (consecutiveFailures >= consecutiveFailureThreshold) {
                    emit(
                        TestProgressEvent.Completed(
                            summary = mapOf(
                                "max_stable_entities" to lastStableCount.toDouble(),
                                "failure_threshold" to frameTimeThresholdMs.toDouble(),
                                "total_duration_ms" to elapsedMs.toDouble(),
                            )
                        )
                    )
                    return@flow
                }
            } else {
                consecutiveFailures = 0
                lastStableCount = currentTarget
            }

            currentTarget += calibration.entityCountStep
        }

        // Kalibrasyon tavanına (maxEntityCountCap) sorunsuz ulaşıldıysa,
        // bu da geçerli bir sonuç — cihaz bu testte hiç zorlanmadı demektir.
        emit(
            TestProgressEvent.Completed(
                summary = mapOf(
                    "max_stable_entities" to lastStableCount.toDouble(),
                    "failure_threshold" to frameTimeThresholdMs.toDouble(),
                    "reached_calibration_cap" to 1.0,
                )
            )
        )
    }
}

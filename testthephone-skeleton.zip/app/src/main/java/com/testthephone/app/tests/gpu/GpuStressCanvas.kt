package com.testthephone.app.tests.gpu

import android.graphics.RuntimeShader
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.random.Random

/**
 * Test 3'ün görsel/render katmanı. TestEngine arayüzüne UYMAZ çünkü GPU
 * testi doğası gereği Compose'un kendi render döngüsüne (withFrameMillis)
 * bağlı çalışmak zorunda — arka planda soyut bir hesaplama döngüsü
 * olarak koşturulamaz, gerçek render pipeline'ının kendisi ölçülüyor.
 *
 * Bu yüzden GPU testi ayrı bir composable olarak yaşar; TestRunner
 * onu diğer testlerle aynı arayüzden çağırmaz, UI katmanında ayrı
 * bir "GPU test ekranı" olarak barındırılır ve sonuçları aynı
 * TestResult/MetricsSnapshot modeline yazılır (rapor şeması tutarlı kalır).
 *
 * onFrameMeasured callback'i her frame'de çağrılır — çağıran taraf
 * (ViewModel) bunu MetricsCollector.snapshot() ile birleştirip
 * TestResult.timeseries'e ekler, tıpkı diğer testlerde olduğu gibi.
 */
@Composable
fun GpuStressCanvas(
    mode: GpuTestMode,
    currentStep: GpuLoadStep,
    modifier: Modifier = Modifier,
    onFrameMeasured: (frameTimeMs: Float, stepIndex: Int) -> Unit,
) {
    var elapsedTime by remember { mutableStateOf(0f) }

    val shader = remember(mode) {
        if (mode == GpuTestMode.AGSL_SHADER) {
            runCatching { RuntimeShader(GpuStressShader.SOURCE) }.getOrNull()
        } else null
    }

    // Canvas fallback modunda kullanılacak, çerçeveler arasında sabit
    // kalan rastgele şekil parametreleri — her frame yeniden rastgele
    // üretmek gerçek maliyeti bozar, bu yüzden şekil sayısı değiştiğinde
    // yeniden üretilir.
    var fallbackShapes by remember { mutableStateOf(generateFallbackShapes(currentStep.canvasShapeCount)) }

    LaunchedEffect(currentStep.canvasShapeCount) {
        if (mode == GpuTestMode.CANVAS_FALLBACK) {
            fallbackShapes = generateFallbackShapes(currentStep.canvasShapeCount)
        }
    }

    Canvas(modifier = modifier) {
        val frameStartNanos = System.nanoTime()

        when (mode) {
            GpuTestMode.AGSL_SHADER -> {
                if (shader != null) {
                    shader.setFloatUniform("resolution", size.width, size.height)
                    shader.setFloatUniform("iterations", currentStep.shaderIterations)
                    shader.setFloatUniform("time", elapsedTime)
                    drawRect(brush = ShaderBrush(shader))
                } else {
                    // Shader oluşturulamadıysa (beklenmedik cihaz kısıtlaması),
                    // sessizce fallback'e düş — test çökmemeli.
                    drawFallbackShapes(fallbackShapes)
                }
            }
            GpuTestMode.CANVAS_FALLBACK -> {
                drawFallbackShapes(fallbackShapes)
            }
        }

        val frameEndNanos = System.nanoTime()
        val frameTimeMs = (frameEndNanos - frameStartNanos) / 1_000_000f
        onFrameMeasured(frameTimeMs, currentStep.stepIndex)
    }

    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis { frameTimeMillis ->
                elapsedTime = frameTimeMillis / 1000f
            }
        }
    }
}

private fun generateFallbackShapes(count: Int): List<FallbackShape> =
    List(count) {
        FallbackShape(
            centerXFraction = Random.nextFloat(),
            centerYFraction = Random.nextFloat(),
            radiusFraction = 0.01f + Random.nextFloat() * 0.04f,
            hue = Random.nextFloat() * 360f,
        )
    }

private data class FallbackShape(
    val centerXFraction: Float,
    val centerYFraction: Float,
    val radiusFraction: Float,
    val hue: Float,
)

/**
 * API 33 altı cihazlar için: çok sayıda yarı saydam, örtüşen daire
 * çizerek GPU'nun overdraw/compositing kapasitesini zorlar. Bu, gerçek
 * oyunlarda parçacık efektleri (particle systems) gibi yaygın bir
 * render yükünü temsil eder — AGSL kadar "saf hesaplama" değil ama
 * gerçekçi bir GPU darboğazı senaryosu.
 */
private fun DrawScope.drawFallbackShapes(shapes: List<FallbackShape>) {
    shapes.forEach { shape ->
        val color = Color.hsv(shape.hue, 0.7f, 0.9f, alpha = 0.35f)
        drawCircle(
            color = color,
            radius = shape.radiusFraction * size.minDimension,
            center = Offset(
                x = shape.centerXFraction * size.width,
                y = shape.centerYFraction * size.height,
            ),
        )
    }
}

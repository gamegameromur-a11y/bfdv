package com.testthephone.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.lifecycleScope
import com.testthephone.app.R
import com.testthephone.app.core.monitoring.BatteryMonitor
import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.ThermalMonitor
import com.testthephone.app.core.safety.TestWakeLockManager
import com.testthephone.app.core.safety.integrity.RootBeerIntegrityChecker
import com.testthephone.app.core.storage.SessionHistoryStore
import com.testthephone.app.core.storage.SessionSummary
import com.testthephone.app.core.storage.UserPreferencesStore
import com.testthephone.app.report.DeviceProfiler
import com.testthephone.app.report.EnvironmentSnapshot
import com.testthephone.app.report.ReportJsonReader
import com.testthephone.app.report.RunnerState
import com.testthephone.app.report.TestResult
import com.testthephone.app.report.TestRunner
import com.testthephone.app.report.TestSession
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.entityspawn.EntitySpawnTestEngine
import com.testthephone.app.tests.entityspawn.InteractiveSimulationTestEngine
import com.testthephone.app.tests.image.ProgressiveImageTestEngine
import com.testthephone.app.tests.multicore.MultiCoreWorkloadTestEngine
import com.testthephone.app.tests.sustained.SustainedPerformanceTestEngine
import com.testthephone.app.ui.AppRoot
import com.testthephone.app.ui.screens.home.TestCatalogEntry
import com.testthephone.app.ui.screens.report.ReportLoadState
import com.testthephone.app.ui.screens.testrun.GpuTestScreen
import com.testthephone.app.ui.screens.testrun.ReactionTimeTestScreen
import com.testthephone.app.ui.theme.TestThePhoneTheme
import kotlinx.coroutines.launch

/**
 * Bu iki testId, TestEngine sözleşmesine UYMAYAN özel testler için
 * ayrılmış sabitler — engines listesindeki testId'lerle karışmamalı.
 * onSelectSingleTest bu id'leri gördüğünde normal TestRunner akışı
 * yerine GPU/tepki süresi ekranlarını açar.
 */
private const val TEST_ID_GPU_RENDER = "gpu_render"
private const val TEST_ID_REACTION_TIME = "reaction_time_under_load"

/**
 * Testleri, güvenlik katmanını, kalıcılık katmanını (DataStore + dosya
 * tabanlı oturum geçmişi) ve raporu kuran, sonucu AppRoot'a bağlayan
 * giriş noktası. Test 3 (GPU) ve Test 7 (tepki süresi), TestEngine
 * sözleşmesine uymadıkları için activeSpecialTestId durumu üzerinden,
 * AppRoot'un activeSpecialTestContent slot'una bağlanır.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val thermalMonitor = ThermalMonitor(applicationContext)
        val metricsCollector = MetricsCollector(applicationContext)
        val batteryMonitor = BatteryMonitor(applicationContext)
        val deviceProfiler = DeviceProfiler(applicationContext)
        val integrityChecker = RootBeerIntegrityChecker(applicationContext)
        val preferencesStore = UserPreferencesStore(applicationContext)
        val historyStore = SessionHistoryStore(applicationContext)
        val reportJsonReader = ReportJsonReader()
        val wakeLockManager = TestWakeLockManager(applicationContext)

        val deviceProfile = deviceProfiler.collect(integrityChecker)
        val calibration = deviceProfiler.calibrationFor(
            cpuCoreCount = deviceProfile.cpuCoreCount,
            ramTotalMb = deviceProfile.ramTotalMb.toInt(),
        )

        val startBattery = batteryMonitor.snapshot()
        val startThermal = thermalMonitor.currentStatus()

        val session = TestSession(
            appVersion = "0.1.0-dev",
            deviceProfile = deviceProfile,
            environmentSnapshot = EnvironmentSnapshot(
                batteryTempCStart = startBattery.temperatureC.value,
                batteryLevelPctStart = startBattery.levelPct.value,
                thermalStatusStart = startThermal.status.name,
            ),
        )

        val testRunner = TestRunner(
            thermalMonitor = thermalMonitor,
            session = session,
            scope = lifecycleScope,
            wakeLockManager = wakeLockManager,
        )

        // Her fabrika, priorResults (o ana kadar tamamlanmış testlerin
        // testId -> summary eşlemesi) alıp gerçek TestEngine'i üretir.
        // Bu, adaptif zinciri gerçek kılıyor:
        //  - Test 2, Test 1'in "max_stable_entities" sonucunu referans alır.
        //  - Test 5, Test 1 veya Test 2'nin (hangisi varsa) sonucunu
        //    referans alır — Test 2 daha spesifik olduğu için önceliklidir.
        // Tek test seçildiğinde (onSelectSingleTest ile) priorResults boş
        // gelir; bu durumda motorlar kendi kalibrasyon tabanlı
        // varsayılanlarına düşer (bkz. ilgili sınıfların içindeki
        // "referenceEntityCount > 0" kontrolleri) — çökme riski yok.
        val engineFactories: List<(Map<String, Map<String, Double>>) -> TestEngine> = listOf(
            { EntitySpawnTestEngine(metricsCollector) },
            { priorResults ->
                val staticCapacity = priorResults["entity_spawn_capacity"]
                    ?.get("max_stable_entities")?.toInt() ?: 0
                InteractiveSimulationTestEngine(metricsCollector, staticCapacityHint = staticCapacity)
            },
            { ProgressiveImageTestEngine(metricsCollector) },
            { priorResults ->
                val referenceCount = priorResults["interactive_simulation_capacity"]
                    ?.get("max_stable_interactive_entities")?.toInt()
                    ?: priorResults["entity_spawn_capacity"]?.get("max_stable_entities")?.toInt()
                    ?: 0
                SustainedPerformanceTestEngine(metricsCollector, referenceEntityCount = referenceCount)
            },
            { MultiCoreWorkloadTestEngine(metricsCollector) },
        )

        val testCatalog = listOf(
            TestCatalogEntry("entity_spawn_capacity", R.string.test_entity_spawn_capacity_name, 3),
            TestCatalogEntry("interactive_simulation_capacity", R.string.test_interactive_simulation_name, 4),
            TestCatalogEntry("gpu_render", R.string.test_gpu_render_name, 3),
            TestCatalogEntry("progressive_image_processing", R.string.test_progressive_image_name, 3),
            TestCatalogEntry("sustained_performance", R.string.test_sustained_performance_name, 10),
            TestCatalogEntry("multicore_parallel_workload", R.string.test_multicore_workload_name, 3),
            TestCatalogEntry("reaction_time_under_load", R.string.test_reaction_time_name, 2),
        )

        setContent {
            val darkThemeEnabled by preferencesStore.darkThemeEnabled().collectAsState(initial = null)

            // İLK AÇILIŞ / TERCİH BELİRTİLMEMİŞSE: koyu tema varsayılan.
            // Önceden null durumunda false (açık tema) varsayılıyordu.
            TestThePhoneTheme(darkTheme = darkThemeEnabled ?: true) {
                val runnerState by testRunner.runnerState.collectAsState()
                val latestSnapshot by testRunner.latestSnapshot.collectAsState()
                // null = henüz DataStore'dan okunmadı; bu durumda EULA'yı
                // yanlışlıkla atlamamak için "kabul edilmemiş" varsayılır
                // (aşağıdaki eulaAcceptedResolved).
                val eulaAccepted by preferencesStore.isEulaAccepted()
                    .collectAsState(initial = null)

                var sessions by remember { mutableStateOf<List<SessionSummary>>(emptyList()) }
                var activeSpecialTestId by remember { mutableStateOf<String?>(null) }
                var selectedSessionId by remember { mutableStateOf<String?>(null) }
                var loadedReportState by remember { mutableStateOf<ReportLoadState?>(null) }

                val languageCode by preferencesStore.languageCode().collectAsState(initial = null)
                val rootModeEnabled by preferencesStore.rootModeEnabled().collectAsState(initial = false)

                // DataStore'daki dil tercihini gerçek uygulama diline uygular.
                // AppCompatDelegate.setApplicationLocales, API 33+'ta framework'ün
                // per-app language desteğiyle otomatik entegre olur (Activity
                // yeniden oluşturulur, Compose recomposition'ı strings.xml'in
                // doğru values-XX klasöründen okumasını sağlar); altında
                // AppCompat'ın kendi mekanizmasını kullanır — tek çağrı her iki
                // durumu da kapsar.
                //
                // İLK AÇILIŞ DAVRANIŞI: kullanıcı henüz bir dil seçmediyse
                // (languageCode == null), sistem/cihaz diline DOKUNMAK yerine
                // bilinçli olarak İngilizce'yi uyguluyoruz. Önceden bu durumda
                // hiçbir şey yapılmıyordu, bu da cihaz dili örn. Türkçe olan bir
                // kullanıcıyı "sistem dili desteklenen 8 dilden biriyse onu
                // göster" mantığıyla karşılıyordu (bkz. aşağıdaki
                // currentLanguageCode hesaplaması) — istenen ilk-açılış deneyimi
                // bu değil, her zaman İngilizce ile karşılamak.
                LaunchedEffect(languageCode) {
                    val code = languageCode ?: "en"
                    val currentLocales = AppCompatDelegate.getApplicationLocales()
                    val alreadyApplied = !currentLocales.isEmpty &&
                        currentLocales.toLanguageTags().startsWith(code)
                    if (!alreadyApplied) {
                        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
                    }
                }

                LaunchedEffect(Unit) {
                    sessions = historyStore.listSessionSummaries()
                }
                LaunchedEffect(runnerState) {
                    if (runnerState.toString().contains("AllCompleted")) {
                        sessions = historyStore.listSessionSummaries()
                    }
                }

                val eulaAcceptedResolved = eulaAccepted == true

                // Rapor detay ekranı: seçili oturum AKTİF oturumsa (bu
                // Activity ömrü boyunca bellekte tutulan `session`),
                // dosya IO'ya hiç gerek yok, doğrudan bellekten gösteriyoruz
                // — hem daha hızlı hem de henüz diske yazılmamış olabilecek
                // en güncel veriyi (örn. timeseries) yansıtır. Geçmişten
                // farklı bir eski oturum seçilirse, ReportJsonReader ile
                // JSON dosyasından asenkron olarak gerçek özet okunuyor.
                val unknownDeviceLabel = androidx.compose.ui.res.stringResource(R.string.unknown_device)

                LaunchedEffect(selectedSessionId) {
                    val sessionId = selectedSessionId
                    if (sessionId == null) {
                        loadedReportState = null
                        return@LaunchedEffect
                    }

                    if (sessionId == session.sessionId) {
                        loadedReportState = ReportLoadState.Loaded(
                            deviceLabel = "${session.deviceProfile.manufacturer} ${session.deviceProfile.model}",
                            results = session.tests.toList(),
                            safetyEventCount = session.safetyEvents.size,
                        )
                        return@LaunchedEffect
                    }

                    loadedReportState = ReportLoadState.Loading
                    val parsed = reportJsonReader.readSummary(historyStore.sessionFile(sessionId))
                    loadedReportState = if (parsed != null) {
                        ReportLoadState.Loaded(
                            deviceLabel = parsed.deviceLabel ?: unknownDeviceLabel,
                            results = parsed.results,
                            safetyEventCount = parsed.safetyEventCount,
                        )
                    } else {
                        ReportLoadState.Error
                    }
                }
                val selectedReportState = loadedReportState

                // GPU/tepki süresi testi seçiliyse, AppRoot'un slot'unu
                // dolduracak composable'ı burada kuruyoruz — bu testler
                // TestEngine sözleşmesine uymadığı için MetricsCollector,
                // safetyDecisionFlow gibi bağımlılıklara doğrudan burada,
                // MainActivity katmanında erişiyoruz.
                val specialTestContent: (@Composable () -> Unit)? = when (activeSpecialTestId) {
                    TEST_ID_GPU_RENDER -> {
                        {
                            val result = remember { TestResult(testId = TEST_ID_GPU_RENDER) }
                            LaunchedEffect(Unit) { testRunner.registerExternalTestResult(result) }
                            // DisposableEffect: ekran kurulduğunda WakeLock alınır,
                            // hangi sebeple olursa olsun (onFinished, geri tuşu,
                            // recomposition) ekran terk edildiğinde onDispose ile
                            // bırakılır — onFinished'a güvenmek yetmez çünkü
                            // kullanıcı sistem geri tuşuyla da çıkabilir.
                            androidx.compose.runtime.DisposableEffect(Unit) {
                                wakeLockManager.acquire()
                                onDispose { wakeLockManager.release() }
                            }
                            GpuTestScreen(
                                metricsCollector = metricsCollector,
                                safetyDecision = testRunner.safetyDecisionFlow,
                                result = result,
                                onFinished = {
                                    testRunner.syncSafetyEvents()
                                    activeSpecialTestId = null
                                },
                            )
                        }
                    }
                    TEST_ID_REACTION_TIME -> {
                        {
                            val result = remember { TestResult(testId = TEST_ID_REACTION_TIME) }
                            LaunchedEffect(Unit) { testRunner.registerExternalTestResult(result) }
                            androidx.compose.runtime.DisposableEffect(Unit) {
                                wakeLockManager.acquire()
                                onDispose { wakeLockManager.release() }
                            }
                            ReactionTimeTestScreen(
                                metricsCollector = metricsCollector,
                                safetyDecision = testRunner.safetyDecisionFlow,
                                result = result,
                                cpuCoreCount = deviceProfile.cpuCoreCount,
                                onFinished = {
                                    testRunner.syncSafetyEvents()
                                    activeSpecialTestId = null
                                },
                            )
                        }
                    }
                    else -> null
                }

                AppRoot(
                    deviceProfile = session.deviceProfile,
                    batteryLevelPct = startBattery.levelPct.value,
                    batteryTempC = startBattery.temperatureC.value,
                    runnerState = runnerState,
                    latestSnapshot = latestSnapshot,
                    testCatalog = testCatalog,
                    eulaAccepted = eulaAcceptedResolved,
                    sessions = sessions,
                    // languageCode null ise (henüz seçim yapılmamış), yukarıdaki
                    // LaunchedEffect zaten uygulama dilini İngilizce'ye
                    // ayarlıyor — burada da tutarlı olması için "en" varsayılıyor.
                    currentLanguageCode = languageCode ?: "en",
                    darkThemeEnabled = darkThemeEnabled ?: true,
                    rootModeEnabled = rootModeEnabled,
                    currentSafetyDecision = testRunner.safetyDecisionFlow.collectAsState().value,
                    activeSpecialTestContent = specialTestContent,
                    selectedReportState = selectedReportState,
                    onAcceptEula = {
                        lifecycleScope.launch { preferencesStore.setEulaAccepted() }
                    },
                    onDeclineEula = {
                        finish()
                    },
                    onStartFullTest = { testRunner.runAll(engineFactories, calibration) },
                    onSelectSingleTest = { testId ->
                        if (testId == TEST_ID_GPU_RENDER || testId == TEST_ID_REACTION_TIME) {
                            activeSpecialTestId = testId
                        } else {
                            // Tek test seçiminde fabrikayı boş priorResults ile
                            // çağırıp testId'sine bakıyoruz — bu ucuz bir işlem
                            // (sadece constructor), gerçek test henüz başlamıyor.
                            // Eşleşen fabrika bulunursa, tek elemanlı bir liste
                            // olarak çalıştırılır; boş priorResults geçtiği için
                            // motor kendi kalibrasyon tabanlı varsayılanına düşer.
                            val matchingFactory = engineFactories.firstOrNull { factory ->
                                factory(emptyMap()).testId == testId
                            }
                            if (matchingFactory != null) {
                                testRunner.runAll(listOf(matchingFactory), calibration)
                            }
                        }
                    },
                    onResumeFromThermalPause = {
                        // runnerState PausedForThermal ise testIndex, DURAKLAYAN
                        // testin sırasını taşır — kaldığımız testten (dahil)
                        // itibaren devam etmeliyiz, baştan değil. Aksi halde
                        // "soğuyunca devam et" tüm diziyi sıfırdan çalıştırırdı,
                        // bu hem gereksiz hem de daha önce tamamlanmış test
                        // sonuçlarının session.tests'e TEKRAR eklenmesine yol açardı.
                        val paused = runnerState as? RunnerState.PausedForThermal
                        val remainingFactories = if (paused != null) {
                            engineFactories.drop(paused.testIndex)
                        } else {
                            engineFactories
                        }
                        testRunner.resumeFromPause(remainingFactories, calibration)
                    },
                    onEndTestRun = {
                        lifecycleScope.launch {
                            historyStore.saveSession(session)
                            sessions = historyStore.listSessionSummaries()
                        }
                    },
                    onSessionClick = { sessionId -> selectedSessionId = sessionId },
                    onCloseReportDetail = { selectedSessionId = null },
                    onShareReportJson = {
                        selectedSessionId?.let { sessionId ->
                            shareReportFile(historyStore.sessionFile(sessionId))
                        }
                    },
                    onDeleteReportSession = {
                        val sessionId = selectedSessionId
                        if (sessionId != null) {
                            lifecycleScope.launch {
                                historyStore.deleteSession(sessionId)
                                sessions = historyStore.listSessionSummaries()
                            }
                        }
                    },
                    onLanguageSelected = { code ->
                        // DataStore'a yazmak yeterli — yukarıdaki
                        // LaunchedEffect(languageCode) bu değişikliği
                        // otomatik yakalayıp AppCompatDelegate'e uygular.
                        lifecycleScope.launch { preferencesStore.setLanguageCode(code) }
                    },
                    onDarkThemeToggled = { enabled ->
                        lifecycleScope.launch { preferencesStore.setDarkThemeEnabled(enabled) }
                    },
                    onRootModeToggled = { enabled ->
                        lifecycleScope.launch { preferencesStore.setRootModeEnabled(enabled) }
                    },
                )
            }
        }
    }

    /**
     * Rapor JSON dosyasını Android'in paylaşım sayfası (Intent.ACTION_SEND)
     * üzerinden dışa aktarır — kullanıcı bunu e-posta, mesajlaşma veya
     * "cihaza kaydet" gibi herhangi bir hedefe gönderebilir. FileProvider
     * (AndroidManifest.xml + res/xml/file_paths.xml) kurulu olduğu için
     * ham file:// URI yerine güvenli content:// URI kullanılıyor.
     */
    private fun shareReportFile(file: java.io.File) {
        if (!file.exists()) return
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this,
            "$packageName.fileprovider",
            file,
        )
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(android.content.Intent.createChooser(intent, "Raporu paylaş"))
    }
}

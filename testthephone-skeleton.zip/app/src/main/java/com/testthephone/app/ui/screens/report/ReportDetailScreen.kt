package com.testthephone.app.ui.screens.report

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.report.TestResult
import com.testthephone.app.report.TestStatus
import com.testthephone.app.ui.components.MetricText
import com.testthephone.app.ui.screens.home.testDisplayNameRes
import com.testthephone.app.ui.theme.AppColors

/**
 * Tamamlanan bir oturumun özet ekranı. Ham JSON'u (binlerce satır)
 * doğrudan göstermiyoruz — o AI/teknik servis için tasarlandı, insan
 * okuması için değil (bkz. önceki karar). Bunun yerine her testin
 * summary alanından üretilmiş kısa, okunabilir bir özet gösteriyoruz.
 * "JSON'u paylaş" butonu, dosyanın tamamını (teknik detay isteyenler
 * için) dışa aktarır.
 *
 * loadState, dosya IO asenkron olduğu için üç durumu ayırt eder:
 * Loading (dosya henüz okunmadı), Loaded (parse edildi), Error (dosya
 * bulunamadı/bozuk — kullanıcıya sessizce boş ekran göstermek yerine
 * açıkça bildirilir).
 */
@Composable
fun ReportDetailScreen(
    loadState: ReportLoadState,
    onShareJson: () -> Unit,
    onDeleteSession: () -> Unit,
) {
    when (loadState) {
        is ReportLoadState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppColors.TextPrimary)
            }
        }
        is ReportLoadState.Error -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = stringResource(R.string.report_load_error),
                    style = MaterialTheme.typography.bodyMedium,
                    color = AppColors.TextMuted,
                )
            }
        }
        is ReportLoadState.Loaded -> {
            Column(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 18.dp),
                    contentPadding = PaddingValues(vertical = 20.dp),
                ) {
                    item {
                        Text(
                            text = stringResource(R.string.report_title),
                            style = MaterialTheme.typography.headlineSmall,
                            color = AppColors.TextPrimary,
                        )
                        Text(
                            text = "${loadState.deviceLabel} · ${loadState.results.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = AppColors.TextMuted,
                            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp),
                        )
                    }

                    items(loadState.results) { result ->
                        TestResultCard(result = result, modifier = Modifier.padding(bottom = 10.dp))
                    }

                    if (loadState.safetyEventCount > 0) {
                        item {
                            Text(
                                text = stringResource(R.string.report_safety_events, loadState.safetyEventCount),
                                style = MaterialTheme.typography.bodySmall,
                                color = AppColors.TextDanger,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = onDeleteSession,
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(text = stringResource(R.string.report_delete))
                    }
                    Button(
                        onClick = onShareJson,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AppColors.FillPrimary,
                            contentColor = AppColors.OnPrimary,
                        ),
                    ) {
                        Text(text = stringResource(R.string.report_share_json))
                    }
                }
            }
        }
    }
}

@Composable
private fun TestResultCard(result: TestResult, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(color = AppColors.Surface1, shape = RoundedCornerShape(10.dp))
            .padding(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = stringResource(testDisplayNameRes(result.testId)),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextPrimary,
                fontWeight = FontWeight.Medium,
            )
            StatusLabel(status = result.status)
        }

        // Her testin en anlamlı 1-2 özet değerini göstermek için basit
        // bir öncelik listesi — tüm summary map'ini dökmek yerine.
        val highlightKeys = listOf(
            "max_stable_entities", "max_stable_interactive_entities",
            "max_stable_resolution_px", "max_stable_gpu_step",
            "sustained_to_burst_ratio", "reaction_time_avg_ms",
        )
        result.summary.entries
            .filter { it.key in highlightKeys }
            .take(2)
            .forEach { (key, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = summaryLabelRes(key)?.let { stringResource(it) } ?: key.replace('_', ' '),
                        style = MaterialTheme.typography.bodySmall,
                        color = AppColors.TextMuted,
                    )
                    MetricText(
                        text = "%.1f".format(value),
                        color = AppColors.TextSecondary,
                    )
                }
            }
    }
}

@Composable
private fun StatusLabel(status: TestStatus) {
    val (labelRes, color) = when (status) {
        TestStatus.COMPLETED -> R.string.report_status_completed to AppColors.StatusCalmEnd
        TestStatus.PAUSED -> R.string.report_status_paused to AppColors.StatusWarningEnd
        TestStatus.ABORTED -> R.string.report_status_aborted to AppColors.TextDanger
        TestStatus.RUNNING -> R.string.report_status_running to AppColors.TextSecondary
        TestStatus.SKIPPED -> R.string.report_status_skipped to AppColors.TextMuted
        TestStatus.NOT_STARTED -> R.string.report_status_not_started to AppColors.TextMuted
    }
    Text(text = stringResource(labelRes), style = MaterialTheme.typography.bodySmall, color = color)
}

/**
 * Test motorlarının summary Map<String, Double> içinde ürettiği teknik
 * JSON anahtarlarını (örn. "max_stable_entities") kullanıcı dostu,
 * lokalize etiketlere eşler. Yeni bir teste yeni bir summary alanı
 * eklendiğinde burada bir karşılık eklenmezse, çağıran taraf anahtarı
 * ham haliyle (alt çizgiler boşlukla değiştirilmiş) gösterir — bu,
 * çeviri eksikliğinde uygulamanın çökmesi yerine zarif bir fallback.
 */
private fun summaryLabelRes(key: String): Int? = when (key) {
    "max_stable_entities" -> R.string.summary_max_stable_entities
    "max_stable_interactive_entities" -> R.string.summary_max_stable_interactive_entities
    "max_stable_resolution_px" -> R.string.summary_max_stable_resolution_px
    "max_stable_gpu_step" -> R.string.summary_max_stable_gpu_step
    "sustained_to_burst_ratio" -> R.string.summary_sustained_to_burst_ratio
    "reaction_time_avg_ms" -> R.string.summary_reaction_time_avg_ms
    else -> null
}

/** ReportDetailScreen'in yükleme durumu — dosya IO asenkron olduğu için. */
sealed interface ReportLoadState {
    data object Loading : ReportLoadState
    data object Error : ReportLoadState
    data class Loaded(
        val deviceLabel: String,
        val results: List<TestResult>,
        val safetyEventCount: Int,
    ) : ReportLoadState
}

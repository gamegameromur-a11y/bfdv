package com.testthephone.app.tests.multicore

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.TestExecutionContext
import com.testthephone.app.tests.TestProgressEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Test 6: Multi-core paralel iş yükü — oyun motorlarının fizik/AI
 * thread'lerini simüle eden bir yaklaşım. Aynı işi tek çekirdekte
 * (baseline) ve artan sayıda paralel çekirdekte (Dispatchers.Default,
 * Kotlin coroutines) çalıştırıp paralel verim (speedup) ölçer.
 *
 * "En klasik hesaplama mantığı" burada da geçerli: her paralel görev,
 * bağımsız bir parçacık grubu üzerinde konum/hız güncellemesi + basit
 * trigonometrik hesaplama yapıyor — gerçek bir fizik motorunun paralel
 * dünya simülasyonu adımının basitleştirilmiş hali.
 *
 * Sonuç, "N çekirdek kullanınca gerçekte kaç kat hızlanıyor" sorusuna
 * cevap verir — ideal durumda N kat, gerçekte hep daha az (senkronizasyon,
 * bellek bant genişliği, thermal throttling gibi etkenlerden ötürü).
 * Bu oran (parallel efficiency), cihazın çoklu görev/arka plan işleme
 * kapasitesi hakkında entity testlerinden farklı bir bilgi verir.
 */
class MultiCoreWorkloadTestEngine(
    private val metricsCollector: MetricsCollector,
) : TestEngine {

    override val testId = "multicore_parallel_workload"
    override val displayNameKey = "test_multicore_workload_name"

    // Her paralel görev grubunun işleyeceği eleman sayısı — sabit tutulur,
    // böylece "toplam iş" çekirdek sayısıyla birlikte artar (gerçekçi
    // paralel ölçek senaryosu: daha fazla çekirdek = daha fazla iş
    // paralelde yapılabiliyor mu sorusu).
    private val elementsPerWorker = 50_000
    private val iterationsPerElement = 200

    override fun run(context: TestExecutionContext): Flow<TestProgressEvent> = flow {
        val maxCores = context.calibration.cpuCoreCount.coerceAtLeast(1)
        val startTime = System.currentTimeMillis()

        // Toplam test süresine bir üst sınır koyuyoruz: yüksek çekirdek
        // sayılı cihazlarda (16 çekirdek gibi) toplam iş fazla büyüyüp
        // testin süresi öngörülemez hale gelmesin diye. Bu sınıra
        // ulaşılırsa test o ana kadarki ölçümlerle tamamlanır.
        val maxTestDurationMs = 3 * 60 * 1000L // 3 dakika.

        // 1 çekirdekten (baseline) maksimum çekirdeğe kadar kademeli test.
        var baselineTimeMs: Double? = null

        for (workerCount in 1..maxCores) {
            if (System.currentTimeMillis() - startTime > maxTestDurationMs) {
                emit(
                    TestProgressEvent.Completed(
                        summary = mapOf(
                            "max_cores_tested" to (workerCount - 1).toDouble(),
                            "baseline_single_core_ms" to (baselineTimeMs ?: 0.0),
                            "stopped_reason_duration_cap" to 1.0,
                            "total_duration_ms" to (System.currentTimeMillis() - startTime).toDouble(),
                        )
                    )
                )
                return@flow
            }

            val decision = context.safetyDecision.value
            if (decision == SafetyDecision.PAUSE_REQUIRED) {
                emit(TestProgressEvent.Paused(reason = "thermal_critical"))
                return@flow
            }

            val elapsedTimeMs = measureParallelWorkload(workerCount)
            if (baselineTimeMs == null) baselineTimeMs = elapsedTimeMs

            val speedup = baselineTimeMs!! / elapsedTimeMs
            val idealSpeedup = workerCount.toDouble()
            val parallelEfficiency = speedup / idealSpeedup

            val elapsedMs = System.currentTimeMillis() - startTime
            val snapshot = metricsCollector.snapshot(
                elapsedMs = elapsedMs,
                testSpecific = mapOf(
                    "worker_count" to workerCount.toDouble(),
                    "workload_time_ms" to elapsedTimeMs,
                    "speedup_vs_single_core" to speedup,
                    "parallel_efficiency" to parallelEfficiency,
                ),
            )
            emit(TestProgressEvent.Sample(snapshot))
        }

        emit(
            TestProgressEvent.Completed(
                summary = mapOf(
                    "max_cores_tested" to maxCores.toDouble(),
                    "baseline_single_core_ms" to (baselineTimeMs ?: 0.0),
                    "total_duration_ms" to (System.currentTimeMillis() - startTime).toDouble(),
                )
            )
        )
    }

    /**
     * workerCount kadar paralel coroutine başlatır, her biri
     * elementsPerWorker kadar elemanı iterationsPerElement kez
     * işler, hepsi tamamlanana kadar bekler ve toplam süreyi döner.
     */
    private suspend fun measureParallelWorkload(workerCount: Int): Double = coroutineScope {
        val start = System.nanoTime()

        val jobs = (0 until workerCount).map { workerIndex ->
            async(Dispatchers.Default) {
                simulateParticleGroup(workerIndex, elementsPerWorker, iterationsPerElement)
            }
        }
        jobs.awaitAll()

        (System.nanoTime() - start) / 1_000_000.0
    }

    /**
     * Bir "parçacık grubu" üzerinde tekrarlayan trigonometrik + karekök
     * hesaplaması — CPU-yoğun, dallanma (branch) az, bu yüzden ölçüm
     * gürültüsü düşük ve paralel ölçeklenebilirlik net görülür.
     */
    private fun simulateParticleGroup(seedOffset: Int, elementCount: Int, iterations: Int): Double {
        var accumulator = 0.0
        for (i in 0 until elementCount) {
            var x = (i + seedOffset).toDouble()
            var y = (i * 1.3 + seedOffset).toDouble()
            repeat(iterations) {
                val nx = sin(x) * sqrt(y * y + 1.0)
                val ny = sin(y) * sqrt(x * x + 1.0)
                x = nx
                y = ny
            }
            accumulator += x + y
        }
        return accumulator // Sonucu döndürerek JIT'in hesaplamayı elemesini önlüyoruz.
    }
}

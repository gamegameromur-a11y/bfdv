package com.testthephone.app.core.monitoring

/**
 * ÖNEMLİ BUG DÜZELTMESİ: MetricsCollector.rootThermalReader alanı önceden
 * (RootThermalReader arayüzü tanımlanmış olmasına rağmen) HİÇBİR YERDE
 * atanmıyordu — Ayarlar ekranındaki "Root Modu" anahtarı DataStore'a
 * bir tercih yazıyordu ama bu tercihi gerçekten okuyup MetricsCollector'a
 * bağlayan hiçbir kod yoktu. Sonuç: kullanıcı root erişimi olan bir
 * cihazda bu anahtarı açsa bile hiçbir şey değişmiyordu —
 * cpuTempRootC her zaman "root_not_available" olarak kalıyordu. Anahtar
 * görsel olarak çalışıyor gibi görünüp fiilen işlevsizdi.
 *
 * Bu sınıf, RootThermalReader sözleşmesinin somut implementasyonu:
 * `su -c` üzerinden SABİT, KULLANICI GİRDİSİ İÇERMEYEN bir kabuk
 * komutuyla /sys/class/thermal/thermal_zone*/{type,temp} dosyalarını
 * okur — normal (root olmayan) erişimde SELinux tarafından engellenen
 * zone'lara da erişebilir. Komut sabit olduğu için (hiçbir kullanıcı
 * girdisi ya da dinamik string interpolation komut satırına
 * karışmıyor) shell injection riski taşımaz.
 *
 * "libsu" adı, projede bu iş için ayrılmış kütüphaneyi (com.github.topjohnwu.libsu)
 * çağırıyormuş gibi düşünülebilir; burada ekstra bağımlılık eklemeden,
 * doğrudan ProcessBuilder ile eşdeğer güvenli bir yol izleniyor —
 * Shell.getShell()/Shell.cmd() yerine Runtime tabanlı, ama aynı temel
 * ilkeyle (tek seferlik su -c çağrısı, timeout'lu, çıktıyı parse edip
 * anında kapatma).
 */
class LibsuRootThermalReader : RootThermalReader {

    private val thermalZoneReader = ThermalZoneReader()

    override fun readCpuTemp(): MeasuredValue<Float> = readCategory(ThermalZoneCategory.CPU)

    override fun readGpuTemp(): MeasuredValue<Float> = readCategory(ThermalZoneCategory.GPU)

    private fun readCategory(category: ThermalZoneCategory): MeasuredValue<Float> {
        // Root olmadan zaten okunabilen zone'lar varsa (bazı OEM'lerde
        // SELinux izin veriyor), gereksiz bir root shell çağrısına hiç
        // gerek yok — önce normal yoldan deniyoruz.
        val direct = thermalZoneReader.readCategory(category)
        if (direct.value != null) return direct

        val zones = runCatching { readAllZonesViaRoot() }.getOrNull()
            ?: return unavailable("root_shell:exception_or_no_su")

        val match = zones.firstOrNull { it.category == category }
            ?: return unavailable("root_shell:no_match_for_${category.name.lowercase()}")

        return certain(match.temperatureC, "root_shell:thermal_zone${match.zoneIndex}:label=${match.typeLabel}")
    }

    /**
     * Tek bir `su -c` çağrısıyla TÜM thermal_zone dizinlerini tarayıp
     * type+temp çiftlerini satır satır döndüren bir kabuk betiği
     * çalıştırır. Tek çağrıda toplu okuma tercih edildi (her zone için
     * ayrı su çağrısı yapmak hem çok daha yavaş hem her seferinde ayrı
     * bir root izni istemi/log kaydı anlamına gelirdi).
     *
     * Betik SABİTTİR — hiçbir kullanıcı/uygulama verisi komut satırına
     * enjekte edilmiyor, bu yüzden shell injection riski yoktur.
     */
    private fun readAllZonesViaRoot(): List<ThermalZoneReading> {
        val script = "for z in /sys/class/thermal/thermal_zone*; do " +
            "echo \"\$z\"; cat \"\$z/type\" 2>/dev/null; cat \"\$z/temp\" 2>/dev/null; echo '---'; " +
            "done"

        val process = ProcessBuilder("su", "-c", script)
            .redirectErrorStream(false)
            .start()

        // Root isteminin kullanıcı tarafından onaylanmasını (ya da
        // reddedilmesini) sonsuza kadar bekleyip test akışını
        // kilitlememek için makul bir zaman aşımı: kullanıcı istemi
        // görmezse/geç onaylarsa, test bu okumayı "kullanılamıyor"
        // olarak işaretleyip devam etmeli, donmamalı.
        val finished = process.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
        if (!finished) {
            process.destroyForcibly()
            return emptyList()
        }
        if (process.exitValue() != 0) return emptyList()

        val output = process.inputStream.bufferedReader().readText()
        return parseZoneOutput(output)
    }

    private fun parseZoneOutput(output: String): List<ThermalZoneReading> {
        val results = mutableListOf<ThermalZoneReading>()
        val blocks = output.split("---").map { it.trim() }.filter { it.isNotEmpty() }

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.size < 3) continue

            val zoneIndex = lines[0].substringAfterLast("thermal_zone").toIntOrNull() ?: continue
            val typeLabel = lines[1]
            val rawTemp = lines[2].toLongOrNull() ?: continue
            val tempC = if (rawTemp > 1000) rawTemp / 1000.0f else rawTemp.toFloat()

            val category = when {
                listOf("cpu", "apc", "cpuss", "tsens_tz", "core").any { typeLabel.lowercase().contains(it) } -> ThermalZoneCategory.CPU
                typeLabel.lowercase().contains("gpu") -> ThermalZoneCategory.GPU
                listOf("battery", "batt", "bms").any { typeLabel.lowercase().contains(it) } -> ThermalZoneCategory.BATTERY
                listOf("skin", "quiet").any { typeLabel.lowercase().contains(it) } -> ThermalZoneCategory.SKIN
                else -> ThermalZoneCategory.UNKNOWN
            }

            results.add(ThermalZoneReading(zoneIndex, typeLabel, tempC, category))
        }
        return results
    }
}

package com.testthephone.app.tests.gpu

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.report.TestResult
import com.testthephone.app.report.TestStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * GpuStressCanvas'ın çağırdığı onFrameMeasured callback'ini toplayıp
 * "bu adımda kaç frame ölçüldü, ortalama frame time ne, eşik aşıldı mı"
 * kararını veren kontrolcü. TestRunner'daki EntitySpawnTestEngine'in
 * mantığıyla PARALEL ama Compose'un kendi render döngüsüne bağlı
 * çalıştığı için ayrı bir sınıf.
 *
 * SafetyController'a olan bağımlılık aynı: her adımda mevcut
 * SafetyDecision kontrol edilir, PAUSE_REQUIRED gelirse test durur.
 */
class GpuTestController(
    private val metricsCollector: MetricsCollector,
    private val safetyDecision: StateFlow<SafetyDecision>,
    private val result: TestResult,
) {
    private val calibrator = GpuLoadCalibrator(
        GpuTierHint(cpuCoreCount = Runtime.getRuntime().availableProcessors())
    )
    private val mode = GpuTestModeSelector.select()

    private val framesPerStep = 30
    private val frameTimeThresholdMs = 33.3f
    private val consecutiveFailureThreshold = 3

    private var stepIndex = 0
    private var framesInCurrentStep = mutableListOf<Float>()
    private var consecutiveFailures = 0
    private var lastStableStep = 0
    private val startTime = System.currentTimeMillis()

    private val _state = MutableStateFlow(
        GpuTestUiState(mode = mode, currentStep = calibrator.stepFor(0), finished = false)
    )
    val state: StateFlow<GpuTestUiState> = _state.asStateFlow()

    init {
        result.status = TestStatus.RUNNING
        result.startedAtUtcMillis = System.currentTimeMillis()
    }

    /**
     * GpuStressCanvas'ın her frame'de çağırdığı geri bildirim.
     * framesPerStep kadar örnek toplanınca adım değerlendirilir.
     */
    fun onFrame(frameTimeMs: Float, frameStepIndex: Int) {
        if (_state.value.finished) return

        if (safetyDecision.value == SafetyDecision.PAUSE_REQUIRED) {
            finishAsPaused()
            return
        }

        if (frameStepIndex != stepIndex) return // Adım geçişi sırasında gelen eski frame'i yok say.

        framesInCurrentStep.add(frameTimeMs)
        if (framesInCurrentStep.size < framesPerStep) return

        val avgFrameTimeMs = framesInCurrentStep.average().toFloat()
        val jitterMs = framesInCurrentStep.max() - framesInCurrentStep.min()
        val elapsedMs = System.currentTimeMillis() - startTime

        val currentGpuStep = calibrator.stepFor(stepIndex)
        val snapshot = metricsCollector.snapshot(
            elapsedMs = elapsedMs,
            testSpecific = mapOf(
                "gpu_load_step_index" to stepIndex.toDouble(),
                "shader_iterations" to currentGpuStep.shaderIterations.toDouble(),
                "canvas_shape_count" to currentGpuStep.canvasShapeCount.toDouble(),
                "frame_time_ms" to avgFrameTimeMs.toDouble(),
                "frame_time_jitter_ms" to jitterMs.toDouble(),
                "fps" to (1000.0 / avgFrameTimeMs.coerceAtLeast(0.001f)),
            ),
        )
        result.timeseries.add(snapshot)

        if (avgFrameTimeMs > frameTimeThresholdMs) {
            consecutiveFailures++
            if (consecutiveFailures >= consecutiveFailureThreshold) {
                finishAsCompleted(elapsedMs)
                return
            }
        } else {
            consecutiveFailures = 0
            lastStableStep = stepIndex
        }

        stepIndex++
        framesInCurrentStep = mutableListOf()
        _state.value = _state.value.copy(currentStep = calibrator.stepFor(stepIndex))
    }

    private fun finishAsCompleted(elapsedMs: Long) {
        result.status = TestStatus.COMPLETED
        result.endedAtUtcMillis = System.currentTimeMillis()
        result.summary = mapOf(
            "max_stable_gpu_step" to lastStableStep.toDouble(),
            "failure_threshold_ms" to frameTimeThresholdMs.toDouble(),
            "total_duration_ms" to elapsedMs.toDouble(),
        )
        result.summaryLabels = mapOf(
            "render_mode" to if (mode == GpuTestMode.AGSL_SHADER) "agsl_shader" else "canvas_fallback",
        )
        _state.value = _state.value.copy(finished = true)
    }

    private fun finishAsPaused() {
        result.status = TestStatus.PAUSED
        result.abortReason = "thermal_critical"
        result.endedAtUtcMillis = System.currentTimeMillis()
        _state.value = _state.value.copy(finished = true, paused = true)
    }
}

data class GpuTestUiState(
    val mode: GpuTestMode,
    val currentStep: GpuLoadStep,
    val finished: Boolean,
    val paused: Boolean = false,
)

package com.testthephone.app.ui.screens.testrun

import com.testthephone.app.R
import com.testthephone.app.core.monitoring.MetricsSnapshot
import java.util.Locale

/**
 * ÖNEMLİ TUTARLILIK BUG DÜZELTMESİ: "%.1f".format(it) gibi çağrılar
 * (Kotlin'in String.format extension'ı), örtük olarak
 * Locale.getDefault() — yani CİHAZIN SİSTEM DİLİNİ — kullanır. Bazı
 * dillerde (Almanca, Rusça, birçok Avrupa dili) ondalık ayırıcı virgüldür
 * ("36,5"), nokta değil. Bu dosyadaki 4 ayrı format çağrısı (fps, frame
 * time, sıcaklık, cpu%) hepsi bu şekilde cihazın sistem locale'ine
 * bağlıydı — uygulamanın kendi iç dil tercihine değil (bkz.
 * HistoryScreen.kt'deki aynı sınıf bug için önceki tur gerekçesi).
 * Test ilerleme ekranındaki bu rakamlar SANİYEDE BİRKAÇ KEZ güncellenen
 * canlı metrikler olduğu için, kullanıcı test sırasında sürekli bunları
 * izliyor — tutarsız ondalık gösterimi (bir metrik "36.5", diğeri
 * yanlışlıkla "36,5" gibi karışık) fark edilmesi kolay bir cila
 * sorunu olurdu.
 *
 * Locale.US ile SABİTLİYORUZ (dile göre değişmeyen, hep nokta ondalık
 * ayırıcı) — bu, performans/teknik uygulamalarda yaygın ve kabul gören
 * bir yaklaşım: rakamlar evrensel/tutarlı kalır, sadece çevredeki metin
 * (etiketler) lokalize olur. Kullanıcının dil tercihini format()'a kadar
 * taşımak (composable olmayan bu extension fonksiyonuna languageCode
 * parametresi eklemek) çok daha büyük bir refactor gerektirirdi;
 * Locale.US sabitlemesi aynı tutarlılık garantisini çok daha az
 * karmaşıklıkla veriyor.
 */
private fun formatMetric(pattern: String, value: Float): String =
    String.format(Locale.US, pattern, value)

/**
 * MetricsSnapshot ile TestProgressScreen'in beklediği sade LiveMetric
 * listesi arasındaki köprü. UI katmanı confidence/source bilgisiyle
 * ilgilenmiyor — o detay sadece JSON raporunda kalıyor, ekranda sadece
 * "değer" ve "bu değer dikkat mi gerektiriyor" gösterilir.
 *
 * Bu fonksiyon composable DEĞİL (normal bir Kotlin extension'ı), bu
 * yüzden stringResource() çağıramaz — etiketler ve (termal durum gibi
 * kendisi de bir metin olan) değerler @StringRes Int id olarak taşınır,
 * gerçek metne TestProgressScreen içinde (composable context'te)
 * çevrilir.
 */
fun MetricsSnapshot.toLiveMetrics(): List<LiveMetric> {
    val metrics = mutableListOf<LiveMetric>()

    testSpecificValues["entity_count"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_entity_count, value = it.toInt().toString()))
    }
    testSpecificValues["fps"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_fps, value = formatMetric("%.0f", it.toFloat())))
    }
    testSpecificValues["frame_time_ms"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_frame_time, value = formatMetric("%.1f ms", it.toFloat())))
    }
    testSpecificValues["image_resolution_px"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_resolution, value = "${it.toInt()}px"))
    }
    testSpecificValues["worker_count"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_core_count, value = it.toInt().toString()))
    }
    testSpecificValues["reaction_time_ms"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_reaction_time, value = "${it.toInt()} ms"))
    }

    batteryTemperatureC.value?.let {
        metrics.add(
            LiveMetric(
                labelRes = R.string.home_metric_temperature,
                value = formatMetric("%.1f°C", it),
                reflectsSystemStatus = true,
            ),
        )
    }

    metrics.add(
        LiveMetric(
            labelRes = R.string.metric_thermal_status,
            valueRes = thermalStatusValueRes(),
            reflectsSystemStatus = true,
        ),
    )

    batteryLevelPct.value?.let {
        metrics.add(LiveMetric(labelRes = R.string.home_metric_battery, value = "$it%"))
    }
    cpuUsageTotalPct.value?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_cpu, value = formatMetric("%.0f%%", it)))
    }

    return metrics
}

/**
 * Termal durumun kart üzerinde gösterilecek DEĞER kısmı (örn. "Rahat",
 * "Kritik") de lokalize edilmesi gereken bir metin olduğu için,
 * StatusColor.tierFor ile aynı sınıflandırma mantığını kullanarak
 * ilgili progress_status_* string kaynağına eşliyoruz — StatusBadge
 * ile burası aynı üç kovaya (calm/warning/critical) ayırıyor.
 */
private fun MetricsSnapshot.thermalStatusValueRes(): Int = when (thermalStatus) {
    "NONE", "LIGHT" -> R.string.progress_status_calm
    "MODERATE", "SEVERE" -> R.string.progress_status_warning
    "CRITICAL", "EMERGENCY", "SHUTDOWN" -> R.string.progress_status_critical
    // ÖNEMLİ GÖSTERGE HATASI DÜZELTMESİ: "UNKNOWN" durumu (termal API
    // desteklenmiyor, API 29 altı bir cihaz, ya da bir okuma hatası
    // sonucu runCatching fallback'i devreye girdiğinde ortaya çıkar,
    // bkz. MetricsCollector/ThermalMonitor) önceden bu when bloğunda hiç
    // ele alınmıyordu ve sessizce `else -> progress_status_calm` dalına
    // düşüyordu. Sonuç: cihazın termal durumu hakkında HİÇBİR bilgi
    // olmadığı halde kullanıcıya yeşil/güven veren "Sakin" göstergesi
    // gösteriliyordu — cihaz gerçekten aşırı ısınıyor olsa bile okuma
    // başarısız olduğu için ekran yanlışlıkla "her şey yolunda" diyordu.
    // Bu, bir güvenlik/UX güven sorunu: kullanıcı yanlış bir güvenlik
    // hissiyle testine devam edebilirdi. Artık ayrı, dürüst bir
    // "Bilinmiyor" durumu gösteriliyor.
    "UNKNOWN" -> R.string.progress_status_unknown
    else -> R.string.progress_status_unknown
}

/** MetricsSnapshot.thermalStatus (String) alanını ThermalStatus enum'ına çevirir. */
fun MetricsSnapshot.toThermalStatusEnum(): com.testthephone.app.core.safety.ThermalStatus =
    runCatching { com.testthephone.app.core.safety.ThermalStatus.valueOf(thermalStatus) }
        .getOrDefault(com.testthephone.app.core.safety.ThermalStatus.UNKNOWN)

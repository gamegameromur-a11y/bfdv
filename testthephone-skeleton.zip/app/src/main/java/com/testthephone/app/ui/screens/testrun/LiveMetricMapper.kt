package com.testthephone.app.ui.screens.testrun

import com.testthephone.app.R
import com.testthephone.app.core.monitoring.MetricsSnapshot

/**
 * MetricsSnapshot ile TestProgressScreen'in beklediği sade LiveMetric
 * listesi arasındaki köprü. UI katmanı confidence/source bilgisiyle
 * ilgilenmiyor — o detay sadece JSON raporunda kalıyor, ekranda sadece
 * "değer" ve "bu değer dikkat mi gerektiriyor" gösterilir.
 *
 * Bu fonksiyon composable DEĞİL (normal bir Kotlin extension'ı), bu
 * yüzden stringResource() çağıramaz — etiketler ve (termal durum gibi
 * kendisi de bir metin olan) değerler @StringRes Int id olarak taşınır,
 * gerçek metne TestProgressScreen içinde (composable context'te)
 * çevrilir.
 */
fun MetricsSnapshot.toLiveMetrics(): List<LiveMetric> {
    val metrics = mutableListOf<LiveMetric>()

    testSpecificValues["entity_count"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_entity_count, value = it.toInt().toString()))
    }
    testSpecificValues["fps"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_fps, value = "%.0f".format(it)))
    }
    testSpecificValues["frame_time_ms"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_frame_time, value = "%.1f ms".format(it)))
    }
    testSpecificValues["image_resolution_px"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_resolution, value = "${it.toInt()}px"))
    }
    testSpecificValues["worker_count"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_core_count, value = it.toInt().toString()))
    }
    testSpecificValues["reaction_time_ms"]?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_reaction_time, value = "${it.toInt()} ms"))
    }

    batteryTemperatureC.value?.let {
        metrics.add(
            LiveMetric(
                labelRes = R.string.home_metric_temperature,
                value = "%.1f°C".format(it),
                reflectsSystemStatus = true,
            ),
        )
    }

    metrics.add(
        LiveMetric(
            labelRes = R.string.metric_thermal_status,
            valueRes = thermalStatusValueRes(),
            reflectsSystemStatus = true,
        ),
    )

    batteryLevelPct.value?.let {
        metrics.add(LiveMetric(labelRes = R.string.home_metric_battery, value = "$it%"))
    }
    cpuUsageTotalPct.value?.let {
        metrics.add(LiveMetric(labelRes = R.string.metric_cpu, value = "%.0f%%".format(it)))
    }

    return metrics
}

/**
 * Termal durumun kart üzerinde gösterilecek DEĞER kısmı (örn. "Rahat",
 * "Kritik") de lokalize edilmesi gereken bir metin olduğu için,
 * StatusColor.tierFor ile aynı sınıflandırma mantığını kullanarak
 * ilgili progress_status_* string kaynağına eşliyoruz — StatusBadge
 * ile burası aynı üç kovaya (calm/warning/critical) ayırıyor.
 */
private fun MetricsSnapshot.thermalStatusValueRes(): Int = when (thermalStatus) {
    "NONE", "LIGHT" -> R.string.progress_status_calm
    "MODERATE", "SEVERE" -> R.string.progress_status_warning
    "CRITICAL", "EMERGENCY", "SHUTDOWN" -> R.string.progress_status_critical
    else -> R.string.progress_status_calm
}

/** MetricsSnapshot.thermalStatus (String) alanını ThermalStatus enum'ına çevirir. */
fun MetricsSnapshot.toThermalStatusEnum(): com.testthephone.app.core.safety.ThermalStatus =
    runCatching { com.testthephone.app.core.safety.ThermalStatus.valueOf(thermalStatus) }
        .getOrDefault(com.testthephone.app.core.safety.ThermalStatus.UNKNOWN)

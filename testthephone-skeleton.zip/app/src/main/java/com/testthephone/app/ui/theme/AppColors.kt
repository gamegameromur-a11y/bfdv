package com.testthephone.app.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * "Test the phone" için renk sistemi, önceki tasarım kararlarımızın
 * doğrudan kod karşılığı: SABİT bir marka rengi yok — sistem durumu
 * (rahat/yükleniyor/kritik) tek görsel dil olarak kullanılıyor.
 * Ana ekran bilinçli olarak beyaz/nötr ağırlıklı; renk sadece test
 * çalışırken, gerçekten bir şey söylerken devreye giriyor.
 *
 * AppColors artık statik bir obje DEĞİL — LocalAppColors CompositionLocal'i
 * üzerinden çözülen bir arayüz. Bu, Ayarlar'daki "Koyu tema" anahtarının
 * gerçekten bir şey yapabilmesi için gerekliydi: önceden AppColors sabit
 * (hep açık tema) bir object'ti, DataStore'daki darkThemeEnabled tercihi
 * hiçbir görsel etki yaratmıyordu. Artık TestThePhoneTheme, darkTheme
 * parametresine göre LightAppColors veya DarkAppColors'ı sağlıyor;
 * ekranlardaki `AppColors.TextPrimary` gibi çağrılar (bkz. altta `val
 * AppColors get()`) mevcut kod tabanını DEĞİŞTİRMEDEN doğru palete
 * yönleniyor.
 */
interface AppColorPalette {
    val Background: Color
    val Surface1: Color
    val Surface2: Color
    val Border: Color
    val BorderStrong: Color

    val TextPrimary: Color
    val TextSecondary: Color
    val TextMuted: Color

    val StatusCalmStart: Color
    val StatusCalmEnd: Color
    val StatusWarningStart: Color
    val StatusWarningEnd: Color
    val StatusCriticalStart: Color
    val StatusCriticalEnd: Color
    // "Termal durum bilinmiyor" için ayrı, nötr gri ton — bkz.
    // StatusColor.tierFor içindeki UNKNOWN gerekçesi. Sakin yeşille
    // KARIŞTIRILMAMALI: burası "her şey yolunda" değil, "veri yok"
    // anlamına geliyor.
    val StatusUnknownStart: Color
    val StatusUnknownEnd: Color

    val TextDanger: Color
    val BorderDanger: Color
    val FillDanger: Color
    val OnDanger: Color

    val FillPrimary: Color
    val OnPrimary: Color
}

object LightAppColors : AppColorPalette {
    // Nötr taban — "sade, gösterişsiz ama özgüvenli" hedefi.
    override val Background = Color(0xFFFFFFFF)
    override val Surface1 = Color(0xFFF7F7F8) // Kartların içi.
    override val Surface2 = Color(0xFFFFFFFF) // Kartların kendisi (Background'dan ayrışması border ile).
    override val Border = Color(0xFFE5E5E7)
    override val BorderStrong = Color(0xFFD4D4D8)

    override val TextPrimary = Color(0xFF18181B)
    override val TextSecondary = Color(0xFF52525B)
    // Önceden 0xFFA1A1AA — beyaza çok yakın bir gri olduğu için açık
    // arka plan üstünde etiket/alt metinler neredeyse görünmez oluyordu.
    // Kontrastı artırmak için koyulaştırıldı.
    override val TextMuted = Color(0xFF71717A)

    // --- Durum rengi sistemi ---
    // Bu üç renk, ThermalStatus / SafetyDecision durumuna göre UI'da
    // yumuşak geçişlerle kullanılır (bkz. StatusColor.tierFor). Sabit
    // bir "marka rengi" değiller — sadece canlı veri onları
    // tetiklediğinde görünürler. Koyu temada da AYNI durum renkleri
    // kullanılıyor (bilinçli) — "kritik = kırmızı" evrensel bir sinyal,
    // tema değişince anlamının kaymaması için ton sabit tutuluyor.
    override val StatusCalmStart = Color(0xFF97C459) // NONE/LIGHT — rahat.
    override val StatusCalmEnd = Color(0xFF6FA83E)
    override val StatusWarningStart = Color(0xFFFAC775) // MODERATE/SEVERE — yükleniyor.
    override val StatusWarningEnd = Color(0xFFEF9F27)
    override val StatusCriticalStart = Color(0xFFF598A7) // CRITICAL/EMERGENCY/SHUTDOWN — kritik.
    override val StatusCriticalEnd = Color(0xFFE23D5C)
    // Nötr gri: sakin yeşille karıştırılmasın diye bilinçli olarak
    // sıcak/soğuk hiçbir tona yaklaştırılmadı.
    override val StatusUnknownStart = Color(0xFFC4C4C9)
    override val StatusUnknownEnd = Color(0xFF9A9AA2)

    override val TextDanger = Color(0xFFB91C3C)
    override val BorderDanger = Color(0xFFF1AAB8)
    override val FillDanger = Color(0xFFE23D5C)
    override val OnDanger = Color(0xFFFFFFFF)

    override val FillPrimary = Color(0xFF18181B) // Ana CTA butonu — nötr, koyu, iddiasız.
    override val OnPrimary = Color(0xFFFFFFFF)
}

object DarkAppColors : AppColorPalette {
    // Saf siyah (#000) yerine çok koyu gri: OLED'de tam siyah metin
    // kontrastını sertleştirip göz yorgunluğu yaratabiliyor, ayrıca
    // "sade ama özgüvenli" tonunu koyu modda da korumak için yumuşak
    // bir koyu nötr tercih edildi.
    override val Background = Color(0xFF121214)
    override val Surface1 = Color(0xFF1C1C1F) // Kartların içi — Background'dan bir tık açık.
    override val Surface2 = Color(0xFF1C1C1F)
    override val Border = Color(0xFF303034)
    override val BorderStrong = Color(0xFF3F3F45)

    override val TextPrimary = Color(0xFFF4F4F5)
    override val TextSecondary = Color(0xFFA1A1AA)
    override val TextMuted = Color(0xFF71717A)

    override val StatusCalmStart = Color(0xFF97C459)
    override val StatusCalmEnd = Color(0xFF6FA83E)
    override val StatusWarningStart = Color(0xFFFAC775)
    override val StatusWarningEnd = Color(0xFFEF9F27)
    override val StatusCriticalStart = Color(0xFFF598A7)
    override val StatusCriticalEnd = Color(0xFFE23D5C)
    override val StatusUnknownStart = Color(0xFF54545C)
    override val StatusUnknownEnd = Color(0xFF404048)

    // Koyu temada kırmızı metin/kenarlık, koyu arka plan üstünde okunabilirlik
    // için biraz daha açık tonlanıyor — açık temadaki koyu kırmızı
    // (0xFFB91C3C) koyu zeminde kontrastı düşük kalırdı.
    override val TextDanger = Color(0xFFF87171)
    override val BorderDanger = Color(0xFF5C2530)
    override val FillDanger = Color(0xFFE23D5C)
    override val OnDanger = Color(0xFFFFFFFF)

    override val FillPrimary = Color(0xFFF4F4F5) // Koyu temada CTA açık renk, zeminle ters kontrast.
    override val OnPrimary = Color(0xFF18181B)
}

val LocalAppColors = staticCompositionLocalOf<AppColorPalette> { LightAppColors }

/**
 * Geriye dönük uyumluluk: mevcut ekranlardaki tüm `AppColors.TextPrimary`
 * gibi çağrılar, bu top-level `val` sayesinde herhangi bir kod değişikliği
 * gerekmeden LocalAppColors CompositionLocal'inin o anki değerine yönlenir.
 * Bu, composable context DIŞINDA (örn. bir data class alanı olarak)
 * kullanılamaz — ama projede AppColors her zaman composable içinde
 * çağrılıyor, bu yüzden güvenli.
 */
val AppColors: AppColorPalette
    @androidx.compose.runtime.Composable
    get() = LocalAppColors.current


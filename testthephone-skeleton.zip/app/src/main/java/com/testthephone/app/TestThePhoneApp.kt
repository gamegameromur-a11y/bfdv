package com.testthephone.app

import android.app.Application

/**
 * Şimdilik minimal.
 *
 * Dil tercihinin (AppCompatDelegate.setApplicationLocales) uygulanması
 * BİLEREK burada değil, MainActivity'nin Compose ağacındaki
 * LaunchedEffect(languageCode) içinde yapılıyor. Application.onCreate()
 * içinde DataStore'dan senkron okuma yapmak mümkün değil (DataStore API'si
 * suspend/Flow tabanlı) — burada "en erken" bir garanti vermeye
 * çalışmak, ya bloklayan bir okuma (ANR riski) ya da yanıltıcı bir
 * "erken uygulama" izlenimi yaratırdı. Compose'un ilk kompozisyonu
 * kullanıcı bir şey görmeden önce çalıştığı için, mevcut konum pratikte
 * yeterince erken.
 */
class TestThePhoneApp : Application()

package com.testthephone.app.tests.sustained

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.TestExecutionContext
import com.testthephone.app.tests.TestProgressEvent
import com.testthephone.app.tests.entityspawn.Entity
import com.testthephone.app.tests.entityspawn.EntitySimulationStep
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Test 5: Sürdürülebilir performans / throttling eğrisi — "gerçek oyunda
 * 20. dakikada performans nasıl olacak" sorusunun doğrudan cevabı.
 *
 * Araştırmamızdaki bulguya dayanıyor: tekli-koşum benchmarklar (Geekbench,
 * AnTuTu gibi) 1-15 dakikalık kısa pencerede ölçüm yapar, throttling
 * devreye girmeden. Gerçekte sürdürülebilir GPU performansı tepe skorların
 * %50-65'i, CPU ise %64-78'i seviyesinde kalıyor. Bu test, o farkı
 * doğrudan ölçer.
 *
 * Yöntem: sabit bir yoğunlukta (Test 1/2'nin bulduğu stabil kapasitenin
 * altında, bilerek "rahat" bir seviyede) karma CPU yükünü uzun süre
 * (varsayılan 10 dakika, testDurationMs ile ayarlanabilir) çalıştırır.
 * İlk 60 saniyelik ortalama "burst skoru", son 60 saniyelik ortalama ise
 * "sustained skoru" olarak kaydedilir; oranları rapora yazılır.
 *
 * Sabit yoğunlukta çalışmasının nedeni: kademeli artan testlerde (Test
 * 1-2 gibi) "ne kadar dayanabildiği" ölçülüyor, burada ise "sabit bir
 * yükte zamanla ne kadar bozulduğu" ölçülüyor — iki farklı soru, iki
 * farklı yöntem gerektiriyor.
 */
class SustainedPerformanceTestEngine(
    private val metricsCollector: MetricsCollector,
    /** Test 1/2'den gelen referans kapasite; sabit yük bunun bir kesri olarak belirlenir. */
    private val referenceEntityCount: Int,
    private val testDurationMs: Long = 10 * 60 * 1000L, // 10 dakika, varsayılan.
    private val boundsWidth: Float = 1080f,
    private val boundsHeight: Float = 2400f,
) : TestEngine {

    override val testId = "sustained_performance"
    override val displayNameKey = "test_sustained_performance_name"

    private val deltaSeconds = 1f / 60f
    private val burstWindowMs = 60_000L // İlk/son 60 saniye "burst"/"sustained" pencereleri.
    private val samplingIntervalMs = 1000L // Bu test uzun sürdüğü için daha seyrek örnekleme yeterli.

    override fun run(context: TestExecutionContext): Flow<TestProgressEvent> = flow {
        // Sabit yük: referans kapasitenin %60'ı — cihazı anında zorlayan
        // bir seviye değil, "gerçekçi sürdürülebilir oyun senaryosu"
        // simüle eden, bilinçli olarak rahat bir yoğunluk.
        val fixedLoad = if (referenceEntityCount > 0) {
            (referenceEntityCount * 0.6).toInt().coerceAtLeast(context.calibration.initialEntityCount)
        } else {
            context.calibration.initialEntityCount
        }

        val simulationStep = EntitySimulationStep(boundsWidth, boundsHeight)
        val entities = MutableList(fixedLoad) {
            Entity.spawnRandom(boundsWidth, boundsHeight, interactive = true)
        }
        val neighborCheckWindow = (context.calibration.cpuCoreCount * 2).coerceIn(4, 32)

        val startTime = System.currentTimeMillis()
        val burstFrameTimes = mutableListOf<Float>()
        // ÖNEMLİ PERFORMANS BUG'I: Bu liste önceden testDurationMs boyunca
        // (varsayılan 10 DAKİKA) HER FRAME için büyüyor ve hiç temizlenmiyordu.
        // Üstelik her ~1 saniyede bir (samplingIntervalMs) bu listenin
        // TAMAMI filter{} ile taranıyordu (bkz. aşağıdaki recentWindow
        // hesaplaması) — bu da testin süresi arttıkça filtreleme
        // maliyetinin de büyüdüğü, giderek yavaşlayan bir O(n²) davranışı
        // demekti. 10 dakikalık testte, frame time ~5-10ms civarındaysa
        // liste 60.000-120.000 elemana ulaşabiliyor, bu da testin sonlarına
        // doğru fark edilir şekilde yavaşlamasına (frame ölçümünün kendisi
        // değil, çevresindeki liste/filtreleme maliyeti yüzünden) yol
        // açıyordu — "test uzadıkça giderek daha yavaş/donmuş hissettiriyor"
        // şikayetinin olası bir kaynağı.
        //
        // Düzeltme: son burstWindowMs kadarlık kaydı ayrı, sınırlı boyutlu
        // bir ArrayDeque'de tutuyoruz — pencereden düşen eski örnekler
        // anında atılıyor, bu yüzden liste her zaman en fazla ~burstWindowMs
        // kadarlık frame sayısı büyüklüğünde kalıyor (sabit üst sınır),
        // testin toplam süresinden bağımsız.
        val recentFrameTimes = ArrayDeque<Pair<Long, Float>>()

        var lastSampleTime = 0L

        while (true) {
            val elapsedMs = System.currentTimeMillis() - startTime
            if (elapsedMs >= testDurationMs) break

            val decision = context.safetyDecision.value
            if (decision == SafetyDecision.PAUSE_REQUIRED) {
                emit(TestProgressEvent.Paused(reason = "thermal_critical"))
                return@flow
            }

            val frameStart = System.nanoTime()
            simulationStep.stepInteractive(entities, deltaSeconds, neighborCheckWindow)
            val frameTimeMs = (System.nanoTime() - frameStart) / 1_000_000f

            recentFrameTimes.addLast(elapsedMs to frameTimeMs)
            // Pencereden düşen (burstWindowMs'ten eski) örnekleri anında at
            // — bu, listenin testin toplam süresinden bağımsız, her zaman
            // sabit bir üst sınırda kalmasını sağlıyor.
            while (recentFrameTimes.isNotEmpty() && recentFrameTimes.first().first < elapsedMs - burstWindowMs) {
                recentFrameTimes.removeFirst()
            }
            if (elapsedMs <= burstWindowMs) {
                burstFrameTimes.add(frameTimeMs)
            }

            // Seyrek örnekleme: her frame'de değil, saniyede bir snapshot al.
            if (elapsedMs - lastSampleTime >= samplingIntervalMs) {
                lastSampleTime = elapsedMs
                val recentWindow = recentFrameTimes
                    .filter { it.first >= elapsedMs - samplingIntervalMs }
                    .map { it.second }
                val avgRecentFrameTimeMs = if (recentWindow.isNotEmpty()) recentWindow.average().toFloat() else frameTimeMs

                val snapshot = metricsCollector.snapshot(
                    elapsedMs = elapsedMs,
                    testSpecific = mapOf(
                        "entity_count_fixed_load" to fixedLoad.toDouble(),
                        "frame_time_ms" to avgRecentFrameTimeMs.toDouble(),
                        "fps" to (1000.0 / avgRecentFrameTimeMs.coerceAtLeast(0.001f)),
                    ),
                )
                emit(TestProgressEvent.Sample(snapshot))
            }
        }

        val totalElapsed = System.currentTimeMillis() - startTime
        // Test bittiğinde recentFrameTimes zaten sadece son burstWindowMs'lik
        // pencereyi tutuyor (yukarıdaki döngüde sürekli budandığı için) —
        // bu doğrudan "sustained" (son 60 saniye) örneklem kümesidir.
        val sustainedFrameTimes = recentFrameTimes.map { it.second }

        val burstAvgFrameTimeMs = burstFrameTimes.averageOrZero()
        val sustainedAvgFrameTimeMs = sustainedFrameTimes.averageOrZero()

        // FPS oranı üzerinden hesaplanan sustained/burst oranı — frame
        // time değil FPS kıyaslanıyor çünkü "performans oranı" sezgisel
        // olarak FPS cinsinden daha anlaşılır (araştırmadaki %50-78
        // aralığıyla doğrudan karşılaştırılabilir).
        val burstFps = if (burstAvgFrameTimeMs > 0) 1000.0 / burstAvgFrameTimeMs else 0.0
        val sustainedFps = if (sustainedAvgFrameTimeMs > 0) 1000.0 / sustainedAvgFrameTimeMs else 0.0
        val sustainedToBurstRatio = if (burstFps > 0) sustainedFps / burstFps else 0.0

        emit(
            TestProgressEvent.Completed(
                summary = mapOf(
                    "burst_avg_fps" to burstFps,
                    "sustained_avg_fps" to sustainedFps,
                    "sustained_to_burst_ratio" to sustainedToBurstRatio,
                    "fixed_load_entity_count" to fixedLoad.toDouble(),
                    "total_duration_ms" to totalElapsed.toDouble(),
                )
            )
        )
    }

    private fun List<Float>.averageOrZero(): Float = if (isEmpty()) 0f else average().toFloat()
}

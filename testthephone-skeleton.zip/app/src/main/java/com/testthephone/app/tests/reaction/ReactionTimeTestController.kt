package com.testthephone.app.tests.reaction

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.report.TestResult
import com.testthephone.app.report.TestStatus
import com.testthephone.app.tests.entityspawn.Entity
import com.testthephone.app.tests.entityspawn.EntitySimulationStep
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Test 7: Frame pacing / input-to-photon gecikmesi — "yük artıkça tepki
 * süresi değişiyor mu" sorusunun doğrudan cevabı. Diğer testlerde her
 * adımın içine gömülü olan tepki süresi mini-testinin, burada odaklı
 * ve tek başına bir teste dönüştürülmüş hali.
 *
 * GPU testi gibi bu da Compose'un kendi render/input döngüsüne bağlı
 * çalıştığı için TestEngine arayüzüne uymaz — UI katmanında ayrı bir
 * composable (ReactionTimeSurface, ayrı dosyada) + bu kontrolcü ikilisi
 * olarak yaşar.
 *
 * Yöntem: arka planda kademeli artan bir CPU yükü (entity simülasyonu)
 * çalışırken, ekranda düzenli aralıklarla bir hedef belirir; kullanıcı
 * dokunduğunda dokunma zaman damgası ile hedefin ekranda göründüğü zaman
 * damgası arasındaki fark "tepki süresi" olarak ölçülür. Bu, hem
 * kullanıcının biyolojik tepki süresini hem de sistemin input-to-photon
 * gecikmesini birlikte içerir — ikisini ayırmak cihaz API'leriyle
 * mümkün değil, bu yüzden rapor bu ölçümü "algılanan tepki süresi"
 * olarak, INDIRECT_ESTIMATE benzeri bir dürüstlükle sunar.
 */
class ReactionTimeTestController(
    private val metricsCollector: MetricsCollector,
    private val safetyDecision: StateFlow<SafetyDecision>,
    private val result: TestResult,
    private val cpuCoreCount: Int,
    boundsWidth: Float = 1080f,
    boundsHeight: Float = 2400f,
) {
    private val simulationStep = EntitySimulationStep(boundsWidth, boundsHeight)
    private val backgroundEntities = mutableListOf<Entity>()
    private val boundsW = boundsWidth
    private val boundsH = boundsHeight

    // Yük seviyeleri: her biri farklı bir arka plan entity yoğunluğu.
    // Test, bu seviyelerde sırayla birkaç tepki süresi ölçümü toplar.
    private val loadLevels = listOf(0, 500, 1500, 3000, 6000)
    private val samplesPerLoadLevel = 5

    private var loadLevelIndex = 0
    private var samplesAtCurrentLevel = mutableListOf<Long>()
    private var targetShownAtNanos: Long? = null
    private val allSamples = mutableListOf<Pair<Int, Long>>() // (loadLevel, reactionTimeMs)

    private val startTime = System.currentTimeMillis()

    private val _state = MutableStateFlow(
        ReactionTestUiState(
            currentLoadLevel = loadLevels[0],
            targetVisible = false,
            finished = false,
        )
    )
    val state: StateFlow<ReactionTestUiState> = _state.asStateFlow()

    init {
        result.status = TestStatus.RUNNING
        result.startedAtUtcMillis = System.currentTimeMillis()
        applyLoadLevel(loadLevels[0])
        scheduleNextTarget()
    }

    /**
     * UI katmanının her frame'de (ya da düzenli aralıklarla) çağırması
     * gereken arka plan yük adımı — GPU testindeki gibi render'a bağımlı
     * değil ama UI thread'i bloklamaması için çağıran taraf bunu uygun
     * bir Compose side-effect'i (LaunchedEffect + withFrameMillis) içinde
     * çağırmalı, tıpkı entity testlerinde olduğu gibi.
     */
    fun stepBackgroundLoad() {
        if (_state.value.finished) return

        if (safetyDecision.value == SafetyDecision.PAUSE_REQUIRED) {
            finishAsPaused()
            return
        }

        val neighborCheckWindow = (cpuCoreCount * 2).coerceIn(4, 32)
        simulationStep.stepInteractive(backgroundEntities, 1f / 60f, neighborCheckWindow)
    }

    /** UI'de hedef göründüğünde çağrılır — zaman damgasını kaydeder. */
    fun onTargetShown() {
        targetShownAtNanos = System.nanoTime()
        _state.value = _state.value.copy(targetVisible = true)
    }

    /** Kullanıcı hedefe dokunduğunda çağrılır. */
    fun onTargetTapped() {
        val shownAt = targetShownAtNanos ?: return
        val reactionTimeMs = (System.nanoTime() - shownAt) / 1_000_000

        samplesAtCurrentLevel.add(reactionTimeMs)
        allSamples.add(loadLevels[loadLevelIndex] to reactionTimeMs)
        targetShownAtNanos = null
        _state.value = _state.value.copy(targetVisible = false)

        recordSnapshotIfNeeded()

        if (samplesAtCurrentLevel.size >= samplesPerLoadLevel) {
            advanceToNextLoadLevel()
        } else {
            scheduleNextTarget()
        }
    }

    private fun recordSnapshotIfNeeded() {
        val elapsedMs = System.currentTimeMillis() - startTime
        val recentReactionMs = samplesAtCurrentLevel.lastOrNull() ?: return
        val snapshot = metricsCollector.snapshot(
            elapsedMs = elapsedMs,
            testSpecific = mapOf(
                "background_load_entity_count" to loadLevels[loadLevelIndex].toDouble(),
                "reaction_time_ms" to recentReactionMs.toDouble(),
            ),
        )
        result.timeseries.add(snapshot)
    }

    private fun advanceToNextLoadLevel() {
        loadLevelIndex++
        samplesAtCurrentLevel = mutableListOf()

        if (loadLevelIndex >= loadLevels.size) {
            finishAsCompleted()
            return
        }

        applyLoadLevel(loadLevels[loadLevelIndex])
        _state.value = _state.value.copy(currentLoadLevel = loadLevels[loadLevelIndex])
        scheduleNextTarget()
    }

    private fun applyLoadLevel(entityCount: Int) {
        backgroundEntities.clear()
        repeat(entityCount) {
            backgroundEntities.add(Entity.spawnRandom(boundsW, boundsH, interactive = true))
        }
    }

    private fun scheduleNextTarget() {
        // Gerçek "ne zaman görünecek" zamanlaması UI katmanında
        // (rastgele gecikme + onTargetShown çağrısı) yönetilir; burada
        // sadece durumu "henüz görünmüyor" olarak işaretliyoruz.
        _state.value = _state.value.copy(targetVisible = false)
    }

    private fun finishAsCompleted() {
        result.status = TestStatus.COMPLETED
        result.endedAtUtcMillis = System.currentTimeMillis()

        val overallAvg = allSamples.map { it.second }.averageOrZero()
        val overallMin = allSamples.minOfOrNull { it.second } ?: 0L
        val overallMax = allSamples.maxOfOrNull { it.second } ?: 0L

        // Yüksüz (loadLevel=0) ve en yüklü seviyedeki ortalamaları
        // kıyaslayarak "yük tepki süresini ne kadar etkiledi" oranını
        // hesaplıyoruz — bu, testin asıl cevapladığı soru.
        val unloadedAvg = allSamples.filter { it.first == loadLevels.first() }.map { it.second }.averageOrZero()
        val heaviestLoadAvg = allSamples.filter { it.first == loadLevels.last() }.map { it.second }.averageOrZero()
        val degradationRatio = if (unloadedAvg > 0) heaviestLoadAvg / unloadedAvg else 0.0

        result.summary = mapOf(
            "reaction_time_avg_ms" to overallAvg,
            "reaction_time_min_ms" to overallMin.toDouble(),
            "reaction_time_max_ms" to overallMax.toDouble(),
            "reaction_time_unloaded_avg_ms" to unloadedAvg,
            "reaction_time_heaviest_load_avg_ms" to heaviestLoadAvg,
            "reaction_time_degradation_ratio" to degradationRatio,
            "total_duration_ms" to (System.currentTimeMillis() - startTime).toDouble(),
        )
        _state.value = _state.value.copy(finished = true)
    }

    private fun finishAsPaused() {
        result.status = TestStatus.PAUSED
        result.abortReason = "thermal_critical"
        result.endedAtUtcMillis = System.currentTimeMillis()
        _state.value = _state.value.copy(finished = true, paused = true)
    }

    private fun List<Long>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
}

data class ReactionTestUiState(
    val currentLoadLevel: Int,
    val targetVisible: Boolean,
    val finished: Boolean,
    val paused: Boolean = false,
)

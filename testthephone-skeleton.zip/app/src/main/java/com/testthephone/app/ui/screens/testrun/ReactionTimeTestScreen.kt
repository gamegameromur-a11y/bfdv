package com.testthephone.app.ui.screens.testrun

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.report.TestResult
import com.testthephone.app.tests.reaction.ReactionTimeSurface
import com.testthephone.app.tests.reaction.ReactionTimeTestController
import com.testthephone.app.ui.theme.AppColors
import kotlinx.coroutines.flow.StateFlow

/**
 * Test 7'nin (tepki süresi) ekran katmanı. GpuTestScreen ile aynı
 * desende: ReactionTimeTestController + ReactionTimeSurface'i kurar,
 * "finished" olduğunda çağıran tarafa haber verir.
 */
@Composable
fun ReactionTimeTestScreen(
    metricsCollector: MetricsCollector,
    safetyDecision: StateFlow<SafetyDecision>,
    result: TestResult,
    cpuCoreCount: Int,
    onFinished: () -> Unit,
) {
    val controller = remember {
        ReactionTimeTestController(
            metricsCollector = metricsCollector,
            safetyDecision = safetyDecision,
            result = result,
            cpuCoreCount = cpuCoreCount,
        )
    }
    val uiState by controller.state.collectAsState()

    LaunchedEffect(uiState.finished) {
        if (uiState.finished) onFinished()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
    ) {
        Text(
            text = stringResource(R.string.reaction_test_title),
            style = MaterialTheme.typography.titleMedium,
            color = AppColors.TextPrimary,
        )
        Text(
            text = stringResource(R.string.reaction_test_instruction, uiState.currentLoadLevel),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextMuted,
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 12.dp),
        ) {
            ReactionTimeSurface(
                controller = controller,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

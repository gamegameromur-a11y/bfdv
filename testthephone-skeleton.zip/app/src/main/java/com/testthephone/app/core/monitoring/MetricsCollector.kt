package com.testthephone.app.core.monitoring

import android.content.Context
import com.testthephone.app.core.safety.ThermalMonitor
import com.testthephone.app.core.safety.ThermalReading
import com.testthephone.app.core.safety.ThermalStatus

/**
 * Tüm testlerin ortak kullandığı tek örnekleme noktası. "İstisnasız her
 * şeyi izleyeceğiz" hedefinin somut karşılığı burası: her test döngüsü
 * belirli aralıklarla (varsayılan 250ms) bu sınıfı çağırıp bir
 * MetricsSnapshot alır, bu da JSON rapor şemasındaki timeseries[] dizisinin
 * her elemanına karşılık gelir.
 *
 * Root modu ayrı tutulur (rootZoneReading alanları) — normal ölçümle
 * asla karıştırılmaz, sadece kullanılabilirse doldurulur.
 */
class MetricsCollector(context: Context) {

    private val batteryMonitor = BatteryMonitor(context)
    private val memoryMonitor = MemoryMonitor(context)
    private val cpuUsageMonitor = CpuUsageMonitor()
    private val thermalZoneReader = ThermalZoneReader()
    private val thermalMonitor = ThermalMonitor(context)

    /**
     * Root erişimi varsa dışarıdan enjekte edilir (RootThermalReader,
     * ayrı bir modülde tanımlanacak). Yoksa null kalır ve ilgili
     * alanlar UNAVAILABLE olarak işaretlenir.
     */
    var rootThermalReader: RootThermalReader? = null

    fun snapshot(elapsedMs: Long, testSpecific: Map<String, Double> = emptyMap()): MetricsSnapshot {
        // ÖNEMLİ CRASH RİSKİ DÜZELTMESİ: bu fonksiyon her test adımında
        // (saniyede birkaç kez) çağrılıyor ve gerçek donanım/sistem
        // API'lerine dokunuyor — bunların bir kısmı (özellikle
        // rootThermalReader, root erişimiyle çalıştığı için doğası
        // gereği en kırılgan olanı) OEM'e/cihaza göre beklenmedik
        // istisnalar fırlatabilir. Önceden thermal/battery/memory
        // okumaları ile rootThermalReader hiçbir üst düzey korumaya
        // sahip değildi — TEK BİR sensörün başarısız olması, testin
        // ORTASINDA tüm uygulamayı çökertip kullanıcının o ana kadarki
        // ilerlemesini kaybetmesine yol açabilirdi.
        //
        // Her okumayı BAĞIMSIZ olarak koruyoruz (tek bir dev try/catch
        // yerine): böylece örneğin root okuması başarısız olursa, bu
        // diğer sensörlerin (thermal, battery, memory, CPU) o adımda
        // yine de doğru şekilde raporlanmasını engellemez — kısmi veri
        // kaybı, TAM çökmeden her zaman daha iyidir.
        val thermal = runCatching { thermalMonitor.currentStatus() }
            .getOrElse { ThermalReading(status = ThermalStatus.UNKNOWN, headroom = null, supported = false) }
        val battery = runCatching { batteryMonitor.snapshot() }
            .getOrElse {
                BatterySnapshot(
                    temperatureC = unavailable("BatteryManager:exception"),
                    levelPct = unavailable("BatteryManager:exception"),
                    currentMicroAmps = unavailable("BatteryManager:exception"),
                    voltageMv = unavailable("BatteryManager:exception"),
                )
            }
        val memory = runCatching { memoryMonitor.snapshot() }
            .getOrElse {
                MemorySnapshot(
                    appUsedMb = unavailable("ActivityManager:exception"),
                    systemAvailableMb = unavailable("ActivityManager:exception"),
                    systemTotalMb = unavailable("ActivityManager:exception"),
                    systemLowMemory = unavailable("ActivityManager:exception"),
                )
            }
        val cpuTotal = runCatching { cpuUsageMonitor.totalUsagePct() }
            .getOrElse { unavailable("proc_stat:exception") }
        val cpuPerCore = runCatching { cpuUsageMonitor.perCoreUsagePct() }
            .getOrElse { unavailable("proc_stat:per_core_exception") }
        val cpuTempEstimate = runCatching { thermalZoneReader.readCategory(ThermalZoneCategory.CPU) }
            .getOrElse { unavailable("sysfs_thermal_zone:exception") }
        val gpuTempEstimate = runCatching { thermalZoneReader.readCategory(ThermalZoneCategory.GPU) }
            .getOrElse { unavailable("sysfs_thermal_zone:exception") }
        val cpuTempRoot = runCatching {
            rootThermalReader?.readCpuTemp() ?: unavailable("root_not_available")
        }.getOrElse { unavailable("root_thermal_reader:exception") }
        val gcCumulative = runCatching { memoryMonitor.cumulativeGcPauseCount() }
            .getOrElse { unavailable("art.gc.gc-count:exception") }

        return MetricsSnapshot(
            elapsedMs = elapsedMs,
            thermalStatus = thermal.status.name,
            thermalHeadroom = if (thermal.supported) {
                certain(thermal.headroom, "PowerManager.getThermalHeadroom")
            } else {
                unavailable("PowerManager.getThermalHeadroom:unsupported_below_api29")
            },
            batteryTemperatureC = battery.temperatureC,
            batteryLevelPct = battery.levelPct,
            batteryCurrentMicroAmps = battery.currentMicroAmps,
            cpuUsageTotalPct = cpuTotal,
            cpuUsagePerCorePct = cpuPerCore,
            cpuTempEstimateC = cpuTempEstimate,
            gpuTempEstimateC = gpuTempEstimate,
            cpuTempRootC = cpuTempRoot,
            ramUsedMb = memory.appUsedMb,
            gcCumulativeCount = gcCumulative,
            testSpecificValues = testSpecific,
        )
    }

    /**
     * Testlerin acil durdurma kararını değerlendirmek için doğrudan
     * erişebileceği okuma. Bu, SafetyController'ın termal güvenlik
     * kararlarının (PAUSE_REQUIRED vb.) dayandığı yol olduğu için,
     * korumasız bırakılması hem bir çökme riski hem de DAHA CİDDİSİ,
     * bir istisna durumunda güvenlik mekanizmasının kendisinin devre
     * dışı kalması riski taşıyordu. Başarısız olursa UNKNOWN/unsupported
     * dönüyoruz — SafetyController bunu "veri yok" olarak ele alıp
     * ihtiyatlı davranmaya devam edebilir, çökmez.
     */
    fun rawThermalReading(): ThermalReading =
        runCatching { thermalMonitor.currentStatus() }
            .getOrElse { ThermalReading(status = ThermalStatus.UNKNOWN, headroom = null, supported = false) }
}

/**
 * Root erişimiyle thermal_zone dosyalarını SELinux kısıtlaması olmadan
 * okuyan arayüz. Gerçek implementasyon (libsu tabanlı) ayrı bir dosyada
 * tanımlanacak; burada sadece sözleşme (contract) tanımlanıyor ki
 * MetricsCollector root olsun olmasın aynı şekilde çalışabilsin.
 */
interface RootThermalReader {
    fun readCpuTemp(): MeasuredValue<Float>
    fun readGpuTemp(): MeasuredValue<Float>
}

/**
 * Uygulama içi (runtime) veri modeli. JSON export sırasında
 * MetricsSnapshotJson.from(this) ile somut, doğrudan serileştirilebilir
 * bir DTO'ya çevrilir (bkz. core/monitoring/json/MetricsSnapshotJson.kt).
 */
data class MetricsSnapshot(
    val elapsedMs: Long,
    val thermalStatus: String,
    val thermalHeadroom: MeasuredValue<Float>,
    val batteryTemperatureC: MeasuredValue<Float>,
    val batteryLevelPct: MeasuredValue<Int>,
    val batteryCurrentMicroAmps: MeasuredValue<Int>,
    val cpuUsageTotalPct: MeasuredValue<Float>,
    val cpuUsagePerCorePct: MeasuredValue<List<Float>>,
    val cpuTempEstimateC: MeasuredValue<Float>,
    val gpuTempEstimateC: MeasuredValue<Float>,
    val cpuTempRootC: MeasuredValue<Float>,
    val ramUsedMb: MeasuredValue<Float>,
    val gcCumulativeCount: MeasuredValue<Int>,
    /** Teste özel değerler (örn. entity_count, fps, frame_time_ms). */
    val testSpecificValues: Map<String, Double>,
)

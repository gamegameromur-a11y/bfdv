package com.testthephone.app.core.monitoring

import android.content.Context
import com.testthephone.app.core.safety.ThermalMonitor
import com.testthephone.app.core.safety.ThermalReading

/**
 * Tüm testlerin ortak kullandığı tek örnekleme noktası. "İstisnasız her
 * şeyi izleyeceğiz" hedefinin somut karşılığı burası: her test döngüsü
 * belirli aralıklarla (varsayılan 250ms) bu sınıfı çağırıp bir
 * MetricsSnapshot alır, bu da JSON rapor şemasındaki timeseries[] dizisinin
 * her elemanına karşılık gelir.
 *
 * Root modu ayrı tutulur (rootZoneReading alanları) — normal ölçümle
 * asla karıştırılmaz, sadece kullanılabilirse doldurulur.
 */
class MetricsCollector(context: Context) {

    private val batteryMonitor = BatteryMonitor(context)
    private val memoryMonitor = MemoryMonitor(context)
    private val cpuUsageMonitor = CpuUsageMonitor()
    private val thermalZoneReader = ThermalZoneReader()
    private val thermalMonitor = ThermalMonitor(context)

    /**
     * Root erişimi varsa dışarıdan enjekte edilir (RootThermalReader,
     * ayrı bir modülde tanımlanacak). Yoksa null kalır ve ilgili
     * alanlar UNAVAILABLE olarak işaretlenir.
     */
    var rootThermalReader: RootThermalReader? = null

    fun snapshot(elapsedMs: Long, testSpecific: Map<String, Double> = emptyMap()): MetricsSnapshot {
        val thermal = thermalMonitor.currentStatus()
        val battery = batteryMonitor.snapshot()
        val memory = memoryMonitor.snapshot()

        return MetricsSnapshot(
            elapsedMs = elapsedMs,
            thermalStatus = thermal.status.name,
            thermalHeadroom = if (thermal.supported) {
                certain(thermal.headroom, "PowerManager.getThermalHeadroom")
            } else {
                unavailable("PowerManager.getThermalHeadroom:unsupported_below_api29")
            },
            batteryTemperatureC = battery.temperatureC,
            batteryLevelPct = battery.levelPct,
            batteryCurrentMicroAmps = battery.currentMicroAmps,
            cpuUsageTotalPct = cpuUsageMonitor.totalUsagePct(),
            cpuUsagePerCorePct = cpuUsageMonitor.perCoreUsagePct(),
            cpuTempEstimateC = thermalZoneReader.readCategory(ThermalZoneCategory.CPU),
            gpuTempEstimateC = thermalZoneReader.readCategory(ThermalZoneCategory.GPU),
            cpuTempRootC = rootThermalReader?.readCpuTemp() ?: unavailable("root_not_available"),
            ramUsedMb = memory.appUsedMb,
            gcCumulativeCount = memoryMonitor.cumulativeGcPauseCount(),
            testSpecificValues = testSpecific,
        )
    }

    /** Testlerin acil durdurma kararını değerlendirmek için doğrudan erişebileceği okuma. */
    fun rawThermalReading(): ThermalReading = thermalMonitor.currentStatus()
}

/**
 * Root erişimiyle thermal_zone dosyalarını SELinux kısıtlaması olmadan
 * okuyan arayüz. Gerçek implementasyon (libsu tabanlı) ayrı bir dosyada
 * tanımlanacak; burada sadece sözleşme (contract) tanımlanıyor ki
 * MetricsCollector root olsun olmasın aynı şekilde çalışabilsin.
 */
interface RootThermalReader {
    fun readCpuTemp(): MeasuredValue<Float>
    fun readGpuTemp(): MeasuredValue<Float>
}

/**
 * Uygulama içi (runtime) veri modeli. JSON export sırasında
 * MetricsSnapshotJson.from(this) ile somut, doğrudan serileştirilebilir
 * bir DTO'ya çevrilir (bkz. core/monitoring/json/MetricsSnapshotJson.kt).
 */
data class MetricsSnapshot(
    val elapsedMs: Long,
    val thermalStatus: String,
    val thermalHeadroom: MeasuredValue<Float>,
    val batteryTemperatureC: MeasuredValue<Float>,
    val batteryLevelPct: MeasuredValue<Int>,
    val batteryCurrentMicroAmps: MeasuredValue<Int>,
    val cpuUsageTotalPct: MeasuredValue<Float>,
    val cpuUsagePerCorePct: MeasuredValue<List<Float>>,
    val cpuTempEstimateC: MeasuredValue<Float>,
    val gpuTempEstimateC: MeasuredValue<Float>,
    val cpuTempRootC: MeasuredValue<Float>,
    val ramUsedMb: MeasuredValue<Float>,
    val gcCumulativeCount: MeasuredValue<Int>,
    /** Teste özel değerler (örn. entity_count, fps, frame_time_ms). */
    val testSpecificValues: Map<String, Double>,
)

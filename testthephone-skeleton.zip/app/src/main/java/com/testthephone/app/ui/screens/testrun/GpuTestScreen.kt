package com.testthephone.app.ui.screens.testrun

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.report.TestResult
import com.testthephone.app.tests.gpu.GpuStressCanvas
import com.testthephone.app.tests.gpu.GpuTestController
import com.testthephone.app.tests.gpu.GpuTestMode
import com.testthephone.app.ui.theme.AppColors
import kotlinx.coroutines.flow.StateFlow

/**
 * Test 3'ün (GPU render) ekran katmanı. GpuStressCanvas + GpuTestController'ı
 * kurup birbirine bağlar, controller "finished" olduğunda onFinished
 * callback'i ile çağıran tarafa haber verir.
 *
 * result parametresi dışarıdan geliyor (MainActivity tarafından
 * oluşturulup TestRunner.registerExternalTestResult ile session'a
 * eklenmiş oluyor) — bu, GPU testinin de diğer testlerle aynı
 * TestResult/JSON şemasına yazmasını sağlıyor.
 */
@Composable
fun GpuTestScreen(
    metricsCollector: MetricsCollector,
    safetyDecision: StateFlow<SafetyDecision>,
    result: TestResult,
    onFinished: () -> Unit,
) {
    val controller = remember {
        GpuTestController(
            metricsCollector = metricsCollector,
            safetyDecision = safetyDecision,
            result = result,
        )
    }
    val uiState by controller.state.collectAsState()

    LaunchedEffect(uiState.finished) {
        if (uiState.finished) onFinished()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
    ) {
        Text(
            text = stringResource(R.string.gpu_test_title),
            style = MaterialTheme.typography.titleMedium,
            color = AppColors.TextPrimary,
        )
        val modeLabelRes = if (uiState.mode == GpuTestMode.AGSL_SHADER) {
            R.string.gpu_test_mode_agsl
        } else {
            R.string.gpu_test_mode_canvas
        }
        val modeLabel = stringResource(modeLabelRes)
        Text(
            text = stringResource(R.string.gpu_test_step, uiState.currentStep.stepIndex + 1, modeLabel),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextMuted,
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 12.dp),
        ) {
            GpuStressCanvas(
                mode = uiState.mode,
                currentStep = uiState.currentStep,
                modifier = Modifier.fillMaxSize(),
                onFrameMeasured = { frameTimeMs, stepIndex ->
                    controller.onFrame(frameTimeMs, stepIndex)
                },
            )
        }
    }
}

package com.testthephone.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Roboto, Android'in native fontu — kararlaştırdığımız gibi. Sabit
 * genişlikli rakam gösterimi (canlı değişen FPS/sıcaklık gibi
 * metriklerde metnin zıplamaması için) Compose'ta doğrudan bir
 * Typography parametresi değil, ilgili Text bileşenlerinde
 * FontFeatureSettings("tnum") ile ayrıca etkinleştirilir
 * (bkz. ui/components/MetricText.kt).
 */
private val AppFontFamily = FontFamily.Default // Roboto, Android'de sistem varsayılanı.

private val AppTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 20.sp,
    ),
    titleMedium = TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
    ),
    bodySmall = TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = AppFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
    ),
)

private fun colorSchemeFor(palette: AppColorPalette, darkTheme: Boolean) = if (darkTheme) {
    darkColorScheme(
        background = palette.Background,
        surface = palette.Surface2,
        onBackground = palette.TextPrimary,
        onSurface = palette.TextPrimary,
        primary = palette.FillPrimary,
        onPrimary = palette.OnPrimary,
        error = palette.FillDanger,
        onError = palette.OnDanger,
        outline = palette.Border,
    )
} else {
    lightColorScheme(
        background = palette.Background,
        surface = palette.Surface2,
        onBackground = palette.TextPrimary,
        onSurface = palette.TextPrimary,
        primary = palette.FillPrimary,
        onPrimary = palette.OnPrimary,
        error = palette.FillDanger,
        onError = palette.OnDanger,
        outline = palette.Border,
    )
}

/**
 * darkTheme parametresi, Ayarlar > Koyu tema anahtarından (DataStore
 * üzerinden MainActivity'de collectAsState ile okunup buraya geçirilen
 * darkThemeEnabled) gelir. Bu parametre gerçekten bir şey yapmıyor
 * OLABİLİRDİ eğer AppColors sabit bir object kalsaydı — bkz.
 * AppColors.kt'deki CompositionLocal geçişi, bu boşluğu kapatan asıl
 * değişiklik.
 */
@Composable
fun TestThePhoneTheme(darkTheme: Boolean = false, content: @Composable () -> Unit) {
    val palette = if (darkTheme) DarkAppColors else LightAppColors
    CompositionLocalProvider(LocalAppColors provides palette) {
        MaterialTheme(
            colorScheme = colorSchemeFor(palette, darkTheme),
            typography = AppTypography,
            content = content,
        )
    }
}


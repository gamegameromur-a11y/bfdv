package com.testthephone.app.tests

import com.testthephone.app.core.monitoring.MetricsSnapshot
import com.testthephone.app.core.safety.SafetyDecision
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * Tüm testlerin (entity spawn, GPU render, sürdürülebilir performans, vb.)
 * uyduğu ortak sözleşme. Her test kendi iş yükünü üretir, ama örnekleme,
 * güvenlik kontrolü ve rapor birleştirme mantığı TestRunner'da ortak.
 */
interface TestEngine {
    val testId: String
    val displayNameKey: String // Lokalizasyon anahtarı, UI dil dosyalarına karşılık gelir.

    /**
     * Testi başlatır ve ilerleme olaylarını akış olarak yayınlar.
     * SafetyController'dan gelen PAUSE_REQUIRED kararında, çağıran taraf
     * (TestRunner) bu akışı iptal eder — test motoru kendi kendine
     * güvenlik kararı vermez, sadece dışarıdan gelen sinyale uyar.
     */
    fun run(context: TestExecutionContext): Flow<TestProgressEvent>
}

/**
 * Bir testin çalışması için gereken bağlam: mevcut güvenlik kararı akışı,
 * cihaza özel kalibrasyon parametreleri, örnekleme aralığı.
 *
 * safetyDecision bir StateFlow'dur — test motorları .value ile her döngü
 * adımında ANLIK, en güncel kararı okur (kuyruğa alınmış eski bir değeri
 * değil). Bu, "acil durdurma kararı gecikmesin" gereksiniminin doğrudan
 * karşılığıdır.
 */
data class TestExecutionContext(
    val safetyDecision: StateFlow<SafetyDecision>,
    val calibration: DeviceCalibration,
    val samplingIntervalMs: Long = 250L,
)

/**
 * Cihaz profiline göre ayarlanmış test parametreleri. Önceden konuştuğumuz
 * "her sonuca özel test" / adaptif kalibrasyon mantığının veri modeli —
 * düşük segment bir cihazda başlangıç entity sayısı ve artış adımı, üst
 * segment bir cihaza göre çok daha küçük olmalı; aksi halde test süresi
 * ya anlamsız uzar ya da ilk adımda cihaz zaten zorlanır.
 */
data class DeviceCalibration(
    val cpuCoreCount: Int,
    val totalRamMb: Int,
    val initialEntityCount: Int,
    val entityCountStep: Int,
    val maxEntityCountCap: Int,
) {
    companion object {
        /**
         * Basit, şeffaf bir kalibrasyon kuralı: çekirdek sayısı ve RAM'e
         * göre ölçeklenir. Karmaşık bir makine öğrenmesi modeli değil,
         * bilinçli ve açıklanabilir bir doğrusal ölçekleme — raporda
         * "adaptive_calibration" alanına bu girdi değerleriyle birlikte
         * yazılacağı için şeffaf olması önemli.
         */
        fun forDevice(cpuCoreCount: Int, totalRamMb: Int): DeviceCalibration {
            val ramFactor = (totalRamMb / 1024).coerceIn(1, 24) // GB cinsinden, mantıklı bir aralığa sıkıştır.
            val coreFactor = cpuCoreCount.coerceIn(1, 16)

            return DeviceCalibration(
                cpuCoreCount = cpuCoreCount,
                totalRamMb = totalRamMb,
                initialEntityCount = 500 * coreFactor,
                entityCountStep = 250 * coreFactor,
                maxEntityCountCap = 2000 * ramFactor,
            )
        }
    }
}

/** Testin her örnekleme adımında yayınladığı ilerleme olayı. */
sealed interface TestProgressEvent {
    data class Sample(val snapshot: MetricsSnapshot) : TestProgressEvent
    data class Paused(val reason: String) : TestProgressEvent
    data class Completed(val summary: Map<String, Double>) : TestProgressEvent
    data class Aborted(val reason: String) : TestProgressEvent
}

package com.testthephone.app.core.storage

import android.content.Context
import com.testthephone.app.report.ReportJsonWriter
import com.testthephone.app.report.TestSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Tamamlanan test oturumlarını cihazda kalıcı olarak saklar (JSON
 * dosyaları, filesDir/reports/ altında — ReportJsonWriter'ın zaten
 * yazdığı formatın aynısı) ve Geçmiş sekmesinin listeleyebilmesi için
 * hafif bir özet (SessionSummary) üretir.
 *
 * Tam JSON dosyasını her seferinde okumak yerine, listeleme için sadece
 * dosya adından (sessionId, timestamp) türetilen özet bilgi kullanılır
 * — Geçmiş ekranı açıldığında onlarca büyük JSON dosyasını tek tek
 * ayrıştırmak gereksiz maliyetli olurdu.
 */
class SessionHistoryStore(private val context: Context) {

    private val reportsDir: File
        get() = File(context.filesDir, "reports").apply { mkdirs() }

    private val reportWriter = ReportJsonWriter()

    suspend fun saveSession(session: TestSession): File = withContext(Dispatchers.IO) {
        val outFile = File(reportsDir, "session_${session.sessionId}.json")
        reportWriter.writeToFile(session, outFile)
        outFile
    }

    /**
     * Kayıtlı oturumların özetini, en yeniden en eskiye sıralı döner.
     * Dosya adından sessionId'yi, dosyanın son değiştirilme zamanından
     * tarihi çıkarır — tam JSON'u parse etmeden hızlı bir liste sağlar.
     */
    suspend fun listSessionSummaries(): List<SessionSummary> = withContext(Dispatchers.IO) {
        val dir = reportsDir
        if (!dir.exists()) return@withContext emptyList()

        dir.listFiles { file -> file.isFile && file.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() }
            ?.mapNotNull { file ->
                val sessionId = file.name.removePrefix("session_").removeSuffix(".json")
                if (sessionId.isBlank()) null else SessionSummary(
                    sessionId = sessionId,
                    filePath = file.absolutePath,
                    savedAtMillis = file.lastModified(),
                )
            }
            ?: emptyList()
    }

    suspend fun deleteSession(sessionId: String): Boolean = withContext(Dispatchers.IO) {
        File(reportsDir, "session_$sessionId.json").delete()
    }

    fun sessionFile(sessionId: String): File = File(reportsDir, "session_$sessionId.json")
}

data class SessionSummary(
    val sessionId: String,
    val filePath: String,
    val savedAtMillis: Long,
)

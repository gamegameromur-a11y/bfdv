package com.testthephone.app.core.monitoring.json

import com.testthephone.app.core.monitoring.Confidence
import com.testthephone.app.core.monitoring.MeasuredValue
import com.testthephone.app.core.monitoring.MetricsSnapshot
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject

/**
 * kotlinx.serialization generic tip parametreleri için otomatik serializer
 * üretemediğinden (MeasuredValue<T> çağrı yerinde somutlaştırılmadıkça),
 * runtime modelini burada elle, alan alan somut JSON'a çeviriyoruz.
 *
 * Bu, JSON şemasındaki { "value": ..., "confidence": "...", "source": "..." }
 * yapısının birebir karşılığıdır — rapor tasarımında kararlaştırdığımız
 * güven-etiketli metrik formatı.
 */
@Serializable
data class MeasuredValueJson(
    val value: JsonElement,
    val confidence: String,
    val source: String,
)

/**
 * ÖNEMLİ VERİ BÜTÜNLÜĞÜ DÜZELTMESİ: kotlinx.serialization'ın JsonPrimitive'i,
 * bir Double/Float değeri NaN veya Infinite olduğunda İSTİSNA FIRLATIR
 * (varsayılan Json yapılandırması bunlara izin vermez). Bu proje, test
 * sonuçlarını sayısal bölme işlemleriyle üretiyor (FPS = 1000/frameTime,
 * speedup = baseline/elapsed, çeşitli oranlar vb.) — bölen değerin bazı
 * uç durumlarda (örn. System.nanoTime() çözünürlük sınırına takılan çok
 * hızlı bir işlem, ya da beklenmedik bir sensör okuması) 0 veya NaN
 * olması teorik olarak mümkün. Böyle bir değer JsonPrimitive'e SARILMAYA
 * ÇALIŞILDIĞI AN (test bittiğinde, rapor dosyaya yazılırken) kontrolsüz
 * bir istisna fırlar — bu da kullanıcının SADECE O TESTİ değil, o ana
 * kadar biriktirdiği TÜM oturumun raporunu kaybetmesi anlamına gelir
 * (writeToFile tek bir JSON belgesi yazıyor, kısmi yazma yok).
 *
 * Play Store'daki gerçek kullanıcılar için bu, "en ufak bir hata bile
 * kul hakkı olabilir" ilkesiyle doğrudan çelişen bir senaryo: kullanıcı
 * 10 dakikalık bir testi tamamlar, sonucu görmeyi bekler, ama arka
 * planda tek bir NaN/Infinity değeri yüzünden hiçbir şey kaydedilmez.
 *
 * Çözüm: NaN/Infinity değerleri SESSİZCE ATMAK yerine (bu da veriyi
 * gizler, "doğru rapor" ilkesini ihlal eder), JSON'da null olarak
 * yazıyoruz — MeasuredValue şemasındaki "okunamadı" sözleşmesiyle
 * tutarlı, ve raporu okuyan taraf (AI/teknik servis) bunu "bu metrik
 * için geçerli bir değer hesaplanamadı" olarak yorumlayabilir; sessizce
 * 0 yazmak YANLIŞ bir sayı vermek olurdu, bu da rapor doğruluğunu
 * doğrudan zedeler.
 */
private fun safeJsonPrimitive(value: Float): JsonElement =
    if (value.isNaN() || value.isInfinite()) JsonNull else JsonPrimitive(value)

private fun safeJsonPrimitive(value: Double): JsonElement =
    if (value.isNaN() || value.isInfinite()) JsonNull else JsonPrimitive(value)

fun <T> MeasuredValue<T>.toJson(valueToJson: (T) -> JsonElement): MeasuredValueJson =
    MeasuredValueJson(
        value = value?.let(valueToJson) ?: JsonNull,
        confidence = confidence.name.lowercase(),
        source = source,
    )

// NOT: Kotlin'de generic tip parametreleri JVM bytecode düzeyinde erasure'a
// uğrar (MeasuredValue<Float>, MeasuredValue<Int> vb. hepsi aynı ham
// MeasuredValue sınıfına indirgenir). Bu yüzden aynı isimde (toJson) birden
// fazla extension function farklı T'ler için tanımlanamaz — derleyici bunları
// aynı JVM imzasına sahip olarak görür ("platform declaration clash").
// Çözüm: her somut tip için ayrı isimli extension function kullanmak.
fun MeasuredValue<Float>.floatToJson(): MeasuredValueJson = toJson { safeJsonPrimitive(it) }
fun MeasuredValue<Int>.intToJson(): MeasuredValueJson = toJson { JsonPrimitive(it) }
fun MeasuredValue<Boolean>.boolToJson(): MeasuredValueJson = toJson { JsonPrimitive(it) }
fun MeasuredValue<List<Float>>.floatListToJson(): MeasuredValueJson = toJson { list ->
    buildJsonArray { list.forEach { add(safeJsonPrimitive(it)) } }
}

/**
 * MetricsSnapshot'ı, JSON rapor şemasındaki timeseries[] elemanı formatına
 * çevirir. Her alan MeasuredValueJson (value/confidence/source üçlüsü)
 * olarak yazılır; testSpecificValues ise doğrudan sayısal alanlar olarak
 * düzleştirilir (entity_count, fps, frame_time_ms gibi).
 */
fun MetricsSnapshot.toJsonObject() = buildJsonObject {
    put("elapsed_ms", JsonPrimitive(elapsedMs))
    put("thermal_status", JsonPrimitive(thermalStatus))
    put("thermal_headroom", jsonOf(thermalHeadroom.floatToJson()))
    put("battery_temp_c", jsonOf(batteryTemperatureC.floatToJson()))
    put("battery_level_pct", jsonOf(batteryLevelPct.intToJson()))
    put("battery_current_ua", jsonOf(batteryCurrentMicroAmps.intToJson()))
    put("cpu_usage_pct_total", jsonOf(cpuUsageTotalPct.floatToJson()))
    put("cpu_usage_per_core_pct", jsonOf(cpuUsagePerCorePct.floatListToJson()))
    put("cpu_temp_c_estimated", jsonOf(cpuTempEstimateC.floatToJson()))
    put("gpu_temp_c_estimated", jsonOf(gpuTempEstimateC.floatToJson()))
    put("cpu_temp_c_root", jsonOf(cpuTempRootC.floatToJson()))
    put("ram_used_mb", jsonOf(ramUsedMb.floatToJson()))
    put("gc_cumulative_count", jsonOf(gcCumulativeCount.intToJson()))
    // testSpecificValues (fps, speedup_vs_single_core, parallel_efficiency,
    // sustained_to_burst_ratio gibi test motorlarının ürettiği serbest
    // biçimli sayısal alanlar) de aynı NaN/Infinity güvenlik ağından
    // geçiyor — yukarıdaki gerekçe (safeJsonPrimitive) burada da geçerli.
    testSpecificValues.forEach { (key, v) -> put(key, safeJsonPrimitive(v)) }
}

// buildJsonObject DSL'i içinde iç içe obje eklemek için küçük yardımcı.
private fun jsonOf(measured: MeasuredValueJson): JsonElement = buildJsonObject {
    put("value", measured.value)
    put("confidence", JsonPrimitive(measured.confidence))
    put("source", JsonPrimitive(measured.source))
}

package com.testthephone.app.core.monitoring.json

import com.testthephone.app.core.monitoring.Confidence
import com.testthephone.app.core.monitoring.MeasuredValue
import com.testthephone.app.core.monitoring.MetricsSnapshot
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject

/**
 * kotlinx.serialization generic tip parametreleri için otomatik serializer
 * üretemediğinden (MeasuredValue<T> çağrı yerinde somutlaştırılmadıkça),
 * runtime modelini burada elle, alan alan somut JSON'a çeviriyoruz.
 *
 * Bu, JSON şemasındaki { "value": ..., "confidence": "...", "source": "..." }
 * yapısının birebir karşılığıdır — rapor tasarımında kararlaştırdığımız
 * güven-etiketli metrik formatı.
 */
@Serializable
data class MeasuredValueJson(
    val value: JsonElement,
    val confidence: String,
    val source: String,
)

fun <T> MeasuredValue<T>.toJson(valueToJson: (T) -> JsonElement): MeasuredValueJson =
    MeasuredValueJson(
        value = value?.let(valueToJson) ?: JsonNull,
        confidence = confidence.name.lowercase(),
        source = source,
    )

// NOT: Kotlin'de generic tip parametreleri JVM bytecode düzeyinde erasure'a
// uğrar (MeasuredValue<Float>, MeasuredValue<Int> vb. hepsi aynı ham
// MeasuredValue sınıfına indirgenir). Bu yüzden aynı isimde (toJson) birden
// fazla extension function farklı T'ler için tanımlanamaz — derleyici bunları
// aynı JVM imzasına sahip olarak görür ("platform declaration clash").
// Çözüm: her somut tip için ayrı isimli extension function kullanmak.
fun MeasuredValue<Float>.floatToJson(): MeasuredValueJson = toJson { JsonPrimitive(it) }
fun MeasuredValue<Int>.intToJson(): MeasuredValueJson = toJson { JsonPrimitive(it) }
fun MeasuredValue<Boolean>.boolToJson(): MeasuredValueJson = toJson { JsonPrimitive(it) }
fun MeasuredValue<List<Float>>.floatListToJson(): MeasuredValueJson = toJson { list ->
    buildJsonArray { list.forEach { add(JsonPrimitive(it)) } }
}

/**
 * MetricsSnapshot'ı, JSON rapor şemasındaki timeseries[] elemanı formatına
 * çevirir. Her alan MeasuredValueJson (value/confidence/source üçlüsü)
 * olarak yazılır; testSpecificValues ise doğrudan sayısal alanlar olarak
 * düzleştirilir (entity_count, fps, frame_time_ms gibi).
 */
fun MetricsSnapshot.toJsonObject() = buildJsonObject {
    put("elapsed_ms", JsonPrimitive(elapsedMs))
    put("thermal_status", JsonPrimitive(thermalStatus))
    put("thermal_headroom", jsonOf(thermalHeadroom.floatToJson()))
    put("battery_temp_c", jsonOf(batteryTemperatureC.floatToJson()))
    put("battery_level_pct", jsonOf(batteryLevelPct.intToJson()))
    put("battery_current_ua", jsonOf(batteryCurrentMicroAmps.intToJson()))
    put("cpu_usage_pct_total", jsonOf(cpuUsageTotalPct.floatToJson()))
    put("cpu_usage_per_core_pct", jsonOf(cpuUsagePerCorePct.floatListToJson()))
    put("cpu_temp_c_estimated", jsonOf(cpuTempEstimateC.floatToJson()))
    put("gpu_temp_c_estimated", jsonOf(gpuTempEstimateC.floatToJson()))
    put("cpu_temp_c_root", jsonOf(cpuTempRootC.floatToJson()))
    put("ram_used_mb", jsonOf(ramUsedMb.floatToJson()))
    put("gc_cumulative_count", jsonOf(gcCumulativeCount.intToJson()))
    testSpecificValues.forEach { (key, v) -> put(key, JsonPrimitive(v)) }
}

// buildJsonObject DSL'i içinde iç içe obje eklemek için küçük yardımcı.
private fun jsonOf(measured: MeasuredValueJson): JsonElement = buildJsonObject {
    put("value", measured.value)
    put("confidence", JsonPrimitive(measured.confidence))
    put("source", JsonPrimitive(measured.source))
}

package com.testthephone.app.report

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.testthephone.app.tests.DeviceCalibration

/**
 * Test oturumu başlamadan önce bir kez çalışır: cihazın statik profilini
 * (model, çekirdek sayısı, RAM, root durumu) toplar ve buna göre
 * DeviceCalibration'ı üretir. Root/tamper tespiti burada entegre edilir
 * çünkü rapor şemasında device_profile.rootedOrModified alanı bu adımda
 * doldurulmalı — testler başlamadan önce bilinmesi gereken bir bilgi.
 */
class DeviceProfiler(private val context: Context) {

    fun collect(integrityChecker: DeviceIntegrityChecker): DeviceProfile {
        val activityManager = context.applicationContext
            .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val cpuCoreCount = Runtime.getRuntime().availableProcessors()
        val ramTotalMb = memInfo.totalMem / (1024 * 1024)

        val integrityResult = integrityChecker.check()

        val calibration = DeviceCalibration.forDevice(
            cpuCoreCount = cpuCoreCount,
            totalRamMb = ramTotalMb.toInt(),
        )

        return DeviceProfile(
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE ?: "unknown",
            sdkInt = Build.VERSION.SDK_INT,
            cpuCoreCount = cpuCoreCount,
            abi = Build.SUPPORTED_ABIS?.toList() ?: emptyList(),
            ramTotalMb = ramTotalMb,
            rootedOrModified = integrityResult.rootedOrModified,
            integrityVerdict = integrityResult.verdictLabel,
            adaptiveCalibration = AdaptiveCalibrationInfo(
                initialEntityCount = calibration.initialEntityCount,
                entityCountStep = calibration.entityCountStep,
                maxEntityCountCap = calibration.maxEntityCountCap,
            ),
        )
    }

    /** DeviceProfiler ile eşleşen kalibrasyonu ayrı almak isteyen çağıranlar için. */
    fun calibrationFor(cpuCoreCount: Int, ramTotalMb: Int): DeviceCalibration =
        DeviceCalibration.forDevice(cpuCoreCount, ramTotalMb)

    /**
     * collect() içindeki ActivityManager.getMemoryInfo veya
     * integrityChecker.check() çağrılarından biri beklenmedik bir istisna
     * fırlatırsa (örn. bazı OEM ROM'larında sistem servisi bağlama hatası)
     * kullanılacak minimal ama GEÇERLİ bir profil. Build.* alanları statik
     * sabitler olduğu için exception riski taşımaz, bu yüzden onları
     * olduğu gibi koruyoruz — sadece dinamik/riskli ölçümleri (RAM, root
     * tespiti) muhafazakar varsayılanlara düşürüyoruz. cpuCoreCount için
     * Runtime.getRuntime().availableProcessors() pratikte hiçbir zaman
     * exception fırlatmayan güvenli bir JVM API'si olduğundan yine de
     * çağrılıyor; 1'in altına asla düşmeyeceği JVM sözleşmesiyle garanti.
     */
    fun fallbackProfile(): DeviceProfile {
        val cpuCoreCount = runCatching { Runtime.getRuntime().availableProcessors() }.getOrDefault(4)
        return DeviceProfile(
            manufacturer = Build.MANUFACTURER ?: "unknown",
            model = Build.MODEL ?: "unknown",
            androidVersion = Build.VERSION.RELEASE ?: "unknown",
            sdkInt = Build.VERSION.SDK_INT,
            cpuCoreCount = cpuCoreCount,
            abi = Build.SUPPORTED_ABIS?.toList() ?: emptyList(),
            // 4096 MB: hiçbir gerçek cihazı yanıltıcı biçimde çok güçlü ya
            // da çok zayıf göstermeyen, orta seviye bir muhafazakar varsayım
            // — DeviceCalibration.forDevice bunu makul bir kalibrasyona
            // çevirir, test motorları çökmez.
            ramTotalMb = 4096L,
            rootedOrModified = false,
            integrityVerdict = "unchecked_startup_fallback",
            adaptiveCalibration = DeviceCalibration.forDevice(cpuCoreCount, 4096).let {
                AdaptiveCalibrationInfo(
                    initialEntityCount = it.initialEntityCount,
                    entityCountStep = it.entityCountStep,
                    maxEntityCountCap = it.maxEntityCountCap,
                )
            },
        )
    }
}

/**
 * Root/tamper tespitinin sözleşmesi. Gerçek implementasyon (RootBeer +
 * opsiyonel Play Integrity API) core/safety/integrity paketinde ayrı
 * bir dosyada tanımlanacak — burada sadece arayüz var ki DeviceProfiler
 * hangi yöntemin kullanıldığından bağımsız çalışsın.
 */
interface DeviceIntegrityChecker {
    fun check(): IntegrityResult
}

data class IntegrityResult(
    val rootedOrModified: Boolean,
    /** Örn. "MEETS_DEVICE_INTEGRITY", "rootbeer_local_only", "unchecked". */
    val verdictLabel: String,
)

package com.testthephone.app.report

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.testthephone.app.tests.DeviceCalibration

/**
 * Test oturumu başlamadan önce bir kez çalışır: cihazın statik profilini
 * (model, çekirdek sayısı, RAM, root durumu) toplar ve buna göre
 * DeviceCalibration'ı üretir. Root/tamper tespiti burada entegre edilir
 * çünkü rapor şemasında device_profile.rootedOrModified alanı bu adımda
 * doldurulmalı — testler başlamadan önce bilinmesi gereken bir bilgi.
 */
class DeviceProfiler(private val context: Context) {

    fun collect(integrityChecker: DeviceIntegrityChecker): DeviceProfile {
        val activityManager = context.applicationContext
            .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val cpuCoreCount = Runtime.getRuntime().availableProcessors()
        val ramTotalMb = memInfo.totalMem / (1024 * 1024)

        val integrityResult = integrityChecker.check()

        val calibration = DeviceCalibration.forDevice(
            cpuCoreCount = cpuCoreCount,
            totalRamMb = ramTotalMb.toInt(),
        )

        return DeviceProfile(
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE ?: "unknown",
            sdkInt = Build.VERSION.SDK_INT,
            cpuCoreCount = cpuCoreCount,
            abi = Build.SUPPORTED_ABIS?.toList() ?: emptyList(),
            ramTotalMb = ramTotalMb,
            rootedOrModified = integrityResult.rootedOrModified,
            integrityVerdict = integrityResult.verdictLabel,
            adaptiveCalibration = AdaptiveCalibrationInfo(
                initialEntityCount = calibration.initialEntityCount,
                entityCountStep = calibration.entityCountStep,
                maxEntityCountCap = calibration.maxEntityCountCap,
            ),
        )
    }

    /** DeviceProfiler ile eşleşen kalibrasyonu ayrı almak isteyen çağıranlar için. */
    fun calibrationFor(cpuCoreCount: Int, ramTotalMb: Int): DeviceCalibration =
        DeviceCalibration.forDevice(cpuCoreCount, ramTotalMb)
}

/**
 * Root/tamper tespitinin sözleşmesi. Gerçek implementasyon (RootBeer +
 * opsiyonel Play Integrity API) core/safety/integrity paketinde ayrı
 * bir dosyada tanımlanacak — burada sadece arayüz var ki DeviceProfiler
 * hangi yöntemin kullanıldığından bağımsız çalışsın.
 */
interface DeviceIntegrityChecker {
    fun check(): IntegrityResult
}

data class IntegrityResult(
    val rootedOrModified: Boolean,
    /** Örn. "MEETS_DEVICE_INTEGRITY", "rootbeer_local_only", "unchecked". */
    val verdictLabel: String,
)

package com.testthephone.app.ui.navigation

/**
 * Tip güvenli rota tanımları. String tabanlı Compose Navigation
 * route'ları yerine sealed interface kullanmak, ekran parametrelerinin
 * (örn. hangi testin çalıştığı) derleme zamanında kontrol edilmesini
 * sağlıyor — testId'yi yanlış yazma riski ortadan kalkıyor.
 */
sealed interface Screen {
    data object Home : Screen
    data object History : Screen
    data object Settings : Screen

    /** Tam test akışı: tüm testler sırayla, TestRunner üzerinden. */
    data object FullTestRun : Screen

    /** Tek bir testin detay/başlatma ekranı. */
    data class SingleTest(val testId: String) : Screen

    /** Bir oturumun tamamlanmış raporunun görüntülendiği ekran. */
    data class ReportDetail(val sessionId: String) : Screen

    /** İlk açılışta zorunlu EULA onay ekranı. */
    data object EulaConsent : Screen
}

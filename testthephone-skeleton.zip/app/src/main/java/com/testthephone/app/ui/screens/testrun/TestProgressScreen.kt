package com.testthephone.app.ui.screens.testrun

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.core.safety.ThermalStatus
import com.testthephone.app.ui.components.MetricText
import com.testthephone.app.ui.theme.AppColors
import com.testthephone.app.ui.theme.StatusColor
import com.testthephone.app.ui.theme.StatusTier

/**
 * Önceki mockup'ta tasarladığımız "test sırasında" ekranının gerçek
 * implementasyonu. Durum rengi (yeşil→sarı→kırmızı) burada canlı
 * olarak, animasyonlu geçişle görünür — ThermalStatus değiştikçe
 * progressBar ve metrik kartlarının rengi yumuşak geçişle güncellenir.
 *
 * "Yumuşak geçişler" talebi animateColorAsState ile karşılanıyor:
 * renk anlık sıçramıyor, ~400ms'lik bir tween ile eski renkten yeniye
 * kayıyor.
 */
@Composable
fun TestProgressScreen(
    testDisplayName: String,
    thermalStatus: ThermalStatus,
    progressFraction: Float, // 0f-1f arası, testin tahmini ilerlemesi.
    metrics: List<LiveMetric>,
) {
    val tier = StatusColor.tierFor(thermalStatus)
    val (gradientStart, gradientEnd) = StatusColor.gradientFor(tier)

    val animatedStart by animateColorAsState(
        targetValue = gradientStart,
        animationSpec = tween(durationMillis = 400),
        label = "status_gradient_start",
    )
    val animatedEnd by animateColorAsState(
        targetValue = gradientEnd,
        animationSpec = tween(durationMillis = 400),
        label = "status_gradient_end",
    )
    val animatedMetricColor by animateColorAsState(
        targetValue = StatusColor.solidFor(tier),
        animationSpec = tween(durationMillis = 400),
        label = "status_metric_color",
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = testDisplayName,
                style = MaterialTheme.typography.titleMedium,
                color = AppColors.TextPrimary,
                fontWeight = FontWeight.Medium,
            )
            StatusBadge(tier = tier, background = animatedEnd)
        }

        // İlerleme çubuğu — durum rengiyle aynı gradyanı kullanır,
        // testin ne kadar ilerlediğini VE sistemin ne kadar zorlandığını
        // tek bir görsel öğede birleştiriyor.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 20.dp)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color = AppColors.Surface1),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progressFraction.coerceIn(0f, 1f))
                    .fillMaxSize()
                    .clip(RoundedCornerShape(3.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(animatedStart, animatedEnd),
                        ),
                    ),
            )
        }

        MetricGrid(metrics = metrics, accentColor = animatedMetricColor, tier = tier)
    }
}

@Composable
private fun StatusBadge(tier: StatusTier, background: Color) {
    val labelRes = when (tier) {
        StatusTier.CALM -> R.string.progress_status_calm
        StatusTier.WARNING -> R.string.progress_status_warning
        StatusTier.CRITICAL -> R.string.progress_status_critical
    }
    Text(
        text = stringResource(labelRes),
        style = MaterialTheme.typography.labelSmall,
        color = AppColors.TextPrimary,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color = background.copy(alpha = 0.35f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
private fun MetricGrid(metrics: List<LiveMetric>, accentColor: Color, tier: StatusTier) {
    // 2 sütunlu basit ızgara — LazyVerticalGrid yerine chunked ile
    // manuel bölme, sabit ve küçük bir liste için yeterli, ekstra
    // bağımlılık gerektirmiyor.
    metrics.chunked(2).forEach { rowMetrics ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            rowMetrics.forEach { metric ->
                MetricCard(
                    metric = metric,
                    accentColor = accentColor,
                    tier = tier,
                    modifier = Modifier.weight(1f),
                )
            }
            // Tek sayıda metrik varsa son satırda boşluk dengelemesi.
            if (rowMetrics.size == 1) {
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MetricCard(
    metric: LiveMetric,
    accentColor: Color,
    tier: StatusTier,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(color = AppColors.Surface1, shape = RoundedCornerShape(10.dp))
            .padding(12.dp),
    ) {
        Text(
            text = stringResource(metric.labelRes),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextMuted,
        )
        MetricText(
            text = metric.valueRes?.let { stringResource(it) } ?: metric.value,
            modifier = Modifier.padding(top = 4.dp),
            // Sadece "dikkat gerektiren" olarak işaretlenmiş metrikler
            // (örn. sıcaklık, termal durum) durum rengini alır; entity
            // sayısı gibi nötr metrikler her zaman TextPrimary kalır —
            // renk sadece gerçekten anlam taşıdığında kullanılmalı.
            color = if (metric.reflectsSystemStatus && tier != StatusTier.CALM) {
                accentColor
            } else {
                AppColors.TextPrimary
            },
        )
    }
}

/**
 * Test ilerleme ekranında gösterilecek tek bir canlı metrik.
 * labelRes her zaman doludur (etiket her zaman lokalize edilir).
 * value, sayısal/serbest metin değerler için kullanılır (örn. "52",
 * "29.4°C"). valueRes ise SADECE termal durum gibi kendisi de lokalize
 * edilmesi gereken bir durum ADI olduğunda doldurulur (örn. "Kritik") —
 * doluysa value yerine valueRes gösterilir.
 * reflectsSystemStatus = true ise (sıcaklık, termal durum gibi),
 * kartın değeri durum rengini alır; false ise (entity sayısı gibi
 * nötr sayılar) her zaman nötr renkte kalır.
 */
data class LiveMetric(
    val labelRes: Int,
    val value: String = "",
    val valueRes: Int? = null,
    val reflectsSystemStatus: Boolean = false,
)

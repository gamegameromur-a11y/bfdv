package com.testthephone.app.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.ui.theme.AppColors

/**
 * Ayarlar sekmesi. Dil seçimi burada bir liste olarak gösteriliyor
 * (8 dil, kararlaştırdığımız kombinasyon) — dil ADLARI (Türkçe,
 * English, vb.) bilinçli olarak lokalize EDİLMEZ, her zaman kendi
 * dilinde gösterilir (bu, çoğu uygulamanın dil seçicisinde standart
 * bir konvansiyon — kullanıcı kendi dilini tanıyabilmeli, sistem
 * dilinde bir çeviri değil).
 *
 * Root modu anahtarı ÖZELLİKLE dikkatli tasarlandı: varsayılan kapalı,
 * açıklayıcı bir alt metinle birlikte — kullanıcı bunu bilerek,
 * anlayarak açmalı.
 */
@Composable
fun SettingsScreen(
    currentLanguageCode: String,
    darkThemeEnabled: Boolean,
    rootModeEnabled: Boolean,
    onLanguageSelected: (String) -> Unit,
    onDarkThemeToggled: (Boolean) -> Unit,
    onRootModeToggled: (Boolean) -> Unit,
    onOpenEula: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
    ) {
        item {
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineSmall,
                color = AppColors.TextPrimary,
                modifier = Modifier.padding(bottom = 20.dp),
            )
        }

        item { SectionLabel(stringResource(R.string.settings_section_appearance)) }
        item {
            ToggleRow(
                label = stringResource(R.string.settings_dark_theme),
                checked = darkThemeEnabled,
                onCheckedChange = onDarkThemeToggled,
            )
        }

        item { SectionLabel(stringResource(R.string.settings_section_language), topPadding = 20.dp) }
        items(SUPPORTED_LANGUAGES) { lang ->
            LanguageRow(
                language = lang,
                selected = lang.code == currentLanguageCode,
                onClick = { onLanguageSelected(lang.code) },
            )
        }

        item { SectionLabel(stringResource(R.string.settings_section_advanced), topPadding = 20.dp) }
        item {
            ToggleRow(
                label = stringResource(R.string.settings_root_mode),
                description = stringResource(R.string.settings_root_mode_description),
                checked = rootModeEnabled,
                onCheckedChange = onRootModeToggled,
            )
        }

        item { SectionLabel(stringResource(R.string.settings_section_legal), topPadding = 20.dp) }
        item { LinkRow(label = stringResource(R.string.settings_terms_of_use), onClick = onOpenEula) }
        item { LinkRow(label = stringResource(R.string.settings_privacy_policy), onClick = onOpenPrivacyPolicy) }
    }
}

@Composable
private fun SectionLabel(text: String, topPadding: Dp = 0.dp) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = AppColors.TextMuted,
        modifier = Modifier.padding(top = topPadding, bottom = 8.dp),
    )
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    description: String? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = AppColors.Surface1, shape = RoundedCornerShape(10.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextPrimary,
            )
            if (description != null) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = AppColors.TextMuted,
                    modifier = Modifier.padding(top = 4.dp, end = 8.dp),
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AppColors.OnPrimary,
                checkedTrackColor = AppColors.FillPrimary,
            ),
        )
    }
}

@Composable
private fun LanguageRow(language: SupportedLanguage, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .background(color = if (selected) AppColors.Surface1 else AppColors.Surface2)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = language.displayName,
            style = MaterialTheme.typography.bodyMedium,
            color = AppColors.TextPrimary,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
        )
        if (selected) {
            Text(text = "✓", color = AppColors.TextPrimary)
        }
    }
}

@Composable
private fun LinkRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = AppColors.TextPrimary)
        Text(text = "›", color = AppColors.TextMuted)
    }
}

data class SupportedLanguage(val code: String, val displayName: String)

/**
 * Kararlaştırdığımız 8 dil: Türkçe, İngilizce, İspanyolca, Almanca,
 * Fransızca, Portekizce, Rusça, Arapça. Kod ISO 639-1 standardı.
 * displayName'ler bilinçli olarak SABİT (lokalize değil) — dil
 * seçicide her dil kendi adıyla, kendi alfabesiyle görünmeli.
 */
val SUPPORTED_LANGUAGES = listOf(
    SupportedLanguage("tr", "Türkçe"),
    SupportedLanguage("en", "English"),
    SupportedLanguage("es", "Español"),
    SupportedLanguage("de", "Deutsch"),
    SupportedLanguage("fr", "Français"),
    SupportedLanguage("pt", "Português"),
    SupportedLanguage("ru", "Русский"),
    SupportedLanguage("ar", "العربية"),
)

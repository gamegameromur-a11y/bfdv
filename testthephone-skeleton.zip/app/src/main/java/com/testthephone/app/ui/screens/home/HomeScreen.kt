package com.testthephone.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.report.DeviceProfile
import com.testthephone.app.ui.components.MetricText
import com.testthephone.app.ui.theme.AppColors
import java.util.Locale

/**
 * Ana Sayfa: önceki mockup'ta kararlaştırdığımız yapı — cihaz özeti,
 * "Tam testi başlat" birincil CTA'sı, altında tek tek başlatılabilecek
 * testlerin listesi. Geçmiş test sonuçları BİLEREK burada değil (ayrı
 * sekmede) — ana ekran sade kalsın diye.
 */
@Composable
fun HomeScreen(
    deviceProfile: DeviceProfile?,
    batteryLevelPct: Int?,
    batteryTempC: Float?,
    testCatalog: List<TestCatalogEntry>,
    onStartFullTest: () -> Unit,
    onSelectSingleTest: (testId: String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
    ) {
        item {
            DeviceSummarySection(
                deviceProfile = deviceProfile,
                batteryLevelPct = batteryLevelPct,
                batteryTempC = batteryTempC,
            )
        }

        item {
            StartFullTestSection(
                estimatedMinutes = testCatalog.sumOf { it.estimatedMinutes },
                testCount = testCatalog.size,
                onStartFullTest = onStartFullTest,
            )
        }

        item {
            Text(
                text = stringResource(R.string.home_single_test_section),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextSecondary,
                modifier = Modifier.padding(top = 8.dp, bottom = 12.dp),
            )
        }

        items(testCatalog) { entry ->
            TestCatalogRow(
                entry = entry,
                onClick = { onSelectSingleTest(entry.testId) },
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun DeviceSummarySection(
    deviceProfile: DeviceProfile?,
    batteryLevelPct: Int?,
    batteryTempC: Float?,
) {
    Column(modifier = Modifier.padding(bottom = 24.dp)) {
        Text(
            text = if (deviceProfile != null) {
                "${deviceProfile.manufacturer} ${deviceProfile.model} · Android ${deviceProfile.androidVersion}"
            } else {
                stringResource(R.string.home_device_loading)
            },
            style = MaterialTheme.typography.bodyMedium,
            color = AppColors.TextSecondary,
        )
        Text(
            text = stringResource(R.string.home_last_test_none),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextMuted,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp),
        )

        Column {
            MetricCardRow(
                label = stringResource(R.string.home_metric_battery),
                value = batteryLevelPct?.let { "$it%" } ?: "—",
            )
            MetricCardRow(
                label = stringResource(R.string.home_metric_temperature),
                // ÖNEMLİ TUTARLILIK BUG DÜZELTMESİ: bkz.
                // LiveMetricMapper.kt'deki aynı sınıf gerekçe —
                // "%.1f".format(it) örtük olarak cihazın sistem
                // locale'ini kullanır (bazı dillerde ondalık ayırıcı
                // virgüldür). Locale.US ile sabitleyip tüm sayısal
                // göstergelerde tutarlı nokta ayırıcı garanti ediyoruz.
                value = batteryTempC?.let { "${String.format(Locale.US, "%.1f", it)}°C" } ?: "—",
                modifier = Modifier.padding(top = 10.dp),
            )
        }
    }
}

@Composable
private fun MetricCardRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(color = AppColors.Surface1, shape = RoundedCornerShape(10.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = AppColors.TextMuted)
        MetricText(text = value, color = AppColors.TextPrimary)
    }
}

@Composable
private fun StartFullTestSection(
    estimatedMinutes: Int,
    testCount: Int,
    onStartFullTest: () -> Unit,
) {
    Column(modifier = Modifier.padding(bottom = 24.dp)) {
        Button(
            onClick = onStartFullTest,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = AppColors.FillPrimary,
                contentColor = AppColors.OnPrimary,
            ),
        ) {
            Text(text = stringResource(R.string.home_start_full_test), fontWeight = FontWeight.Medium)
        }
        Text(
            text = stringResource(R.string.home_estimated_duration, estimatedMinutes, testCount),
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.TextMuted,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun TestCatalogRow(
    entry: TestCatalogEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .background(color = AppColors.Surface2)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = stringResource(entry.displayNameRes),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextPrimary,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = stringResource(R.string.home_minutes_short, entry.estimatedMinutes),
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextMuted,
            )
        }
        Text(text = "›", color = AppColors.TextMuted)
    }
}

/**
 * Ana ekranda listelenen bir testin özet bilgisi. displayNameRes,
 * daha önce sabit String yerine artık bir @StringRes int id —
 * her test adı strings.xml'deki test_*_name anahtarlarına karşılık
 * geliyor (bkz. MainActivity'deki testCatalog tanımı).
 */
data class TestCatalogEntry(
    val testId: String,
    val displayNameRes: Int,
    val estimatedMinutes: Int,
)

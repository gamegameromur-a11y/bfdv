package com.testthephone.app.tests.image

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.sin
import kotlin.random.Random

/**
 * Test 4 (progressive image processing) için galeriden dosya seçmek
 * yerine sentetik, deterministik bir test görüntüsü üretir. Bilinçli
 * tercih: galeri/depolama izni istemek hem gereksiz bir izin yüzeyi
 * açar (Data Safety formunda ekstra açıklama gerektirir) hem de
 * kullanıcının seçtiği görüntüye göre test sonucu değişken hale gelir
 * — aynı cihazda iki farklı çalıştırma farklı görüntü karmaşıklığından
 * ötürü farklı sonuç verebilir. Sentetik, sabit tohum (seed) ile
 * üretilen görüntü, testin tekrarlanabilirliğini garanti eder.
 *
 * Görüntü, gerçekçi işlem yükü üretmesi için bilinçli olarak yüksek
 * frekanslı desenler (gürültü + sinüs dalgaları) içerir — düz renkli
 * bir görüntü blur/edge-detection gibi filtrelerde gerçekçi olmayan
 * şekilde ucuza işlenir.
 */
object SyntheticImageGenerator {

    private const val SEED = 42L

    fun generate(width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val random = Random(SEED)
        val pixels = IntArray(width * height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                // Sinüs tabanlı desen + hafif gürültü: hem yumuşak geçişli
                // bölgeler (blur testinde anlamlı) hem de keskin kenarlar
                // (edge detection testinde anlamlı) içerir.
                val patternValue = (
                    sin(x * 0.05) * sin(y * 0.05) * 127 + 128
                ).toInt().coerceIn(0, 255)
                val noise = random.nextInt(-20, 20)
                val value = (patternValue + noise).coerceIn(0, 255)

                pixels[y * width + x] = Color.rgb(value, (value * 0.8).toInt(), (255 - value))
            }
        }

        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return bitmap
    }
}

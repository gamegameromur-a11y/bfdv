package com.testthephone.app.tests.entityspawn

import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Test 1 (statik kapasite) ve Test 2'nin (etkileşimli simülasyon) ortak
 * kullandığı en klasik hesaplama mantığı: konum, hız, ve komşu entity'lerle
 * temel çarpışma (collision) kontrolü. Bilinçli olarak basit tutuldu —
 * "en klasik hesaplama mantığını kullanacak" talebine uygun, egzotik bir
 * algoritma değil, oyun motorlarının temel iş yükünü temsil eden bir
 * transform + collision check döngüsü.
 */
data class Entity(
    var x: Float,
    var y: Float,
    var velocityX: Float,
    var velocityY: Float,
    val radius: Float = 4f,
) {
    companion object {
        fun spawnRandom(boundsWidth: Float, boundsHeight: Float, interactive: Boolean): Entity {
            val speed = if (interactive) Random.nextFloat() * 120f + 20f else 0f
            val angle = Random.nextFloat() * (2 * Math.PI).toFloat()
            return Entity(
                x = Random.nextFloat() * boundsWidth,
                y = Random.nextFloat() * boundsHeight,
                velocityX = speed * kotlin.math.cos(angle),
                velocityY = speed * kotlin.math.sin(angle),
            )
        }
    }
}

/**
 * Test 1'de (statik kapasite) sadece varlık + minimal transform hesabı,
 * Test 2'de (etkileşimli simülasyon) hareket + komşu çarpışma kontrolü
 * çalıştırılır. Aynı sınıf iki modu da destekler, çünkü ikisi arasındaki
 * fark "ne kadar hesaplama yapıldığı", entity modeli değil.
 */
class EntitySimulationStep(
    private val boundsWidth: Float,
    private val boundsHeight: Float,
) {
    /**
     * Statik mod: pozisyonu sabit tutar, sadece varlığını ve bellek
     * ayak izini ölçmek için entity listesi üzerinde minimal bir
     * dokunuş (index erişimi + basit aritmetik) yapar — tamamen boş
     * bir liste tutmak gerçekçi olmaz, gerçek bir uygulamanın her
     * frame'de entity listesine dokunması gerekir.
     */
    fun stepStatic(entities: MutableList<Entity>) {
        for (i in entities.indices) {
            val e = entities[i]
            // Minimal iş: sınır kontrolü, gerçek bir render/culling adımını temsil eder.
            if (e.x < 0f || e.x > boundsWidth) entities[i] = e.copy(x = e.x.coerceIn(0f, boundsWidth))
        }
    }

    /**
     * Etkileşimli mod: her entity'nin konumunu hızına göre günceller,
     * ve basit bir O(n*k) komşu çarpışma kontrolü yapar (k = kontrol
     * edilen komşu sayısı, tüm listeyi taramak yerine sınırlı bir
     * pencere) — bu, oyun motorlarındaki uzaysal bölümleme
     * (spatial partitioning) olmadan yapılan en klasik yaklaşımın
     * basitleştirilmiş halidir.
     */
    fun stepInteractive(entities: MutableList<Entity>, deltaSeconds: Float, neighborCheckWindow: Int) {
        for (i in entities.indices) {
            val e = entities[i]
            var newX = e.x + e.velocityX * deltaSeconds
            var newY = e.y + e.velocityY * deltaSeconds
            var newVx = e.velocityX
            var newVy = e.velocityY

            if (newX < 0f || newX > boundsWidth) {
                newVx = -newVx
                newX = newX.coerceIn(0f, boundsWidth)
            }
            if (newY < 0f || newY > boundsHeight) {
                newVy = -newVy
                newY = newY.coerceIn(0f, boundsHeight)
            }

            // Komşu çarpışma kontrolü: tüm listeyi değil, sabit boyutlu
            // bir pencereyi tarar — bu da kalibrasyona göre ölçeklenen,
            // öngörülebilir bir hesaplama maliyeti sağlar.
            val windowEnd = minOf(i + neighborCheckWindow, entities.size)
            for (j in (i + 1) until windowEnd) {
                val other = entities[j]
                val dx = newX - other.x
                val dy = newY - other.y
                val distance = sqrt(dx * dx + dy * dy)
                if (distance < e.radius + other.radius) {
                    // Basit esnek çarpışma tepkisi: hız bileşenlerini ters çevir.
                    newVx = -newVx
                    newVy = -newVy
                }
            }

            entities[i] = e.copy(x = newX, y = newY, velocityX = newVx, velocityY = newVy)
        }
    }
}

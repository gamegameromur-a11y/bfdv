package com.testthephone.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.testthephone.app.core.safety.ThermalStatus

/**
 * ThermalStatus'u (Android'in resmi termal API'sinden gelen kesin veri)
 * UI'nin durum rengine çeviren TEK yer. Bu merkezi tutulur ki ekranlar
 * arasında "hangi renk hangi duruma karşılık geliyor" tutarsızlığı
 * olmasın — kritik durum ekranı, test ilerleme kartı, ana sayfa
 * özeti hepsi buradan aynı eşlemeyi kullanır.
 *
 * gradientFor/solidFor artık @Composable işaretli — AppColors,
 * LocalAppColors CompositionLocal'i üzerinden çözüldüğü için (koyu/açık
 * tema geçişini desteklemek amacıyla) composable context gerektiriyor.
 * tierFor ve labelKeyFor composable DEĞİL çünkü AppColors'a hiç
 * dokunmuyorlar, sadece enum eşlemesi yapıyorlar.
 */
enum class StatusTier { CALM, WARNING, CRITICAL, UNKNOWN }

object StatusColor {

    fun tierFor(status: ThermalStatus): StatusTier = when (status) {
        ThermalStatus.NONE, ThermalStatus.LIGHT -> StatusTier.CALM
        ThermalStatus.MODERATE, ThermalStatus.SEVERE -> StatusTier.WARNING
        ThermalStatus.CRITICAL, ThermalStatus.EMERGENCY, ThermalStatus.SHUTDOWN -> StatusTier.CRITICAL
        // ÖNEMLİ GÖSTERGE HATASI DÜZELTMESİ: UNKNOWN önceden CALM ile
        // aynı kovaya (StatusTier.CALM) eşleniyordu — yani termal API
        // desteklenmiyor/başarısız olduğunda (API 29 altı cihazlar,
        // ya da bir okuma hatası sonrası runCatching fallback'i) UI
        // sistem genelinde (kritik durum ekranı, test ilerleme kartı,
        // ana sayfa özeti — bu eşleme hepsinde ortak kullanılıyor)
        // yeşil/"her şey yolunda" rengi gösteriyordu. Cihaz gerçekten
        // aşırı ısınıyor olsa bile, ölçüm başarısız olduğu için ekran
        // güven verici bir renk gösteriyordu — bu yanıltıcı ve
        // potansiyel olarak güvenlik açısından riskli bir davranıştı.
        // Artık ayrı bir UNKNOWN kovası var, nötr gri renkle (bkz.
        // AppColors.StatusUnknownStart/End) gösteriliyor.
        ThermalStatus.UNKNOWN -> StatusTier.UNKNOWN
    }

    @Composable
    fun gradientFor(tier: StatusTier): Pair<Color, Color> = when (tier) {
        StatusTier.CALM -> AppColors.StatusCalmStart to AppColors.StatusCalmEnd
        StatusTier.WARNING -> AppColors.StatusWarningStart to AppColors.StatusWarningEnd
        StatusTier.CRITICAL -> AppColors.StatusCriticalStart to AppColors.StatusCriticalEnd
        StatusTier.UNKNOWN -> AppColors.StatusUnknownStart to AppColors.StatusUnknownEnd
    }

    @Composable
    fun solidFor(tier: StatusTier): Color = when (tier) {
        StatusTier.CALM -> AppColors.StatusCalmEnd
        StatusTier.WARNING -> AppColors.StatusWarningEnd
        StatusTier.CRITICAL -> AppColors.StatusCriticalEnd
        StatusTier.UNKNOWN -> AppColors.StatusUnknownEnd
    }

    fun labelKeyFor(tier: StatusTier): String = when (tier) {
        StatusTier.CALM -> "status_calm"
        StatusTier.WARNING -> "status_warning"
        StatusTier.CRITICAL -> "status_critical"
        StatusTier.UNKNOWN -> "status_unknown"
    }
}

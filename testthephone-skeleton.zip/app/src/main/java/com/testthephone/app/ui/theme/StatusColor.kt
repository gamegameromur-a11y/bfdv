package com.testthephone.app.ui.theme

import androidx.compose.ui.graphics.Color
import com.testthephone.app.core.safety.ThermalStatus

/**
 * ThermalStatus'u (Android'in resmi termal API'sinden gelen kesin veri)
 * UI'nin durum rengine çeviren TEK yer. Bu merkezi tutulur ki ekranlar
 * arasında "hangi renk hangi duruma karşılık geliyor" tutarsızlığı
 * olmasın — kritik durum ekranı, test ilerleme kartı, ana sayfa
 * özeti hepsi buradan aynı eşlemeyi kullanır.
 */
enum class StatusTier { CALM, WARNING, CRITICAL }

object StatusColor {

    fun tierFor(status: ThermalStatus): StatusTier = when (status) {
        ThermalStatus.NONE, ThermalStatus.LIGHT, ThermalStatus.UNKNOWN -> StatusTier.CALM
        ThermalStatus.MODERATE, ThermalStatus.SEVERE -> StatusTier.WARNING
        ThermalStatus.CRITICAL, ThermalStatus.EMERGENCY, ThermalStatus.SHUTDOWN -> StatusTier.CRITICAL
    }

    fun gradientFor(tier: StatusTier): Pair<Color, Color> = when (tier) {
        StatusTier.CALM -> AppColors.StatusCalmStart to AppColors.StatusCalmEnd
        StatusTier.WARNING -> AppColors.StatusWarningStart to AppColors.StatusWarningEnd
        StatusTier.CRITICAL -> AppColors.StatusCriticalStart to AppColors.StatusCriticalEnd
    }

    fun solidFor(tier: StatusTier): Color = when (tier) {
        StatusTier.CALM -> AppColors.StatusCalmEnd
        StatusTier.WARNING -> AppColors.StatusWarningEnd
        StatusTier.CRITICAL -> AppColors.StatusCriticalEnd
    }

    fun labelKeyFor(tier: StatusTier): String = when (tier) {
        StatusTier.CALM -> "status_calm"
        StatusTier.WARNING -> "status_warning"
        StatusTier.CRITICAL -> "status_critical"
    }
}

package com.testthephone.app.core.safety

import android.content.Context
import android.os.PowerManager

/**
 * Konuşmamızda kararlaştırdığımız "test sırasında lütfen telefonu
 * kapatmayın" uyarısının teknik karşılığı: FLAG_KEEP_SCREEN_ON yerine
 * doğrudan PowerManager.WakeLock kullanıyoruz çünkü Compose Activity
 * her zaman ön planda olmayabilir (örn. GPU/tepki süresi testleri
 * ayrı composable'larda) — WakeLock, ekranın SCREEN_DIM_WAKE_LOCK
 * seviyesinde açık kalmasını, hangi composable gösteriliyor olursa
 * olsun garanti eder.
 *
 * SCREEN_DIM_WAKE_LOCK (tam parlaklık değil, PARTIAL_WAKE_LOCK da
 * değil) bilinçli bir orta yol: ekranı tamamen karartıp CPU'yu
 * çalışır tutmak (PARTIAL) kullanıcı ekranı görmesin isterdik ama biz
 * TAM TERSİNİ istiyoruz — kullanıcı canlı metrikleri görebilsin. Tam
 * parlaklık (SCREEN_BRIGHT_WAKE_LOCK) ise gereksiz yere daha fazla
 * pil tüketir ve zaten test sonucunu etkileyebilir (ekran parlaklığı
 * da bir güç tüketici). DIM, ekranı açık tutar ama olabildiğince az
 * ek güç harcar.
 *
 * WAKE_LOCK izni "normal" seviyeli (tehlikeli değil), kullanıcı
 * onayı gerektirmez — sadece manifestte bildirilmesi yeterli, ki
 * zaten var.
 */
class TestWakeLockManager(context: Context) {

    private val powerManager = context.applicationContext
        .getSystemService(Context.POWER_SERVICE) as PowerManager

    private var wakeLock: PowerManager.WakeLock? = null

    /**
     * Bir test başladığında çağrılır. Zaten tutuluyorsa (örn. testler
     * art arda başlatılıyorsa) tekrar acquire etmez — WakeLock'lar
     * iç sayaç tutmuyor, çift acquire/release dengesizliği release'i
     * erken tetikleyebilir.
     */
    fun acquire() {
        if (wakeLock?.isHeld == true) return

        val newWakeLock = powerManager.newWakeLock(
            PowerManager.SCREEN_DIM_WAKE_LOCK,
            "TestThePhone:TestExecutionWakeLock",
        )
        // 30 dakikalık bir üst zaman aşımı: sürdürülebilir performans
        // testi (Test 5) en uzun test, varsayılan 10 dakika sürüyor.
        // Beklenmedik bir kilitlenme/crash durumunda WakeLock'un
        // sonsuza kadar tutulup pili boşaltmasını önlemek için bir
        // güvenlik sınırı — normal akışta release() zaten testler
        // bitince çağrılıyor, bu sadece son çare.
        newWakeLock.acquire(30 * 60 * 1000L)
        wakeLock = newWakeLock
    }

    /** Test tamamlandığında, duraklatıldığında veya iptal edildiğinde çağrılır. */
    fun release() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }
}

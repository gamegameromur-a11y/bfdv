package com.testthephone.app.tests.image

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.sqrt

/**
 * "En klasik hesaplama mantığını kullanacak" talebine uygun, iyi bilinen
 * iki klasik görüntü işleme algoritması: kutu bulanıklaştırma (box blur,
 * Gaussian'ın basitleştirilmiş hali) ve Sobel edge detection. Kütüphaneye
 * (RenderScript, OpenCV vb.) bağımlı DEĞİL — doğrudan piksel matrisi
 * üzerinde, saf CPU hesaplamasıyla çalışır. Bu bilinçli bir tercih:
 * RenderScript kullanmak GPU'ya kayabilir ve testin "CPU/bellek karışık
 * yük" ölçme amacını bulanıklaştırır.
 *
 * Her iki filtre de O(width * height * kernelSize) karmaşıklığında —
 * çözünürlük arttıkça maliyet öngörülebilir ve ölçülebilir şekilde artar,
 * bu da "kademeli artan çözünürlük" testinin temelini oluşturur.
 */
object ClassicImageFilters {

    /**
     * 3x3 kutu bulanıklaştırma — her piksel, komşularının ortalamasıyla
     * değiştirilir.
     */
    fun boxBlur3x3(source: IntArray, width: Int, height: Int): IntArray {
        val output = IntArray(source.size)

        for (y in 0 until height) {
            for (x in 0 until width) {
                var sumR = 0
                var sumG = 0
                var sumB = 0
                var count = 0

                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val nx = x + dx
                        val ny = y + dy
                        if (nx in 0 until width && ny in 0 until height) {
                            val pixel = source[ny * width + nx]
                            sumR += Color.red(pixel)
                            sumG += Color.green(pixel)
                            sumB += Color.blue(pixel)
                            count++
                        }
                    }
                }

                output[y * width + x] = Color.rgb(sumR / count, sumG / count, sumB / count)
            }
        }

        return output
    }

    /**
     * Sobel operatörü ile kenar tespiti — görüntü işlemede en klasik,
     * ders kitabı düzeyinde bilinen algoritmalardan biri. Yatay ve
     * dikey gradyan çekirdeklerini uygulayıp büyüklüğünü hesaplar.
     */
    fun sobelEdgeDetection(source: IntArray, width: Int, height: Int): IntArray {
        val output = IntArray(source.size)

        val gxKernel = arrayOf(
            intArrayOf(-1, 0, 1),
            intArrayOf(-2, 0, 2),
            intArrayOf(-1, 0, 1),
        )
        val gyKernel = arrayOf(
            intArrayOf(-1, -2, -1),
            intArrayOf(0, 0, 0),
            intArrayOf(1, 2, 1),
        )

        fun grayscaleAt(x: Int, y: Int): Int {
            val cx = x.coerceIn(0, width - 1)
            val cy = y.coerceIn(0, height - 1)
            val pixel = source[cy * width + cx]
            // Standart luminance ağırlıklandırması — klasik gri tonlama formülü.
            return (Color.red(pixel) * 0.299 + Color.green(pixel) * 0.587 + Color.blue(pixel) * 0.114).toInt()
        }

        for (y in 0 until height) {
            for (x in 0 until width) {
                var gx = 0
                var gy = 0
                for (ky in -1..1) {
                    for (kx in -1..1) {
                        val gray = grayscaleAt(x + kx, y + ky)
                        gx += gray * gxKernel[ky + 1][kx + 1]
                        gy += gray * gyKernel[ky + 1][kx + 1]
                    }
                }
                val magnitude = sqrt((gx * gx + gy * gy).toDouble()).toInt().coerceIn(0, 255)
                output[y * width + x] = Color.rgb(magnitude, magnitude, magnitude)
            }
        }

        return output
    }

    fun bitmapToPixelArray(bitmap: Bitmap): IntArray {
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        return pixels
    }
}

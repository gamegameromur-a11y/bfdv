package com.testthephone.app.core.monitoring

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

/**
 * Pil sıcaklığı, yüzdesi, akımı gibi metrikler için tek kaynak.
 * Tamamı BatteryManager / ACTION_BATTERY_CHANGED üzerinden, izin
 * gerektirmeden, tüm Android sürümlerinde güvenilir şekilde okunur.
 */
class BatteryMonitor(private val context: Context) {

    private val batteryManager = context.applicationContext
        .getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    fun snapshot(): BatterySnapshot {
        val intent = context.applicationContext.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
        )

        // EXTRA_TEMPERATURE onda birlik derece cinsinden gelir (örn. 294 -> 29.4°C).
        val rawTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val tempC = rawTemp?.takeIf { it != Int.MIN_VALUE }?.let { it / 10.0f }

        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level != null && scale != null && level >= 0 && scale > 0) {
            (level * 100) / scale
        } else null

        // getIntProperty negatif dönebilir (deşarj) ya da desteklenmiyorsa
        // Int.MIN_VALUE dönebilir; bu durumları ayırt ediyoruz.
        val currentMicroAmps = batteryManager
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            .takeIf { it != Int.MIN_VALUE }

        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)?.takeIf { it > 0 }

        return BatterySnapshot(
            temperatureC = certain(tempC, "BatteryManager.EXTRA_TEMPERATURE"),
            levelPct = certain(pct, "BatteryManager.EXTRA_LEVEL"),
            currentMicroAmps = bestEffort(currentMicroAmps, "BatteryManager.BATTERY_PROPERTY_CURRENT_NOW"),
            voltageMv = certain(voltageMv, "BatteryManager.EXTRA_VOLTAGE"),
        )
    }
}

data class BatterySnapshot(
    val temperatureC: MeasuredValue<Float>,
    val levelPct: MeasuredValue<Int>,
    /** Bazı OEM'lerde bu özellik desteklenmiyor, bu yüzden BEST_EFFORT. */
    val currentMicroAmps: MeasuredValue<Int>,
    val voltageMv: MeasuredValue<Int>,
)

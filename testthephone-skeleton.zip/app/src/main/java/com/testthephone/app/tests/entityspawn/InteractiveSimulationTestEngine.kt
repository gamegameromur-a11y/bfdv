package com.testthephone.app.tests.entityspawn

import com.testthephone.app.core.monitoring.MetricsCollector
import com.testthephone.app.core.safety.SafetyDecision
import com.testthephone.app.tests.TestEngine
import com.testthephone.app.tests.TestExecutionContext
import com.testthephone.app.tests.TestProgressEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Test 2: Test 1'de bulunan entity'lerin en fazla kaçı aynı anda hareketli
 * ve etkileşimli (fizik + çarpışma) simüle edilebilir.
 *
 * staticCapacityHint, Test 1'in sonucudur — bu testin üst sınırını,
 * sıfırdan taramak yerine akıllıca daraltır (etkileşimli simülasyon her
 * zaman statik olandan daha maliyetli olduğu için, statik kapasiteyi
 * aşan bir hedefle başlamanın anlamı yok).
 *
 * neighborCheckWindow, cihazın çekirdek sayısına göre kalibre edilir:
 * daha güçlü cihazlarda daha geniş bir komşu penceresi taranarak testin
 * "gerçekçi etkileşim yoğunluğu" ölçmesi sağlanır.
 */
class InteractiveSimulationTestEngine(
    private val metricsCollector: MetricsCollector,
    private val staticCapacityHint: Int,
    private val boundsWidth: Float = 1080f,
    private val boundsHeight: Float = 2400f,
) : TestEngine {

    override val testId = "interactive_simulation_capacity"
    override val displayNameKey = "test_interactive_simulation_name"

    private val consecutiveFailureThreshold = 3
    private val frameTimeThresholdMs = 33.3f
    private val framesPerStep = 20
    private val deltaSeconds = 1f / 60f

    override fun run(context: TestExecutionContext): Flow<TestProgressEvent> = flow {
        val calibration = context.calibration
        val simulationStep = EntitySimulationStep(boundsWidth, boundsHeight)
        val entities = mutableListOf<Entity>()

        // Etkileşimli test her zaman statik kapasiteden düşük veya eşit
        // bir noktadan başlar; statik kapasite bilinmiyorsa (Test 1
        // atlanmışsa) kalibrasyonun başlangıç değerine düş.
        val startingTarget = if (staticCapacityHint > 0) {
            (staticCapacityHint / 4).coerceAtLeast(calibration.initialEntityCount)
        } else {
            calibration.initialEntityCount
        }
        val stepSize = calibration.entityCountStep / 2 // Daha ince adımlarla tara, çünkü maliyet daha keskin artıyor.
        val neighborCheckWindow = (calibration.cpuCoreCount * 2).coerceIn(4, 32)

        var currentTarget = startingTarget
        var consecutiveFailures = 0
        var lastStableCount = 0
        val startTime = System.currentTimeMillis()

        val hardCap = if (staticCapacityHint > 0) staticCapacityHint else calibration.maxEntityCountCap

        while (currentTarget <= hardCap) {
            val decision = context.safetyDecision.value
            if (decision == SafetyDecision.PAUSE_REQUIRED) {
                emit(TestProgressEvent.Paused(reason = "thermal_critical"))
                return@flow
            }

            while (entities.size < currentTarget) {
                entities.add(Entity.spawnRandom(boundsWidth, boundsHeight, interactive = true))
            }

            val frameTimes = FloatArray(framesPerStep)
            for (f in 0 until framesPerStep) {
                val frameStart = System.nanoTime()
                simulationStep.stepInteractive(entities, deltaSeconds, neighborCheckWindow)
                val frameEnd = System.nanoTime()
                frameTimes[f] = (frameEnd - frameStart) / 1_000_000f
            }
            val avgFrameTimeMs = frameTimes.average().toFloat()
            val jitterMs = (frameTimes.maxOrNull()!! - frameTimes.minOrNull()!!)

            val elapsedMs = System.currentTimeMillis() - startTime
            val snapshot = metricsCollector.snapshot(
                elapsedMs = elapsedMs,
                testSpecific = mapOf(
                    "entity_count" to currentTarget.toDouble(),
                    "frame_time_ms" to avgFrameTimeMs.toDouble(),
                    "frame_time_jitter_ms" to jitterMs.toDouble(),
                    "fps" to (1000.0 / avgFrameTimeMs.coerceAtLeast(0.001f)),
                    "neighbor_check_window" to neighborCheckWindow.toDouble(),
                ),
            )
            emit(TestProgressEvent.Sample(snapshot))

            if (avgFrameTimeMs > frameTimeThresholdMs) {
                consecutiveFailures++
                if (consecutiveFailures >= consecutiveFailureThreshold) {
                    emit(
                        TestProgressEvent.Completed(
                            summary = mapOf(
                                "max_stable_interactive_entities" to lastStableCount.toDouble(),
                                "static_capacity_reference" to staticCapacityHint.toDouble(),
                                "interactive_to_static_ratio" to if (staticCapacityHint > 0) {
                                    lastStableCount.toDouble() / staticCapacityHint.toDouble()
                                } else 0.0,
                                "total_duration_ms" to elapsedMs.toDouble(),
                            )
                        )
                    )
                    return@flow
                }
            } else {
                consecutiveFailures = 0
                lastStableCount = currentTarget
            }

            currentTarget += stepSize
        }

        emit(
            TestProgressEvent.Completed(
                summary = mapOf(
                    "max_stable_interactive_entities" to lastStableCount.toDouble(),
                    "static_capacity_reference" to staticCapacityHint.toDouble(),
                    "reached_static_capacity_cap" to 1.0,
                )
            )
        )
    }
}

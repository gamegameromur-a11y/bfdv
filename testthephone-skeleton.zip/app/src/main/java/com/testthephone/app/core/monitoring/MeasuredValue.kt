package com.testthephone.app.core.monitoring

import kotlinx.serialization.Serializable

/**
 * Android'de hiçbir performans metriği tek bir güven seviyesinde değil:
 * bazıları resmi SDK API'lerinden (kesin), bazıları dosya okuma gibi
 * best-effort yöntemlerden (cihaza göre değişken), bazıları da hiç
 * mevcut olmayabilir. Bu sınıf, her ölçümün değerini KAYNAĞI ve
 * GÜVEN SEVİYESİYLE birlikte taşır, böylece raporu okuyan taraf
 * (AI ya da teknik servis) hangi veriye ne kadar güveneceğini bilir.
 *
 * Değer null olabilir (metrik bu cihazda hiç okunamadıysa),
 * ama confidence ve source alanları her zaman doldurulur.
 *
 * Generic T için otomatik serializer üretilemediğinden (kotlinx.serialization
 * generic tip parametresi için çağrı yerinde somut serializer ister), JSON
 * export katmanı MeasuredValueJsonAdapter üzerinden manuel dönüşüm yapar.
 * Bu sınıf uygulama içi (runtime) kullanımda düz bir veri taşıyıcısıdır.
 */
data class MeasuredValue<T>(
    val value: T?,
    val confidence: Confidence,
    val source: String,
)

@Serializable
enum class Confidence {
    /** Resmi, dokümante edilmiş Android SDK API'si, izinsiz erişilebilir. */
    CERTAIN,

    /** İzin gerektirmez ama cihaza/OEM'e göre erişilebilirliği ve doğruluğu değişir
     *  (örn. /proc/stat, cpufreq sysfs dosyaları). */
    BEST_EFFORT,

    /** Doğrudan ölçüm değil, dolaylı/tahmini bir değer
     *  (örn. thermal_zone dosyası "cpu" adını taşıyor ama gerçek CPU
     *  sıcaklığı olduğu garanti değil). */
    INDIRECT_ESTIMATE,

    /** Root erişimiyle elde edilmiş, normal moddan ayrı tutulan veri. */
    ROOT_ONLY,

    /** Bu cihazda/ortamda hiç okunamadı. */
    UNAVAILABLE,
}

/** Kolaylık kurucuları — çağrı yerlerinde tekrarı azaltmak için. */
fun <T> certain(value: T, source: String) =
    MeasuredValue(value, Confidence.CERTAIN, source)

fun <T> bestEffort(value: T?, source: String) =
    MeasuredValue(value, if (value == null) Confidence.UNAVAILABLE else Confidence.BEST_EFFORT, source)

fun <T> indirectEstimate(value: T?, source: String) =
    MeasuredValue(value, if (value == null) Confidence.UNAVAILABLE else Confidence.INDIRECT_ESTIMATE, source)

fun <T> unavailable(source: String): MeasuredValue<T> =
    MeasuredValue(null, Confidence.UNAVAILABLE, source)

package com.testthephone.app.tests.gpu

/**
 * Test 3 (GPU render testi) için AGSL fragment shader kaynağı. Bilinçli
 * olarak Mandelbrot benzeri, iterasyon sayısı parametrik bir hesaplama
 * seçildi — "PC'lerdeki GPU testi mantığının minimalize hali" dediğin
 * şeyin karşılığı: her piksel için tekrarlayan, ölçeklenebilir matematiksel
 * iş yükü, gerçek 3D sahne render etmeden GPU'yu saf hesaplama gücüyle
 * zorlar.
 *
 * `iterations` uniform'u kademeli olarak artırılarak (test motorunda)
 * "çok küçükten başlayıp gittikçe büyüyen" yük eğrisi elde edilir —
 * tıpkı entity spawn testindeki mantığın GPU karşılığı.
 */
object GpuStressShader {

    const val SOURCE = """
        uniform float2 resolution;
        uniform float iterations;
        uniform float time;

        half4 main(float2 fragCoord) {
            float2 uv = (fragCoord - 0.5 * resolution) / min(resolution.x, resolution.y);
            uv *= 2.5;
            uv.x += 0.4;

            // Basit, klasik Mandelbrot iterasyonu — "en klasik hesaplama
            // mantığı" talebine uygun, egzotik olmayan, iyi bilinen bir
            // GPU stres yükü.
            float2 c = uv;
            float2 z = float2(0.0, 0.0);
            float iterCount = 0.0;
            float maxIter = iterations;

            for (float i = 0.0; i < 512.0; i += 1.0) {
                if (i >= maxIter) break;
                if (dot(z, z) > 4.0) break;
                float xTemp = z.x * z.x - z.y * z.y + c.x;
                z.y = 2.0 * z.x * z.y + c.y;
                z.x = xTemp;
                iterCount += 1.0;
            }

            float shade = iterCount / maxIter;
            // Zamanla hafif renk kayması — sadece görsel geri bildirim
            // için, hesaplama maliyetine önemli bir katkısı yok.
            //
            // ÖNEMLİ AGSL TİP UYUŞMAZLIĞI DÜZELTMESİ: bu satır önceden
            // `float3 color = half3(...)` idi — değişken float3 olarak
            // tanımlanıp sağ tarafta half3 constructor'ı çağrılıyordu.
            // AGSL (Skia'nın SkSL'ine dayanır) tip uyuşmazlıklarında
            // katıdır; float3/half3 arasında örtük bir dönüşüm garantisi
            // yoktur. Bu, RuntimeShader(source) çağrısının derleme
            // aşamasında başarısız olmasına yol açabilirdi — GpuStressCanvas
            // bunu zaten runCatching ile yakalayıp null'a düşürüyor
            // (crash olmuyor), AMA sonucu: AGSL destekleyen (API 33+)
            // TÜM cihazlarda shader hiç derlenmeden sessizce Canvas
            // fallback moduna geçiliyor olabilirdi — yani GPU testinin
            // asıl amacı olan "gerçek GPU shader stresi" hiçbir cihazda
            // çalışmadan, kullanıcı fark etmeden çok daha hafif bir teste
            // (Canvas çizimi) yönlendiriliyordu. Tipleri half3 ile
            // tutarlı hale getirdik — dönüş tipi zaten half4.
            half3 color = half3(
                0.5 + 0.5 * cos(3.0 + shade * 6.0 + time * 0.1),
                0.5 + 0.5 * cos(1.5 + shade * 6.0 + time * 0.1),
                0.5 + 0.5 * cos(0.0 + shade * 6.0 + time * 0.1)
            );

            return half4(color, 1.0);
        }
    """
}

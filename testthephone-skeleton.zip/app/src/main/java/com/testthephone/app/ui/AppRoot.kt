package com.testthephone.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.testthephone.app.R
import com.testthephone.app.core.monitoring.MetricsSnapshot
import com.testthephone.app.core.storage.SessionSummary
import com.testthephone.app.report.DeviceProfile
import com.testthephone.app.report.RunnerState
import com.testthephone.app.ui.navigation.BottomNavBar
import com.testthephone.app.ui.navigation.BottomNavTab
import com.testthephone.app.ui.screens.eula.EulaConsentScreen
import com.testthephone.app.ui.screens.history.HistoryScreen
import com.testthephone.app.ui.screens.home.HomeScreen
import com.testthephone.app.ui.screens.home.TestCatalogEntry
import com.testthephone.app.ui.screens.home.testDisplayNameRes
import com.testthephone.app.ui.screens.privacy.PrivacyPolicyScreen
import com.testthephone.app.ui.screens.report.ReportLoadState
import com.testthephone.app.ui.screens.report.ReportDetailScreen
import com.testthephone.app.ui.screens.settings.SettingsScreen
import com.testthephone.app.ui.screens.testrun.TestProgressScreen
import com.testthephone.app.ui.screens.testrun.ThermalPauseScreen
import com.testthephone.app.ui.screens.testrun.toLiveMetrics
import com.testthephone.app.ui.screens.testrun.toThermalStatusEnum

/**
 * Uygulamanın en üst seviye composable'ı. Akış sırası:
 *  1. EULA onaylanmadıysa -> EulaConsentScreen, başka hiçbir şey gösterilmez.
 *  2. RunnerState.PausedForThermal ise -> ThermalPauseScreen, alt navigasyon
 *     gizlenir (kullanıcının test durumundan dikkatini dağıtmamak için).
 *  3. RunnerState.Running ise -> TestProgressScreen, canlı metrikler.
 *  4. Aksi halde -> normal 3 sekmeli navigasyon (Ana sayfa/Geçmiş/Ayarlar).
 *
 * eulaAccepted artık DIŞARIDAN geliyor (UserPreferencesStore'dan,
 * MainActivity'de collectAsState ile okunuyor) — DataStore'a kalıcı
 * yazıldığı için uygulama her açıldığında tekrar sorulmuyor. Bu
 * composable'ın kendisi kalıcılık mekanizmasından habersiz, sadece
 * mevcut durumu render ediyor (tek yönlü veri akışı).
 */
@Composable
fun AppRoot(
    deviceProfile: DeviceProfile?,
    batteryLevelPct: Int?,
    batteryTempC: Float?,
    runnerState: RunnerState,
    latestSnapshot: MetricsSnapshot?,
    testCatalog: List<TestCatalogEntry>,
    eulaAccepted: Boolean,
    sessions: List<SessionSummary>,
    currentLanguageCode: String,
    darkThemeEnabled: Boolean,
    rootModeEnabled: Boolean,
    /**
     * Termal duraklatma ekranında "hâlâ soğumadı mı, soğudu mu"
     * ayrımını yapabilmek için SafetyController'ın GÜNCEL kararı.
     * TestRunner.safetyDecisionFlow'dan MainActivity'de collectAsState
     * ile okunup buraya geçirilir — SafetyDecision.PAUSE_REQUIRED ise
     * hâlâ kritik demektir, RUNNING/RUNNING_CAPPED ise soğumuş demektir.
     */
    currentSafetyDecision: com.testthephone.app.core.safety.SafetyDecision,
    /**
     * GPU (Test 3) ve tepki süresi (Test 7) testleri TestEngine
     * sözleşmesine uymadığı için normal runnerState akışından geçmez.
     * Bu testlerden biri seçildiğinde MainActivity bu slot'u doldurur;
     * null olduğunda normal navigasyon gösterilir. Slot'un içeriği
     * (GpuTestScreen/ReactionTimeTestScreen) MainActivity'de kurulur
     * çünkü MetricsCollector, TestResult gibi bağımlılıklar orada yaşıyor
     * — AppRoot bu testlerin iç detaylarından habersiz kalır.
     */
    activeSpecialTestContent: (@Composable () -> Unit)?,
    /**
     * Kullanıcı Geçmiş sekmesinden bir oturuma tıkladığında dolar
     * (MainActivity, sessionId'ye göre dosyayı okuyup ReportLoadState
     * üretir). Null iken normal navigasyon gösterilir.
     */
    selectedReportState: ReportLoadState?,
    onAcceptEula: () -> Unit,
    onDeclineEula: () -> Unit,
    onStartFullTest: () -> Unit,
    onSelectSingleTest: (testId: String) -> Unit,
    onResumeFromThermalPause: () -> Unit,
    onEndTestRun: () -> Unit,
    onSessionClick: (sessionId: String) -> Unit,
    onCloseReportDetail: () -> Unit,
    onShareReportJson: () -> Unit,
    onDeleteReportSession: () -> Unit,
    onLanguageSelected: (String) -> Unit,
    onDarkThemeToggled: (Boolean) -> Unit,
    onRootModeToggled: (Boolean) -> Unit,
) {
    if (!eulaAccepted) {
        EulaConsentScreen(
            onAccept = onAcceptEula,
            onDecline = onDeclineEula,
        )
        return
    }

    if (activeSpecialTestContent != null) {
        Box(modifier = Modifier.fillMaxSize()) {
            activeSpecialTestContent()
        }
        return
    }

    if (selectedReportState != null) {
        Box(modifier = Modifier.fillMaxSize()) {
            ReportDetailScreen(
                loadState = selectedReportState,
                onShareJson = onShareReportJson,
                onDeleteSession = {
                    onDeleteReportSession()
                    onCloseReportDetail()
                },
            )
        }
        return
    }

    if (runnerState is RunnerState.PausedForThermal) {
        Box(modifier = Modifier.fillMaxSize()) {
            ThermalPauseScreen(
                isStillTooHot = currentSafetyDecision == com.testthephone.app.core.safety.SafetyDecision.PAUSE_REQUIRED,
                onResumeRequested = onResumeFromThermalPause,
                onEndTestRequested = onEndTestRun,
            )
        }
        return
    }

    // ÖNEMLİ BUG DÜZELTMESİ: önceden bu koşul
    // `runnerState is RunnerState.Running && latestSnapshot != null` idi.
    // "Test Başlat"a basıldığında runnerState ANINDA Running'e geçer, ama
    // latestSnapshot ilk MetricsSnapshot event'i gelene kadar null kalır —
    // bu da ilk test adımının tamamlanmasını (entity spawn + framesPerStep
    // kadar simülasyon + metrics toplama) gerektirir, bu da yüzlerce
    // milisaniye sürebilir. O süre boyunca hiçbir dal eşleşmiyordu (Running
    // dalı latestSnapshot==null yüzünden, diğerleri zaten alakasız), kod en
    // alttaki normal navigasyona (HomeScreen) düşüyordu — yani kullanıcı
    // "Test Başlat"a bastığında UI, test gerçekten arka planda başlamış
    // olsa bile, bir süre HİÇBİR ŞEY OLMAMIŞ gibi görünüyordu. Kullanıcı
    // bu süre zarfında tekrar tekrar butona basarsa (ki "donmuş" hissi
    // yüzünden basması çok olası), her basış yeni bir runAll() coroutine'i
    // tetikleyip aynı anda birden fazla test çalıştırıyor, bu da gerçek bir
    // performans/tutarlılık sorununa (ve daha da "donmuş" bir hisse) yol
    // açıyordu. Düzeltme: latestSnapshot koşulunu kaldırıp sadece
    // runnerState'e bakıyoruz; snapshot henüz yokken TestProgressScreen
    // "hazırlanıyor" durumunu (progress_preparing metni, boş metrik
    // listesi) gösterir — bu da HomeScreen'e düşmekten çok daha doğru bir
    // geri bildirim.
    if (runnerState is RunnerState.Running) {
        Box(modifier = Modifier.fillMaxSize()) {
            TestProgressScreen(
                testDisplayName = runnerState.currentTestId
                    ?.let { stringResource(testDisplayNameRes(it)) }
                    ?: stringResource(R.string.progress_preparing),
                thermalStatus = latestSnapshot?.toThermalStatusEnum()
                    ?: com.testthephone.app.core.safety.ThermalStatus.NONE,
                progressFraction = if (runnerState.totalTests > 0) {
                    (runnerState.testIndex + 1).toFloat() / runnerState.totalTests.toFloat()
                } else 0f,
                metrics = latestSnapshot?.toLiveMetrics() ?: emptyList(),
            )
        }
        return
    }

    // Ayarlar'dan "Kullanım Koşulları" veya "Gizlilik Politikası"
    // tıklandığında dolan, tamamen UI'ye özgü, geçici bir görüntüleme
    // durumu. MainActivity'nin bunu bilmesine gerek yok — bu bir iş
    // mantığı kararı değil, sadece hangi ekranın üstte gösterileceği
    // bilgisi, bu yüzden bilinçli olarak AppRoot içinde tutuluyor.
    var overlayDocument by remember { mutableStateOf<LegalDocument?>(null) }

    if (overlayDocument != null) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (overlayDocument) {
                LegalDocument.EULA -> EulaConsentScreen(
                    onAccept = {},
                    onDecline = {},
                    readOnlyMode = true,
                    onClose = { overlayDocument = null },
                )
                LegalDocument.PRIVACY_POLICY -> PrivacyPolicyScreen(
                    onClose = { overlayDocument = null },
                )
                null -> Unit
            }
        }
        return
    }

    var currentTab by remember { mutableStateOf(BottomNavTab.HOME) }

    Scaffold(
        bottomBar = {
            BottomNavBar(currentTab = currentTab, onTabSelected = { currentTab = it })
        },
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
        ) {
            when (currentTab) {
                BottomNavTab.HOME -> HomeScreen(
                    deviceProfile = deviceProfile,
                    batteryLevelPct = batteryLevelPct,
                    batteryTempC = batteryTempC,
                    testCatalog = testCatalog,
                    onStartFullTest = onStartFullTest,
                    onSelectSingleTest = onSelectSingleTest,
                )
                BottomNavTab.HISTORY -> HistoryScreen(
                    sessions = sessions,
                    onSessionClick = onSessionClick,
                )
                BottomNavTab.SETTINGS -> SettingsScreen(
                    currentLanguageCode = currentLanguageCode,
                    darkThemeEnabled = darkThemeEnabled,
                    rootModeEnabled = rootModeEnabled,
                    onLanguageSelected = onLanguageSelected,
                    onDarkThemeToggled = onDarkThemeToggled,
                    onRootModeToggled = onRootModeToggled,
                    onOpenEula = { overlayDocument = LegalDocument.EULA },
                    onOpenPrivacyPolicy = { overlayDocument = LegalDocument.PRIVACY_POLICY },
                )
            }
        }
    }
}

private enum class LegalDocument { EULA, PRIVACY_POLICY }

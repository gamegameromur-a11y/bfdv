package com.testthephone.app.core.safety

import android.content.Context
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Uygulamanın güvenlik mimarisinin çekirdeği. Android'in resmi termal
 * API'lerini kullanır (PowerManager.getCurrentThermalStatus / thermal
 * headroom / thermal status listener) — bunlar CERTAIN güven seviyesinde,
 * izin gerektirmez ve OEM'in kendi termal HAL'ine dayanır (VTS sertifikasyon
 * gereksinimi sayesinde her Android cihazda var olması garanti edilir).
 *
 * Bilerek CPU/GPU sıcaklığı gibi dolaylı ölçümlere DEĞİL, işletim sisteminin
 * kendi "ne kadar zorlanıyorum" değerlendirmesine dayanıyoruz — çünkü bu,
 * cihaza özel termal tasarımdan bağımsız olarak her zaman doğru referans.
 */
class ThermalMonitor(context: Context) {

    private val powerManager = context.applicationContext
        .getSystemService(Context.POWER_SERVICE) as PowerManager

    /**
     * Anlık termal durumu okur. API 29 altında callback/polling API'si
     * mevcut değil; bu durumda NONE varsayılır ve UNAVAILABLE olarak
     * işaretlenir — çağıran taraf bu bilgiyi rapora yansıtmalı.
     */
    fun currentStatus(): ThermalReading {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return ThermalReading(
                status = ThermalStatus.UNKNOWN,
                headroom = null,
                supported = false,
            )
        }
        val rawStatus = powerManager.currentThermalStatus
        val headroom = try {
            // forecastSeconds = 0: şu anki ısınma eğilimini yansıtan en yakın tahmin.
            powerManager.getThermalHeadroom(0)
                .takeUnless { it.isNaN() }
        } catch (e: Throwable) {
            null
        }
        return ThermalReading(
            status = ThermalStatus.fromPlatformValue(rawStatus),
            headroom = headroom,
            supported = true,
        )
    }

    /**
     * Termal durum değişikliklerini canlı akış olarak dinler. Testler
     * bu akışı toplarken her değişiklikte acil durdurma eşiğini kontrol eder.
     */
    fun statusChanges(): Flow<ThermalReading> = callbackFlow {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            trySend(currentStatus())
            awaitClose { }
            return@callbackFlow
        }

        val listener = PowerManager.OnThermalStatusChangedListener { rawStatus ->
            val headroom = try {
                powerManager.getThermalHeadroom(0).takeUnless { it.isNaN() }
            } catch (e: Throwable) {
                null
            }
            trySend(
                ThermalReading(
                    status = ThermalStatus.fromPlatformValue(rawStatus),
                    headroom = headroom,
                    supported = true,
                )
            )
        }

        // Başlangıç değerini hemen gönder, sonra değişiklikleri dinle.
        trySend(currentStatus())
        powerManager.addThermalStatusListener(listener)

        awaitClose {
            powerManager.removeThermalStatusListener(listener)
        }
    }.distinctUntilChanged()
}

data class ThermalReading(
    val status: ThermalStatus,
    /** 0.0 (soğuk) ile 1.0+ (kritik throttling) arası tahmini oran. Null ise okunamadı. */
    val headroom: Float?,
    /** Bu cihaz/API seviyesi termal API'yi destekliyor mu. */
    val supported: Boolean,
)

/**
 * Android'in platform sabitleriyle bire bir eşleşir
 * (PowerManager.THERMAL_STATUS_*), ama kendi enum'umuzda tutmak
 * hem test edilebilirliği artırıyor hem de JSON serileştirmesinde
 * okunabilir isimler veriyor.
 */
enum class ThermalStatus(val severity: Int) {
    UNKNOWN(-1),
    NONE(0),
    LIGHT(1),
    MODERATE(2),
    SEVERE(3),
    CRITICAL(4),
    EMERGENCY(5),
    SHUTDOWN(6);

    companion object {
        fun fromPlatformValue(value: Int): ThermalStatus =
            entries.find { it.severity == value } ?: UNKNOWN
    }
}

package com.testthephone.app.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.core.storage.SessionSummary
import com.testthephone.app.ui.theme.AppColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Geçmiş sekmesi: SessionHistoryStore.listSessionSummaries()'ten gelen
 * gerçek oturum listesini gösterir. Her satır, tıklandığında
 * ReportDetail rotasına yönlendirilir.
 */
@Composable
fun HistoryScreen(
    sessions: List<SessionSummary>,
    // ÖNEMLİ TUTARLILIK BUG DÜZELTMESİ: formatSessionDate önceden
    // Locale.getDefault() (cihazın SİSTEM dili) kullanıyordu — uygulamanın
    // kendi iç dil tercihini (UserPreferencesStore.languageCode /
    // AppCompatDelegate.setApplicationLocales ile ayarlanan) hiç
    // yansıtmıyordu. Pratik sonucu: kullanıcı uygulama içinde İngilizce
    // seçse bile (ya da ilk açılışta İngilizce varsayılanı devredeyken,
    // bkz. MainActivity'deki ilk-açılış gerekçesi), cihaz sistem dili
    // Türkçe ise tarih/saat formatı sessizce Türkçe'ye dönüyordu (ay
    // adları "Ağustos" gibi) — aynı ekranda iki farklı dilin karışık
    // görünmesi, tutarsız ve kafa karıştırıcı bir deneyim yaratıyordu.
    // languageCode parametresi eklenip formatSessionDate'e aktarılıyor.
    languageCode: String,
    onSessionClick: (sessionId: String) -> Unit,
) {
    if (sessions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = stringResource(R.string.history_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextMuted,
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
    ) {
        items(sessions) { session ->
            SessionRow(
                session = session,
                languageCode = languageCode,
                onClick = { onSessionClick(session.sessionId) },
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun SessionRow(
    session: SessionSummary,
    languageCode: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .background(color = AppColors.Surface1)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = formatSessionDate(session.savedAtMillis, languageCode),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextPrimary,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = session.sessionId.take(8),
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextMuted,
            )
        }
        Text(text = "›", color = AppColors.TextMuted)
    }
}

private fun formatSessionDate(millis: Long, languageCode: String): String {
    // Artık cihazın sistem locale'i yerine uygulamanın kendi dil
    // tercihinden türetilen Locale kullanılıyor — Ayarlar ekranındaki
    // dil seçimiyle (ya da ilk açılış varsayılanı İngilizce ile)
    // tutarlı bir tarih/saat biçimi garanti ediliyor.
    val formatter = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale(languageCode))
    return formatter.format(Date(millis))
}

package com.testthephone.app.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.testthephone.app.R
import com.testthephone.app.core.storage.SessionSummary
import com.testthephone.app.ui.theme.AppColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Geçmiş sekmesi: SessionHistoryStore.listSessionSummaries()'ten gelen
 * gerçek oturum listesini gösterir. Her satır, tıklandığında
 * ReportDetail rotasına yönlendirilir.
 */
@Composable
fun HistoryScreen(
    sessions: List<SessionSummary>,
    onSessionClick: (sessionId: String) -> Unit,
) {
    if (sessions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = stringResource(R.string.history_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextMuted,
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp),
        contentPadding = PaddingValues(vertical = 20.dp),
    ) {
        items(sessions) { session ->
            SessionRow(
                session = session,
                onClick = { onSessionClick(session.sessionId) },
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun SessionRow(
    session: SessionSummary,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .background(color = AppColors.Surface1)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = formatSessionDate(session.savedAtMillis),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.TextPrimary,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = session.sessionId.take(8),
                style = MaterialTheme.typography.bodySmall,
                color = AppColors.TextMuted,
            )
        }
        Text(text = "›", color = AppColors.TextMuted)
    }
}

private fun formatSessionDate(millis: Long): String {
    // Not: SimpleDateFormat'ın "d MMMM yyyy, HH:mm" deseni Locale'e göre
    // ay adını (örn. "August" / "Ağustos" / "августа") otomatik lokalize
    // eder — bu, cihazın sistem locale'ini (Locale.getDefault()) kullanır.
    // Uygulama içi dil tercihini tarih biçimine de yansıtmak istersek,
    // bu fonksiyona bir Locale parametresi eklenip UserPreferencesStore
    // dil koduyla eşlenmesi gerekir.
    val formatter = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.getDefault())
    return formatter.format(Date(millis))
}
